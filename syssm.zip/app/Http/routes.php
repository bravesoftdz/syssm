<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

// route to show the login form
Route::get('login', array('uses' => 'PagesController@showLogin'));
Route::post('login', array('uses' => 'PagesController@doLogin'));
Route::get('/logout', array('as' => 'logout', 'uses' => 'PagesController@doLogout'));
Route::post('/changepass', array('as' => 'changepass', 'uses' => 'UsersController@changepass'));
Route::post('/post/cep', array('as' => 'buscaCEP', 'uses' => 'UtilsController@buscaCEP'));
	
Route::group(['middleware' => 'setglobals'], 
	function() {	
		//Main
		Route::get('/', 'PagesController@home');
		Route::get('/home', array('as' => 'home', 'uses' => 'PagesController@home'));
		

		Route::post('/desativarLembrete', array('as' => 'desativarLembrete', 'uses' => 'AgendaController@desativarLembrete'));		
		
		Route::get('/managelog', array('as' => 'managelog', 'uses' => 'PagesController@managelog'));
		Route::get('/managebackup' , array('as' => 'managebackup' , 'uses' => 'PagesController@managebackup'));
		Route::get('/restore', array('as' => 'restore', 'uses' => 'MigrateController@restore'));
		Route::get('/search', array('as' => 'search', 'uses' => 'PagesController@search'));
		Route::post('/pesquisaBeneficiario', array('as' => 'pesquisaBeneficiario', 'uses' => 'PagesController@pesquisaBeneficiario'));
		
		//Métodos adicionais aos resources precisam ser declarados antes
		
		//CRUDs
		Route::resource('parametros', 'ParametrosController');
		Route::resource('users', 'UsersController');
		Route::resource('produtos', 'ProdutosController');
		Route::resource('agenda', 'AgendaController');
		Route::resource('pdf', 'PDFController');
		Route::resource('financeiro', 'FinanceiroController');
	});