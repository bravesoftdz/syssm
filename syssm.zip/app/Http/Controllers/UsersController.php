<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Models\User;
use Session;
use Illuminate\Encryption\Encrypter;
use Exception;
use Validator;
use DB; // para usar a classe DB
use Illuminate\Hashing\BcryptHasher as Hash;

class UsersController extends Controller
{
	public function index()
	{
		if (\Auth::check())
		{
			$users = User::all();
	
			return view('users.index')->withUsers($users);
		}else
		{
			return view('pages.login');			
		}
	}

	public function create()
	{
		return view('users.create');
	}	
	
	public function show($id)
	{
		$user = User::findOrFail($id);
	
		return view('users.show')->withUser($user);
	}
	
	public function edit($id)
	{
		$user = User::findOrFail($id);
		
		return view('users.edit')->withUser($user);
	}
	
	public function update($id, Request $request)
	{
		$user = User::findOrFail($id);
		
		try
		{
            $this->validate($request, 
			   ['email' => 'required',
				'password' => 'required',
				'nome_funcionario' => 'required',
				'id_tipo_perfil' => 'required'
			]);
			
			$input = $request->all();
			$input['password'] = \Hash::make($input['password']);		
			$user->fill($input)->save();
		
			Session::flash('flash_message', 'Usuário alterado com sucesso!');
			
		} catch (Exception $e) {
			Session::flash('flash_danger', $e->getMessage());
		}
	
		return redirect()->back();
	}	

	private function validarTrocaSenha(User $user, array $input)
	{	
		if(($input['senha_atual'] == "") || ($input['password'] == "") || ($input['password_confirmation'] == ""))
		{
			throw new Exception('Todos os campos devem ser preenchidos.');
			return False;			
		}
		elseif(!\Hash::check($input['senha_atual'], $user->getAuthPassword()))
		{
			throw new Exception('Senha atual incorreta.');
			return False;			
		}
		elseif($input['password'] != $input['password_confirmation'])
		{
			throw new Exception('Senhas não coincidem.');			
			return False;
		}
		else
		{
			return True;
		}
	}
	
	public function changepass(Request $request)
	{	
		try
		{
			$id = Config('globals.id_usuario');
			$user = User::findOrFail($id);		
	
			/*
			try
			{
				$this->validate($request, [
					'senha_atual' => 'required',
					'password' => 'required',
					'password_confirmation' => 'required',
				]);
			} catch(ValidationException $e) {
				throw $e;
			}
			*/	

			$input = $request->all();
			
			if($this->validarTrocaSenha($user, $input))
			{
				$input['password'] = \Hash::make($input['password']);
				$user->fill($input)->save();
				Session::flash('flash_message', 'Senha alterada com sucesso!');
			}
			else
			{
				throw new Exception('Não foi possível alterar a senha.');
			}

		} catch (Exception $e) {
			Session::flash('flash_danger', $e->getMessage());
		}
			
		return redirect()->back();
	}

	public function store(Request $request)
	{
		$this->validate($request, [
			'name' => 'required',
			'email' => 'required',
			'password' => 'required',
			'nome_funcionario' => 'required',
			'id_tipo_perfil' => 'required'	
		]);		
		
		$input = $request->all();
		$input['password'] = bcrypt($input['password']);
		
		User::create($input);
		
        Session::flash('flash_message', 'Usuário gravado com sucesso!');		
	
		return redirect()->back();
	}
	
	public function destroy($id)
	{
		$user = User::findOrFail($id);
	
		$user->delete();
	
		Session::flash('flash_message', 'Exclusão efetuada com sucesso!');
	
		return redirect()->route('users.index');
	}	
}