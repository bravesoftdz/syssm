<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\App;
use Session;


class PdfController extends Controller
{
	public static function printPortrait($content) {

		$pdf = \App::make('dompdf.wrapper');
		$pdf->setOrientation('portrait');		
		$pdf->loadHTML($content);
		return $pdf->stream();
	}
	
	public static function printLandscape($content) {
		
		$pdf = \App::make('dompdf.wrapper');
		$pdf->setOrientation('landscape');
		$pdf->loadHTML($content);
		return $pdf->stream();
	}
	
}