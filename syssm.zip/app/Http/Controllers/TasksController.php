<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Models\Task;
use Session;

use DB; // para usar a classe DB

class TasksController extends Controller
{
	public function index()
	{
		if (\Auth::check())
		{
			$tasks = Task::all();
	
			return view('tasks.index')->withTasks($tasks);
		}else
		{
			return view('pages.login');			
		}
	}

	public function create()
	{
		return view('tasks.create');
	}	
	
	public function show($id)
	{
		$task = Task::findOrFail($id);
	
		return view('tasks.show')->withTask($task);
	}
	
	public function edit($id)
	{
		$task = Task::findOrFail($id);
	
		return view('tasks.edit')->withTask($task);
	}
	
	public function update($id, Request $request)
	{
		$task = Task::findOrFail($id);
	
		$this->validate($request, [
			'title' => 'required',
			'description' => 'required'
		]);
	
		$input = $request->all();
	
		$task->fill($input)->save();
	
		Session::flash('flash_message', 'Tarefa alterada com sucesso!');
	
		return redirect()->back();
	}	
	
	public function store(Request $request)
	{
		$this->validate($request, [
			'title' => 'required',
			'description' => 'required'
		]);		
		
		$input = $request->all();
	
		Task::create($input);
		
        Session::flash('flash_message', 'Tarefa gravada com sucesso!');		
	
		return redirect()->back();
	}
	
	public function destroy($id)
	{
		$task = Task::findOrFail($id);
	
		$task->delete();
	
		Session::flash('flash_message', 'Exclusão efetuada com sucesso!');
	
		return redirect()->route('tasks.index');
	}	
}