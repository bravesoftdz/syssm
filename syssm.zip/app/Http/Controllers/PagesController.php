<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\UtilsController;
use App\Http\Controllers\Auth;
use App\Http\Requests;
use App\Models\User;
use App\Models\Beneficiario;
use App\Models\Requerimento;
use App\Models\Escritorio;
use Config;
use Session;
use DB; 
use Exception;

use Illuminate\Support\Facades\Hash;

class PagesController extends Controller
{

	public function showWelcome()
	{
		return view('pages.welcome');
	}

	public function showLogin()
	{
		// show the form
		return view('pages.login');
	}

	public function doLogin()
	{
		// validate the info, create rules for the inputs
		$rules = array(
		    'name' => 'required|max:255',
			'password' => 'required|alphaNum|min:3' // password can only be alphanumeric and has to be greater than 3 characters
		);

		// run the validation rules on the inputs from the form
		$validator = Validator::make(Input::all(), $rules);

		// if the validator fails, redirect back to the form
		if ($validator->fails()) {
			return Redirect::to('login')
				->withErrors($validator) // send back all errors to the login form
				->withInput(Input::except('password')); // send back the input (not the password) so that we can repopulate the form
		} else {

			// create our user data for the authentication
			$userdata = array(
				'name' 	=> Input::get('name'),
				'password' 	=> Input::get('password')
			);

			// attempt to do the login
			if (\Auth::attempt($userdata)) {

				// validation successful!
				// redirect them to the secure section or whatever
				// return Redirect::to('secure');
				// for now we'll just echo success (even though echoing in a controller is bad)
				//echo 'SUCCESS!';
				return Redirect::to('/');

			} else {
				$validator->errors()->add('tagName', 'Login ou senha inválidos. Tente novamente.');
				return redirect('/')->withErrors($validator);
			}

		}
	}	

	public function home()
	{
		if (\Auth::check())
		{
			return view('pages.home');
		}else
		{
			return view('pages.login');
		}
	}	
	
	public function doLogout()
	{
		\Auth::logout();
		return Redirect::to('/');
	}
	
	public function managelog()
	{
		return view('pages.managelog');
	}
	
	public function managebackup()
	{
		return view('pages.managebackup');
	}
	
	public function search()
	{
		try
		{
			$input = Input::all();
			
			$pesquisa_todos = isset($input['pesquisa_todos']);
			$tipo_pesquisa = $input['tipo_pesquisa'];
			$tipospesquisa = Config::get('globals.array_SearchTiposPesquisa');
			$desc_tipopesquisa = $tipospesquisa[$tipo_pesquisa];

			if(isset($input['valor_pesquisa']))
				$valor_pesquisa = $input['valor_pesquisa'];
			else
				$valor_pesquisa = '';
			
			if((!$pesquisa_todos) && ($valor_pesquisa == ""))
				throw new Exception('O termo pesquisado está em branco.');
			
			if(in_array($tipo_pesquisa, Config::get('globals.array_TiposPesquisa_Requerimento')))
			{
				$colunas = array('Beneficiário', 'Protocolo', 'Data do Contrato', 'Data de Encerramento', 'Situação do Benefício', 'Observação');
				$dados = $this->getSearchRequerimento($tipo_pesquisa, $valor_pesquisa, $pesquisa_todos);
			}
			elseif(in_array($tipo_pesquisa, Config::get('globals.array_TiposPesquisa_Beneficiario')))
			{
				$colunas = array('Nome', 'CPF', 'Telefone', 'Celular', 'Data Nascimento', 'Profissão');
				$dados = $this->getSearchBeneficiario($tipo_pesquisa, $valor_pesquisa, $pesquisa_todos);		
			}
			
			return view('pages.searchresult', ['colunas' => $colunas, 
							   'dados' => $dados,
							   'desc_tipopesquisa' => $desc_tipopesquisa]);				
			
		} catch (Exception $e) {
			Session::flash('flash_danger', $e->getMessage());
			return redirect()->back();			
		}
	}
		
	private function getSQLfiltroEscritorio() {
		
		//filtra o escritório somente quando o usuário logado não for ADMIN
		if(!Config::get('globals.usuario_admin')) {
			return ' requerimentos.id_escritorio = ' . Config::get('globals.usuario_escritorio');
		}
		else {
			return ' requerimentos.id_escritorio is not null';
		}		
	}
	
	private function getSearchRequerimento($tipo_pesquisa, $valor_pesquisa, $pesquisa_todos) {

		$sql = 'select beneficiarios.nome, ' .
               '       requerimentos.protocolo_interno, ' .
               '       DATE_FORMAT(requerimentos.dt_contrato, "%d/%m/%Y") as dt_contrato,' .
               '       coalesce(DATE_FORMAT(requerimentos.dt_encerramento, "%d/%m/%Y"), "-") as dt_encerramento, ' .
               '       tipo_sit_beneficio.descricao as sit_beneficio, ' .
               '       requerimentos.observacao, ' .
	           '       CONCAT("beneficiarios/", beneficiarios.id, "/edit") as link ' .	
               '  from requerimentos ' .
               '  join beneficiarios on beneficiarios.id = requerimentos.id_beneficiario ' .
               '  join escritorios on escritorios.id = requerimentos.id_escritorio and '. $this->getSQLfiltroEscritorio() . 
	           '  join tipo_sit_beneficio on tipo_sit_beneficio.id = requerimentos.id_sit_beneficio ';
		
		if($pesquisa_todos) {
			
			switch ($tipo_pesquisa) {
				case 2: //Número do Requerimento
				{
					$sql .= ' order by requerimentos.protocolo_interno ';
					break;
				}
				case 1: //a definir
				{
					break;
				}
			}
			
			return DB::connection()->select($sql, []);
		}
		else {
			
			switch ($tipo_pesquisa) {
				case 2: //Número do Requerimento
				{
					$sql .= ' where requerimentos.protocolo_interno = :protocolo_interno ';
					$sql .= ' order by requerimentos.protocolo_interno ';
					$array_params = array('protocolo_interno' => str_pad($valor_pesquisa, 10, "0", STR_PAD_LEFT));
					break;
				}
				case 1: //a definir
				{
					break;
				}
				default:
				{
					$array_params = [];
					break;
				}
			}
			
			return DB::connection()->select($sql, $array_params );
		}
	}	
	
	private function getSearchBeneficiario($tipo_pesquisa, $valor_pesquisa, $pesquisa_todos) {
		
		$sql = 'select distinct beneficiarios.nome, ' .
               '       beneficiarios.cpf, ' .
               '       beneficiarios.tel_residencial, ' .
               '       beneficiarios.tel_celular, ' .
               '       beneficiarios.dt_nascimento, ' .
               '       beneficiarios.profissao, ' .
		       '       CONCAT("beneficiarios/", beneficiarios.id, "/edit") as link ' .
               '  from beneficiarios ' . 
               '  left join requerimentos on requerimentos.id_beneficiario = beneficiarios.id ' . 
               '  left join escritorios on escritorios.id = requerimentos.id_escritorio and '. $this->getSQLfiltroEscritorio(); 					   
						
		if($pesquisa_todos) {
			
			switch ($tipo_pesquisa) {
				case 0: //nome do beneficiário
				{
					$sql .= ' order by beneficiarios.nome ';
					break;
				}
				case 1: //cpf do beneficiário
				{
					$sql .= ' order by beneficiarios.cpf ';
					break;
				}
			}			
			
			return DB::connection()->select($sql, []);
		}
		else {
			
			switch ($tipo_pesquisa) {
				case 0: //nome do beneficiário
				{
					$sql .= ' where LOWER(beneficiarios.nome) like CONCAT("%", LOWER(:nome), "%")';
					$sql .= ' order by beneficiarios.nome ';
					$array_params = array('nome' => UtilsController::tirarAcentos($valor_pesquisa));
					break;
				}
				case 1: //cpf do beneficiário
				{
					$sql .= ' where beneficiarios.cpf = :cpf';				
					$sql .= ' order by beneficiarios.cpf ';
					$array_params = array('cpf' => $valor_pesquisa);
					break;
				}
				default:
				{
					$array_params = [];
					break;
				}
			}			
			
			return DB::connection()->select($sql, $array_params);
		}
	}

	public function pesquisaBeneficiario(Request $request) {
	
	    /*if ( Request::ajax() ){
            // do what you want.
			return "teste ok.";
        }*/
		//	  return response()->json(['name' => 'Abigail', 'state' => 'CA']);
				  
	    if($request->ajax()){
    	    return "AJAX";
	    }
    	return "HTTP";		
				
		//$request->merge(UtilsController::retornaSearchBuffer());
		
	}
}