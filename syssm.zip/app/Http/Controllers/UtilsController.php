<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\URL;
use App\Models\AcessoCliente;
use App\Models\Beneficiario;
use App\Models\Configuracao;
use DateTime;
use Validator;
use Exception;
use Session;
use DB;

class UtilsController extends Controller
{	
    /**
     * Validate the given request with the given rules.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  array  $rules
     * @param  array  $messages
     * @param  array  $customAttributes
     * @return void
     */
    public static function customValidation(Request $request, array $rules, array $messages = [], array $customAttributes = [])
    {
        /*$validator = $this->getValidationFactory()->make($request->all(), $rules, $messages, $customAttributes);

        if ($validator->fails()) {
            $this->throwValidationException($request, $validator);
        }
		*/
		$validator = Validator::make($request->all(), $rules, $messages, $customAttributes);
			
		if ($validator->fails()) {
			$erros = '';
			foreach($validator->messages()->all() as $erro)
			{
				$erros .= trim($erro) . " \n ";
			}
			throw new Exception($erros);
		}
		else
		{
			return True;
		}		
    }
	
	public static function formatDate($input_format, $output_format, $source) {
		
		$dt = \DateTime::createFromFormat($input_format, $source);
		$dt_formatada = $dt->format($output_format);
		return $dt_formatada;
		
	} 
	
	public static function validateDate($date, $format = 'Y-m-d H:i:s')
	{
		if($date = "")
			return False;
		else
		{
			$dt = \DateTime::createFromFormat($format, $date);
			return $dt && $dt->format($format) == $date;
		}
	}
	
	public static function validaCPF($cpf = null) {
 
		// Verifica se um número foi informado
		if(empty($cpf)) {
			return false;
		}
	
		// Elimina possivel mascara
		//$cpf = ereg_replace('[^0-9]', '', $cpf);
		//$cpf = str_pad($cpf, 11, '0', STR_PAD_LEFT);
		
		// Verifica se o numero de digitos informados é igual a 11 
		if (strlen($cpf) != 11) 
		{
			return false;
		} // Verifica se nenhuma das sequências invalidas abaixo foi digitada. Caso afirmativo, retorna falso
		elseif($cpf == '00000000000' || 
			   $cpf == '11111111111' || 
			   $cpf == '22222222222' || 
			   $cpf == '33333333333' || 
			   $cpf == '44444444444' || 
			   $cpf == '55555555555' || 
			   $cpf == '66666666666' || 
			   $cpf == '77777777777' || 
			   $cpf == '88888888888' || 
			   $cpf == '99999999999') 
		{
			return false;
		// Calcula os digitos verificadores para verificar se o
		// CPF é válido
		} else {   
			
			for ($t = 9; $t < 11; $t++) {
				
				for ($d = 0, $c = 0; $c < $t; $c++) {
					$d += $cpf{$c} * (($t + 1) - $c);
				}
				$d = ((10 * $d) % 11) % 10;
				if ($cpf{$c} != $d) {
					return false;
				}
			}
	
			return true;
		}
	}

	/* 
	 *  Função de busca de Endereço pelo CEP 
	 *  -   Desenvolvido Felipe Olivaes para ajaxbox.com.br 
	 *  -   Utilizando WebService de CEP da republicavirtual.com.br 
	 */  
	public static function buscaCEP(Request $request)
	{  
		$cep = $request->input('cep');
		$resultado = @file_get_contents('http://republicavirtual.com.br/web_cep.php?cep='.urlencode($cep).'&formato=query_string');  
		if(!$resultado){  
			$resultado = "&resultado=0&resultado_txt=erro+ao+buscar+cep";  
		}  
		parse_str($resultado, $retorno);   
		//return $retorno; 
		
		$array_endereco = array();
		
		switch($retorno['resultado']){  
			case '2': //Cidade com logradouro único 
			{
				$array_endereco = ['cidade' => $retorno['cidade'],
				                   'uf' => $retorno['uf']];
				break;  
			}      
			case '1':  //Cidade com logradouro completo
			{
				$array_endereco = ['endereco' => $retorno['tipo_logradouro'] . " " . $retorno['logradouro'],
                                   'bairro' => $retorno['bairro'],
                                   'cidade' => $retorno['cidade'],
				                   'uf' => $retorno['uf']];
				break;
			}      
			default:  
				//throw new Exception("Falha ao buscar cep: " . $retorno['resultado']);
				$array_endereco = ['endereco' => "Falha ao buscar cep: " . $retorno['resultado']];
		}
				
		return $array_endereco;
		//return redirect()->back()->withInput();
 	}
	
	public static function showFile($file) {
		
		if (file_exists($file)) {
			
            $file_extension = strtolower(substr(strrchr($file,"."),1));

            switch ($file_extension) {
                case "pdf": $ctype = "application/pdf"; break;
				case "rtf": $ctype = "application/rtf"; break;
                case "exe": $ctype = "application/octet-stream"; break;
                case "zip": $ctype = "application/zip"; break;
                case "doc": $ctype = "application/msword"; break;
                case "xls": $ctype = "application/vnd.ms-excel"; break;
                case "ppt": $ctype = "application/vnd.ms-powerpoint"; break;
                case "gif": $ctype = "image/gif"; break;
                case "png": $ctype = "image/png"; break;
                case "jpe": 
				case "jpeg":
                case "jpg": $ctype = "image/jpg"; break;
                default: $ctype = "application/octet-stream";
            }		
			
			header('Content-type: '. $ctype);
			header('Content-Disposition: inline; filename="'.basename($file).'"');
			header('Content-Transfer-Encoding: binary');
			header('Content-Length: ' . filesize($file));
			header('Accept-Ranges: bytes');
			readfile($file);
		}
	}
		
	public static function downloadFile($file) {
		
		if (file_exists($file)) {
			
            $file_extension = strtolower(substr(strrchr($file,"."),1));

            switch ($file_extension) {
                case "pdf": $ctype = "application/pdf"; break;
				case "rtf": $ctype = "application/rtf"; break;
                case "exe": $ctype = "application/octet-stream"; break;
                case "zip": $ctype = "application/zip"; break;
                case "doc": $ctype = "application/msword"; break;
                case "xls": $ctype = "application/vnd.ms-excel"; break;
                case "ppt": $ctype = "application/vnd.ms-powerpoint"; break;
                case "gif": $ctype = "image/gif"; break;
                case "png": $ctype = "image/png"; break;
                case "jpe": 
				case "jpeg":
                case "jpg": $ctype = "image/jpg"; break;
                default: $ctype = "application/force-download";
            }			
			
			header('Content-Description: File Transfer');
			header('Content-Type: '. $ctype);
			header('Content-Disposition: attachment; filename="'.basename($file).'"');
			header('Expires: 0');
			header('Cache-Control: must-revalidate');
			header('Pragma: public');
			header('Content-Length: ' . filesize($file));
			readfile($file);
		}	
	}
	
	public static function formatCEP($cep) {
		
		$cep = str_pad($cep, 8, "0", STR_PAD_RIGHT); //completa com zeros à direita		
		return substr($cep, 0, 5) . "-" . substr($cep, 5, 3);
	}
	
	public static function formatCPF($cpf) {
		
		$cpf = str_pad($cpf, 11, "0", STR_PAD_LEFT); //completa com zeros à direita		
		return substr($cpf, 0, 3) . "." . 
			   substr($cpf, 3, 3) . "." . 
			   substr($cpf, 6, 3) . "-" . 
		       substr($cpf, 9, 2);
	}
	
	public static function tirarAcentos($string)
	{
		return preg_replace(array("/(á|à|ã|â|ä)/",
		                          "/(Á|À|Ã|Â|Ä)/",
								  "/(é|è|ê|ë)/",
								  "/(É|È|Ê|Ë)/",
								  "/(í|ì|î|ï)/",
								  "/(Í|Ì|Î|Ï)/",
								  "/(ó|ò|õ|ô|ö)/",
								  "/(Ó|Ò|Õ|Ô|Ö)/",
								  "/(ú|ù|û|ü)/",
								  "/(Ú|Ù|Û|Ü)/",
								  "/(ñ)/",
								  "/(Ñ)/",
								  "/(ç)/",
								  "/(Ç)/"
								 ),
							explode(" ","a A e E i I o O u U n N c C"),
							$string);
	}		

    public static function generateRandomString($length = 10) 
    {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
    
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }
	
    public static function loginPorNumContrato()
	{
	    $config = Configuracao::findOrFail(1);
		return ($config->loginCliPorContrato == 'S');
	}
	
    public static function procuracaoPadraoINSS()
	{
	    $config = Configuracao::findOrFail(1);
		return ($config->modelo_procuracao == 1);  /* 1. INSS 2. Termo Resp. */
	}
	
	public static function tipoImpressaoRelatorio()
	{
		return \Config::get('globals.tipo_impressao_relatorio');
	}
	
    public static function contratoFormatoDOC()
	{
	    $config = Configuracao::findOrFail(1);
		return ($config->modelo_contrato == 1);  /* 1. DOC/RTF 2. HTML/PDF. */
	}
	
	public static function primeiroNome($nome) {
	    
		$nome = trim($nome);
		$pos = strpos($nome, ' ');

		if ($pos === false) {
		    return $nome;
		} else {
		    return substr($nome, 0, $pos);
		}		
	}
	
	
    public static function criaAcessoCliente($beneficiario)
    {
 	   $cli = new AcessoCliente;
 	   $cli->id_beneficiario = $beneficiario->id;

	   if(UtilsController::loginPorNumContrato())
	   {
	 	   $cli->login = str_pad($beneficiario->id, 10, "0", STR_PAD_LEFT);
 		   $cli->senha = Hash::make(UtilsController::generateRandomString());
	   }
	   else
	   {
	 	   $cli->login = UtilsController::primeiroNome($beneficiario->nome);
 		   $cli->senha = Hash::make($beneficiario->cpf);
	   }

 	   $cli->ativo = 'S';
	   $cli->save();
 	   return $cli;
    }
    
	public static function clienteTemAcesso($id_beneficiario) {
	
   	   $cli = UtilsController::recuperaAcessoCliente($id_beneficiario);
   	   return !empty($cli);
	}

	public static function recuperaAcessoCliente($id_beneficiario) {
			
		return AcessoCliente::where('id_beneficiario', '=', $id_beneficiario)->get()->first();
	}
	
    public static function geraAcessoCliente($id_beneficiario = 0) {
 
 	   try
	   {
		   DB::beginTransaction();
		   
		   if($id_beneficiario != 0)
 		   {	
	    	   $beneficiario = Beneficiario::findOrFail($id_beneficiario);
			   if(UtilsController::clienteTemAcesso($id_beneficiario))
			      AcessoCliente::where('id_beneficiario', '=', $id_beneficiario)->delete();
				  
    	       $cli = UtilsController::criaAcessoCliente($beneficiario);

		   	   DB::commit();
			   return $cli;
	   	   }
	   	   else //todos
	   	   {
	    	   AcessoCliente::truncate(); //limpa tabela de acesso
			   
			   $array_beneficiario = Beneficiario::all();
   		       foreach($array_beneficiario as $beneficiario)
		       		$cli = UtilsController::criaAcessoCliente($beneficiario);		   
					   
		   	   DB::commit();
			   return $array_beneficiario;
		   }
		   
       } catch (Exception $e) {
            DB::rollback();
            throw $e;
			return array();
        } 	   
	}

    private static function getModeloDoc($input, $nomecampo, $file)
    {
		$file_ext  = $file->getClientOriginalExtension();
		$file_path = $file->getRealPath();
		$file_data = file_get_contents($file_path);									
		$base64 = base64_encode($file_data);
		
		return $file_ext . '||' . $base64;
	}

   public static function retornaEnderecoBuffer()
   {
      if(isset($_COOKIE['endereco']) && 
         isset($_COOKIE['bairro']) && 
		 isset($_COOKIE['cidade']) && 
		 isset($_COOKIE['uf']))
   		return array('endereco' => $_COOKIE['endereco'],
                     'bairro' => $_COOKIE['bairro'],
					 'cidade' => $_COOKIE['cidade'],
					 'uf' => $_COOKIE['uf']);
	  else
   		return array('endereco' => '',
                     'bairro' => '',
					 'cidade' => '',
					 'uf' => '');
	  
   }
   
   public static function retornaSearchBuffer()
   {
      if(isset($_COOKIE['tipo_pesquisa']) && 
         isset($_COOKIE['valor_pesquisa']))
   		return array('tipo_pesquisa' => $_COOKIE['tipo_pesquisa'],
                     'valor_pesquisa' => $_COOKIE['valor_pesquisa']);
	  else
   		return array('tipo_pesquisa' => '',
                     'valor_pesquisa' => '');  
   }   

   public static function atribuiValoresCheckBox(array $checkboxes, $model, &$input)
   {
		foreach ($checkboxes as $chk) 
		   if(isset($input[$chk]))
		   {	
		   		$model->setAttribute($chk, 'S');
				unset($input[$chk]);
		   }
		   else
		   		$model->setAttribute($chk, 'N');
   }
   
    public static function removerFormatacaoNumero( $strNumero )
    {
 
        $strNumero = trim( str_replace( "R$", null, $strNumero ) );
 
        $vetVirgula = explode( ",", $strNumero );
        if ( count( $vetVirgula ) == 1 )
        {
            $acentos = array(".");
            $resultado = str_replace( $acentos, "", $strNumero );
            return $resultado;
        }
        else if ( count( $vetVirgula ) != 2 )
        {
            return $strNumero;
        }
 
        $strNumero = $vetVirgula[0];
        $strDecimal = mb_substr( $vetVirgula[1], 0, 2 );
 
        $acentos = array(".");
        $resultado = str_replace( $acentos, "", $strNumero );
        $resultado = $resultado . "." . $strDecimal;
 
        return $resultado;
 
    }   
	
   public static function valorPorExtenso( $valor = 0, $bolExibirMoeda = true, $bolPalavraFeminina = false )
   {
        $valor = self::removerFormatacaoNumero( $valor );
 
        $singular = null;
        $plural = null;
 
        if ( $bolExibirMoeda )
        {
            $singular = array("centavo", "real", "mil", "milhão", "bilhão", "trilhão", "quatrilhão");
            $plural = array("centavos", "reais", "mil", "milhões", "bilhões", "trilhões","quatrilhões");
        }
        else
        {
            $singular = array("", "", "mil", "milhão", "bilhão", "trilhão", "quatrilhão");
            $plural = array("", "", "mil", "milhões", "bilhões", "trilhões","quatrilhões");
        }
 
        $c = array("", "cem", "duzentos", "trezentos", "quatrocentos","quinhentos", "seiscentos", "setecentos", "oitocentos", "novecentos");
        $d = array("", "dez", "vinte", "trinta", "quarenta", "cinquenta","sessenta", "setenta", "oitenta", "noventa");
        $d10 = array("dez", "onze", "doze", "treze", "quatorze", "quinze","dezesseis", "dezesete", "dezoito", "dezenove");
        $u = array("", "um", "dois", "três", "quatro", "cinco", "seis","sete", "oito", "nove");
 
 
        if ( $bolPalavraFeminina )
        {
        
            if ($valor == 1) 
            {
                $u = array("", "uma", "duas", "três", "quatro", "cinco", "seis","sete", "oito", "nove");
            }
            else 
            {
                $u = array("", "um", "duas", "três", "quatro", "cinco", "seis","sete", "oito", "nove");
            }
            
            
            $c = array("", "cem", "duzentas", "trezentas", "quatrocentas","quinhentas", "seiscentas", "setecentas", "oitocentas", "novecentas");
            
            
        }
 
 
        $z = 0;
 
        $valor = number_format( $valor, 2, ".", "." );
        $inteiro = explode( ".", $valor );
 
        for ( $i = 0; $i < count( $inteiro ); $i++ ) 
        {
            for ( $ii = mb_strlen( $inteiro[$i] ); $ii < 3; $ii++ ) 
            {
                $inteiro[$i] = "0" . $inteiro[$i];
            }
        }
 
        // $fim identifica onde que deve se dar junção de centenas por "e" ou por "," ;)
        $rt = null;
        $fim = count( $inteiro ) - ($inteiro[count( $inteiro ) - 1] > 0 ? 1 : 2);
        for ( $i = 0; $i < count( $inteiro ); $i++ )
        {
            $valor = $inteiro[$i];
            $rc = (($valor > 100) && ($valor < 200)) ? "cento" : $c[$valor[0]];
            $rd = ($valor[1] < 2) ? "" : $d[$valor[1]];
            $ru = ($valor > 0) ? (($valor[1] == 1) ? $d10[$valor[2]] : $u[$valor[2]]) : "";
 
            $r = $rc . (($rc && ($rd || $ru)) ? " e " : "") . $rd . (($rd && $ru) ? " e " : "") . $ru;
            $t = count( $inteiro ) - 1 - $i;
            $r .= $r ? " " . ($valor > 1 ? $plural[$t] : $singular[$t]) : "";
            if ( $valor == "000")
                $z++;
            elseif ( $z > 0 )
                $z--;
                
            if ( ($t == 1) && ($z > 0) && ($inteiro[0] > 0) )
                $r .= ( ($z > 1) ? " de " : "") . $plural[$t];
                
            if ( $r )
                $rt = $rt . ((($i > 0) && ($i <= $fim) && ($inteiro[0] > 0) && ($z < 1)) ? ( ($i < $fim) ? ", " : " e ") : " ") . $r;
        }
 
        $rt = mb_substr( $rt, 1 );
 
        return($rt ? trim( $rt ) : "zero");
 
    }	
	
}