<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Parametros;
use App\Http\Controllers\UtilsController;
use Session;

class ParametrosController extends Controller 
{

	public function index()
	{
		if (\Auth::check())
		{
			$parametros = Parametros::all();
			//return view()->withTasks($parametros);
			return view('parametros.index')->withParametros($parametros);
		}else
		{
			return view('pages.login');			
		}
    }
	
    /*
    function for  add Parametros get
    created by your name
    created at 22-01-17.
    */
    public function addParametros() {

        $this->load->view('parametros/add-parametros');

    }
    /*
    function for add Parametros post
    created by your name
    created at 22-01-17.
    */
    public function addParametrosPost() {
		
		$data['emp_razao_social']    = $this->input->post('emp_razao_social');
		$data['emp_cnpj']            = $this->input->post('emp_cnpj');
		$data['emp_endereco']        = $this->input->post('emp_endereco');
		$data['emp_complemento']     = $this->input->post('emp_complemento');
		$data['emp_nome_fantasia']   = $this->input->post('emp_nome_fantasia');
		$data['emp_numero']          = $this->input->post('emp_numero');
		$data['emp_cep']             = $this->input->post('emp_cep');
		$data['emp_bairro']          = $this->input->post('emp_bairro');
		$data['emp_cidade']          = $this->input->post('emp_cidade');
		$data['emp_uf']              = $this->input->post('emp_uf');
		$data['link_extratopgto']    = $this->input->post('link_extratopgto');
		$data['link_cartaconcessao'] = $this->input->post('link_cartaconcessao');
		$data['link_agendamento']    = $this->input->post('link_agendamento');
		
		if ($_FILES['doc_procuracao']['name']) { 
            
			$data['doc_procuracao'] = $this->doUpload('doc_procuracao');
        }
		
        if ($_FILES['doc_contrato']['name']) { 
        
			$data['doc_contrato'] = $this->doUpload('doc_contrato');
        } 
        
		$this->parametros->insert($data);
        $this->session->set_flashdata('success', 'Parametros adicionados com sucesso.');
        redirect('manage-parametros');
    }
    /*
    function for edit Parametros get
    returns  Parametros by id.
    created by your name
    created at 22-01-17.
    */
    public function editParametros($parametros_id) {
        $data['parametros_id'] = $parametros_id;
        $data['parametros'] = $this->parametros->getDataById($parametros_id);
        $this->load->view('parametros/edit-parametros', $data);
    }
    /*
    function for edit Parametros post
    created by your name
    created at 22-01-17.
    */
	public function update($id, Request $request)
	{
		try
		{
   		    $request->merge($this->retornaEnderecoBufferParams());
    	    
    		$parametros = Parametros::findOrFail($id);
    	
    		$input = $request->all();
    	
    	    if($request->hasFile('doc_procuracao')) {
        	    if ($request->file('doc_procuracao')->isValid())
        	       $input['doc_procuracao'] = UtilsController::getModeloDoc('doc_procuracao', $request->file('doc_procuracao'));
        		else
        			throw new Exception("O arquivo informado como Modelo de Procuração não é válido.");
    	    }
    	    
    	    if($request->hasFile('doc_contrato')) {    	    
        	    if ($request->file('doc_contrato')->isValid())
        	        $input['doc_contrato'] = UtilsController::getModeloDoc('doc_contrato', $request->file('doc_contrato'));
        		else
        			throw new Exception("O arquivo informado como Modelo de Contrato não é válido.");
    	    }
    		/*	
    	    if($request->hasFile('doc_requerimento')) {
        	    if ($request->file('doc_requerimento')->isValid())
        	        $input['doc_requerimento'] = UtilsController::getModeloDoc('doc_requerimento', $request->file('doc_requerimento'));
        		else
        			throw new Exception("O arquivo informado como Modelo de Contrato não é válido.");
    	    }
    		*/	
    	    if($request->hasFile('doc_declextincao')) {
        	    if ($request->file('doc_declextincao')->isValid())
        	        $input['doc_declextincao'] = UtilsController::getModeloDoc('doc_declextincao', $request->file('doc_declextincao'));
        		else
        			throw new Exception("O arquivo informado como Modelo de Declaração de Extinção não é válido.");
    	    }
    	    /*
    	    if($request->hasFile('doc_logoinss')) {
        	    if ($request->file('doc_logoinss')->isValid())
        	        $input['doc_logoinss'] = UtilsController::getModeloDoc('doc_logoinss', $request->file('doc_logoinss'));
        		else
        			throw new Exception("O arquivo informado como Modelo de Procuração não é válido.");
    		}
    		*/
    
    		$parametros->fill($input)->save();
    		Session::flash('flash_message', 'Configurações salvas com sucesso!');
    		return redirect()->back();
    		
		} catch (Exception $e) {
			Session::flash('flash_danger', $e->getMessage());
			return redirect()->back(); 
		}		
    }

   public function retornaEnderecoBufferParams()
   {
      if(isset($_COOKIE['endereco']) && 
         isset($_COOKIE['bairro']) && 
		 isset($_COOKIE['cidade']) && 
		 isset($_COOKIE['uf']))
   		return array('emp_endereco' => $_COOKIE['endereco'],
                     'emp_bairro' => $_COOKIE['bairro'],
					 'emp_cidade' => $_COOKIE['cidade'],
					 'emp_uf' => $_COOKIE['uf']);
	  else
   		return array('emp_endereco' => '',
                     'emp_bairro' => '',
					 'emp_cidade' => '',
					 'emp_uf' => '');
	  
   }	

}