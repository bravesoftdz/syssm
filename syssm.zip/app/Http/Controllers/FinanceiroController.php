<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Financeiro;
use Session;

class FinanceiroController extends Controller
{
	public function index()
	{
		if (\Auth::check())
		{
			$financeiro = Financeiro::all();
			
			return view('financeiro.index')->withFinanceiro($financeiro);
		}else
		{
			return view('pages.login');			
		}
	}

	public function create()
	{
		return view('financeiro.create');
	}
	
    public function update($id, Request $request)
    {
        try
        {        
            $financeiro = Financeiro::findOrFail($id);           
            //$this->validate($request, $this->validationRulesEdit);        
            $input = $request->all();            
            $financeiro->fill($input)->save();
				
            Session::flash('flash_message', 'Lançamento alterado com sucesso!');
           	return $this->index();
            
        } catch (Exception $e) {
            Session::flash('flash_danger', $e->getMessage());
            return redirect()->back()->withInput(); 
        }            
    }    

    public function store(Request $request)
    {
        try
        {            
            //$this->validate($request, $this->validationRules);
            $input = $request->all();
			
            $input['data'] = UtilsController::formatDate('d/m/Y', 'Y-m-d', $input['data']);    //converte para formato mySQL
			$input['valor'] = intval($input['valor']) / 100;
			$input['id_status'] = 3; //status pendente
            $input['id_user'] = \Auth::user()->id;            
            $inserted = Financeiro::create($input);
            
            //escreve na agenda a data do futuro recebimento/pagamento
            //if(AgendaController::insereLembreteBeneficiario($input)) 
            //{            
                Session::flash('flash_message', 'Lançamento efetuado com sucesso!');        
                return $this->index();
            //}

        } catch (Exception $e) {
            Session::flash('flash_danger', $e->getMessage());
            return redirect()->back()->withInput(); 
        }        
    }
	
	public function cancelar($id)
	{
		$financeiro = Financeiro::findOrFail($id);
		$financeiro->id_status = 2; /* CANCELADO */
		$financeiro->save();
		
		Session::flash('flash_message', 'Movimentação cancelada.');
		return redirect()->route('financeiro.index');
	}	
	
	public function confirmarLancamento($id)
	{
		$financeiro = Financeiro::findOrFail($id);
		if($financeiro->id_status == 2 /* CANCELADO */)
		{
			Session::flash('flash_message', 'Não é possível efetivar um lançamento cancelado.');
			return redirect()->back();
		}
		$financeiro->id_status = 4; /* EFETIVADO */
		$financeiro->save();
		
		Session::flash('flash_message', 'Lançamento efetivado.');
		return $this->index();
	
	}
}