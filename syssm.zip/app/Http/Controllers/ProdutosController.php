<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Produto;
use Session;

class ProdutosController extends Controller
{
	public function index()
	{
		if (\Auth::check())
		{
			$produtos = Produto::all();
			
			return view('produtos.index')->withProduto($produtos);
		}else
		{
			return view('pages.login');			
		}
	}

	public function create()
	{
		return view('produtos.create');
	}	

	public function show($id)
	{
		$produto = Produto::findOrFail($id);
	
		return view('produtos.show')->withProduto($produto);
	}
	
	public function edit($id)
	{
		$produto = Produto::findOrFail($id);
	
		return view('produtos.edit')->withProduto($produto);
	}	
	
	public function update($id, Request $request)
	{
		$produto = Produto::findOrFail($id);

		$this->validate($request, [		
	        'nome' => 'required',
    	    'preco_custo' => 'required',
        	'preco_venda' => 'required',
		]);
		
		$input = $request->all();	
        $input['id_user_alteracao'] = \Auth::user()->id;
		$produto->fill($input)->save();
	
		Session::flash('flash_message', 'Produto alterado com sucesso!');
	
		//return redirect()->back();
		return redirect()->route('produtos.index');
	}	
	
	public function store(Request $request)
	{
		$this->validate($request, [		
	        'nome' => 'required',
    	    'preco_custo' => 'required',
        	'preco_venda' => 'required',
		]);	
		
		$input = $request->all();
        $input['id_user_cadastro'] = \Auth::user()->id;	
		Produto::create($input);
		
        Session::flash('flash_message', 'Produto gravado com sucesso!');		
	
		//return redirect()->back();
		return redirect()->route('produtos.index');
	}
	
	public function destroy($id)
	{
		$produto = Produto::findOrFail($id);
	
		$produto->delete();
	
		Session::flash('flash_message', 'Exclusão efetuada com sucesso!');
	
		return redirect()->route('produtos.index');
	}	
}