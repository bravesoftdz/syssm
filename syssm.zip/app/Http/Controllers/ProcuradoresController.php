<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\UtilsController;
use App\Models\Procurador;
use Exception;
use Session;
use DB;

class ProcuradoresController extends Controller
{
	public function index()
	{
		if (\Auth::check())
		{
			$procuradores = Procurador::all();
			
			return view('procuradores.index')->withProcurador($procuradores);
		}else
		{
			return view('pages.login');			
		}
	}

	public function create()
	{
		return view('procuradores.create');
	}	

	public function show($id)
	{
		$procurador = Procurador::findOrFail($id);
	
		return view('procuradores.show')->withProcurador($procurador);
	}
	
	public function edit($id)
	{
		$procurador = Procurador::findOrFail($id);
	
		return view('procuradores.edit')->withProcurador($procurador);
	}	
	
	public function update($id, Request $request)
	{
		try
		{
			$request->merge(UtilsController::retornaEnderecoBuffer());
								  
			$procurador = Procurador::findOrFail($id);
	
			/*$this->validate($request, [		
					'nome' => 'required',
					'estadocivil' => 'required',
					'cpf' => 'required',
					'rg' => 'required',
					'profissao' => 'required',
					'nacionalidade' => 'required',
					'endereco' => 'required',
					'numero' => 'required',
					'complemento' => 'required',
					'bairro' => 'required',
					'cidade' => 'required',
					'uf' => 'required',
					'cep' => 'required',
			]);*/
			
			$input = $request->all();	
			$procurador->fill($input)->save();
		
			Session::flash('flash_message', 'Dados do Procurador alterados com sucesso!');
		
			//return redirect()->back();
			return redirect()->route('procuradores.index');
			
		} catch (Exception $e) {
			Session::flash('flash_danger', $e->getMessage());
			return redirect()->back()->withInput(); 
		}		
	}	
	
	private function existeCPF($cpf)
	{
		$procuradores = DB::select('select cpf from procuradores where cpf = :cpf ', ['cpf' => $cpf]);
		if(count($procuradores) > 0) {
			return True;
		}else
		{
			return False;
		}
		
	}	
	
	public function store(Request $request)
	{
		try
		{
			$this->validate($request, [		
					'nome' => 'required',
					'estadocivil' => 'required',
					'cpf' => 'required',
					'rg' => 'required',
					'profissao' => 'required',
					'nacionalidade' => 'required',
					'endereco' => 'required',
					'numero' => 'required',
					'complemento' => 'required',
					'bairro' => 'required',
					'cidade' => 'required',
					'uf' => 'required',
					'cep' => 'required',			
			]);	
			
			$input = $request->all();
			
			//validar CPF
			$cpf = str_pad($input['cpf'], 11, "0", STR_PAD_LEFT); //completando o CPF com zeros à esquerda
			
			if(!UtilsController::validaCPF($cpf)) {
				throw new Exception("O CPF informado é inválido.");
			} elseif($this->existeCPF($cpf)) {
				throw new Exception("O CPF informado está cadastrado.");
			} else
				$input['cpf'] = $cpf;			
			
			Procurador::create($input);
			Session::flash('flash_message', 'Procurador gravado com sucesso!');		
			//return redirect()->back();
			return redirect()->route('procuradores.index');
			
		} catch (Exception $e) {
			Session::flash('flash_danger', $e->getMessage());
			return redirect()->back()->withInput(); 
		}			
			
	}
	
	public function destroy($id)
	{
		$procurador = Procurador::findOrFail($id);
	
		$procurador->delete();
	
		Session::flash('flash_message', 'Exclusão efetuada com sucesso!');
	
		return redirect()->route('procuradores.index');
	}	
}