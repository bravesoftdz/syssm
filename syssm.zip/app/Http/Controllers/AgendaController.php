<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Agenda;
use App\Models\Beneficiario;
use App\Models\Evento;
use Session;
use DateTime;
use DB;

class AgendaController extends Controller
{
	public function index()
	{
		if (\Auth::check())
		{
			//$agenda = Agenda::all();
			$agenda = Agenda::where('ativo', '=', 'S')->get();
			
			return view('agenda.index')->withAgenda($agenda);
		}else
		{
			return view('pages.login');			
		}
	}
	
	public function desativarLembrete(Request $request)
	{	
		$input = $request->all();

		$reg = Agenda::findOrFail($input['eventId']);
		$reg->ativo = 'N';
		$reg->save();
		
        Session::flash('flash_message', 'Este lembrete não será mais exibido.');		
		
		/*refresh na tela de agenda */
		//$agenda = Agenda::all();
		$agenda = Agenda::where('ativo', '=', 'S')->get();
		
		return view('agenda.index')->withAgenda($agenda);
	}

	public static function insereLembrete($nome_evento, $desc_evento, $tipo_evento, $dt_evento, $link) {
       
		try
		{
			//cadastrar requerimento		
			$agenda = new Agenda;
			$agenda->evento = $nome_evento;
			$agenda->descricao = $desc_evento;
			$agenda->id_tipo_evento = $tipo_evento; //1=Sucesso // 2=Informação // 3=Aviso // 4=Erro
			$agenda->dt_evento = $dt_evento;
			$agenda->dt_inicio_lembrete = $dt_evento;
			$agenda->dt_expiracao_lembrete = $dt_evento->modify('+1 month'); //lembretes válidos por 1 mês
			$agenda->ativo = 'S';	
			$agenda->link = $link;	
			$agenda->save();			
			return True;
			
		} catch (Exception $e) {
			throw $e;
			return False;
		}
	}
	
	private static function formataDescricaoAgenda($input)
	{
	   $array_search = ['[NOME_BENEFICIARIO]',
	                    '[NUMERO_CONTRATO]',
	                    '[DT_PG_BENEFICIO]',
	                   ];
	   $array_fields = ['nome',
	                    'protocolo_interno',
	                    'dt_pagto_beneficio',
	                    ];
	   $array_replace = array();                 
	   foreach($array_fields as $field)
	   {
	       if(isset($input[$field]))
	         array_push($array_replace, $input[$field]);
	       else
	         array_push($array_replace, '?????');
	   }

	   return str_ireplace($array_search, $array_replace, $evento->template_descricao); 
	}
	
	private static function insereLembreteBeneficiario(array $input) {

		try
		{
			$dt_evento = new DateTime();
		/*
		$dt_evento = DateTime::createFromFormat('Y-m-d H:i:s', $input['dt_evento']);
			$evento = Evento::findOrFail($input['id_evento']);
			
			//drop evento id_tipo_evento
			/*
			o input deve conter:
			[id do Evento]
			[Data do evento]
			[Codigo Beneficiario]
			[Nome Beneficiario]
			{opcional}[Codigo Contrato]
			{opcional}[Data pagto Benefício]
		
			//cadastrar requerimento		
			$agenda = new Agenda;
			$agenda->id_evento = $evento->id;
			$agenda->descricao = AgendaController::formataDescricaoAgenda($input);
			$agenda->dt_evento = $dt_evento;
			$agenda->dt_inicio_lembrete = $dt_evento;
			$agenda->dt_expiracao_lembrete = $dt_evento->modify('+1 month'); //lembretes válidos por 1 mês
			$agenda->link = $input['link'];
			$agenda->ativo = 'S';		
			$agenda->save();
				*/
			//imprimir contrato
			$agenda = new Agenda;
			$agenda->evento = 'Impressão de Contrato';
			$agenda->descricao = 'Necessário imprimir o Contrato do Beneficiário ' . $input['nome'];
			$agenda->id_tipo_evento = 3; //1=Sucesso // 2=Informação // 3=Aviso // 4=Erro
			$agenda->dt_evento = $dt_evento;
			$agenda->dt_inicio_lembrete = $dt_evento;
			$agenda->dt_expiracao_lembrete = $dt_evento->modify('+1 month'); //lembretes válidos por 1 mês
			$agenda->link = $input['link'];
			$agenda->ativo = 'S';		
			$agenda->save();
				
			//imprimir termo de Responsabilidade
			$agenda = new Agenda;
			
			if(UtilsController::procuracaoPadraoINSS())
			{
				$agenda->evento = 'Impressão da Procuração';
				$agenda->descricao = 'Necessário imprimir a Procuração do Beneficiário ' . $input['nome'];
			}
			else
			{
				$agenda->evento = 'Impressão do Termo de Responsabilidade';
				$agenda->descricao = 'Necessário imprimir o Termo de Responsabilidade do Beneficiário ' . $input['nome'];			
			}
			$agenda->id_tipo_evento = 3; //1=Sucesso // 2=Informação // 3=Aviso // 4=Erro
			$agenda->dt_evento = $dt_evento;
			$agenda->dt_inicio_lembrete = $dt_evento;
			$agenda->dt_expiracao_lembrete = $dt_evento->modify('+1 month'); //lembretes válidos por 1 mês
			$agenda->link = $input['link'];
			$agenda->ativo = 'S';		
			$agenda->save();
			
			return True;
		} catch (Exception $e) {
			throw $e;
			return False;
		}		
	}

	public static function insereLembreteAgendamento(array $input) {
		
		try
		{
			
			
			$agenda = new Agenda;
			$agenda->evento = 'Agendamento de Perícia pendente';
			$agenda->descricao = 'Necessário agendar a perícia do contrato n° ' . $input['protocolo_interno'];
			$agenda->id_tipo_evento = 3; //1=Sucesso // 2=Informação // 3=Aviso // 4=Erro
			$agenda->dt_evento = $dt_evento;
			$agenda->dt_inicio_lembrete = $dt_evento;
			$agenda->dt_expiracao_lembrete = $dt_evento->modify('+1 month'); //lembretes válidos por 1 mês
			$agenda->link = $input['link'];
			$agenda->ativo = 'S';		
			$agenda->save();			
			return True;
			
		} catch (Exception $e) {
			throw $e;
			return False;
		}		

	}	
		
	public static function insereLembretePagamento(array $input) {
		
		try
		{
			//cadastrar lembrete de pagamento
			$dt_evento = \DateTime::createFromFormat('d/m/Y', $input['dt_pagto_beneficio']);
			
			$agenda = new Agenda;
			$agenda->evento = 'Pagamento de Benefício';
			$agenda->descricao = 'O pagamento do contrato n° ' . $input['protocolo_interno'] . ' foi programado para ' . $input['dt_pagto_beneficio'];
			$agenda->id_tipo_evento = 2; //1=Sucesso // 2=Informação // 3=Aviso // 4=Erro
			$agenda->dt_evento = $dt_evento;
			$agenda->dt_inicio_lembrete = $dt_evento;
			$agenda->dt_expiracao_lembrete = $dt_evento->modify('+1 month'); //lembretes válidos por 1 mês
			$agenda->link = $input['link'];
			$agenda->ativo = 'S';		
			$agenda->save();			
			return True;
			
		} catch (Exception $e) {
			throw $e;
			return False;
		}		

	}	
	
	public static function desativaLembrete($evento, $id_beneficiario) {
		
		try
		{
			$sql = 'select * from agenda '.
				   ' where UPPER(evento) = UPPER(:evento) '.
				   '   and UPPER(descricao) like CONCAT("%", UPPER(:nome), "%") '.
				   '   and ativo = "S"';
			
			$beneficiario = Beneficiario::findOrFail($id_beneficiario);		
			$arrayLembretes = DB::connection()->select($sql, ['evento' => $evento, 'nome' => $beneficiario->nome]);
			
			foreach($arrayLembretes as $agenda)
			{	
				$upd_agenda = Agenda::findOrFail($agenda->id);
				$upd_agenda->ativo = 'N';
				$upd_agenda->save();
			}
			return True;
		
		} catch (Exception $e) {
			throw $e;
			return False;
		}		
		
	}	
	
/*
Agendamento pendente
O Agendamento do beneficiário Maria José das Couves (Req. #0000000006) está pendente. Favor verificar.
id_tipo_evento = 3	
*/	
}