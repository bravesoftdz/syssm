<?php

namespace App\Http\Middleware;

use Closure;
use Config;
use DB;
use App;
use Illuminate\Support\Facades\URL;

class SetGlobals
{

	private function execute()
	{
		$usuario_tipo_perfil = 2;
		
		//executado a cada mudança de tela
		if(\Auth::check()) {
			
			Config::set('globals.id_usuario', \Auth::user()->id);
			Config::set('globals.nome_usuario', \Auth::user()->nome_funcionario);
			
			$dadosusuario = DB::connection()->select('select * from users where id = :id', ['id' => Config::get('globals.id_usuario')]);
			foreach ($dadosusuario as $usuario)
			{
			    $usuario_tipo_perfil = $usuario->id_tipo_perfil;
				Config::set('globals.usuario_admin',      $usuario->id_tipo_perfil == 0);
				Config::set('globals.usuario_gerente',    $usuario->id_tipo_perfil == 1);	
				Config::set('globals.usuario_ger_ou_adm', Config::get('globals.usuario_admin') || Config::get('globals.usuario_gerente'));
			}
		}
		
		//executa apenas uma vez
		if(!Config::get('globals.initialize_params')) {

			$parametros = DB::connection()->select('select * from parametros where id = :id', ['id' => 1]);
			foreach ($parametros as $parametro)
			{
				Config::set('globals.nome_empresa',        $parametro->emp_nome_fantasia);
				Config::set('globals.tipo_impressao_relatorio', $parametro->tipo_impressao_relatorio);
			}	
		
			//depois pensar em melhorar isso...
			Config::set('globals.id_perfil_admin', 0); 
			Config::set('globals.id_perfil_gerente', 1);
			Config::set('globals.id_perfil_funcionario', 2);
			
			//array com os tipos de perfil para combo lookup
			$arrayTipo_perfil = [];
			$tipos_perfil = DB::connection()->select('select id, nome from tipo_perfil');
			foreach($tipos_perfil as $tipo_perfil):
				$arrayTipo_perfil[$tipo_perfil->id] = $tipo_perfil->nome; 
			endforeach;	
			Config::set('globals.array_tipo_perfil', $arrayTipo_perfil);
		
			/*
			$array_tipo_movimento = [];
			$lista_tipomov = DB::connection()->select('select * from tipo_movimento');
			foreach ($lista_tipomov as $mov)
			{
			    $array_tipo_movimento[$mov->id] = $mov->descricao;
			}	
			Config::set('globals.array_tipo_movimento', $array_tipo_movimento);					
			
			
			//lista de históricos financeiros
			$array_tipo_historico = [];
			$lista_tipohist = DB::connection()->select('select * from historicos');
			foreach ($lista_tipohist as $hist)
			{
			    $array_tipo_historico[$hist->id] = $hist->descricao;
			}	
			Config::set('globals.array_tipo_historico', $array_tipo_historico);					
			*/
			
			//configurações do ambiente
			$debug_mode = env('APP_DEBUG', false);
			
			$array_url_css_navbar = array(1 => URL::asset('css/navbar.css'), //1
			                              2 => URL::asset('css/navbar2.css') //2
									      );
									   
			$array_url_css_loginmodal = array(1 => URL::asset('css/loginmodal.css'), //1
			                                  2 => URL::asset('css/loginmodal2.css'), //2
											 );
			
			$logo_sistema = '';
			$css_template = 1; //default: 1
			$titulo_sistema = 'SysSM - Controle de Estoque';
			$configs = DB::connection()->select('select * from configuracoes where id = :id', ['id' => 1]);
			foreach ($configs as $config)
			{				
				if(App::environment('local')) {
					$logo_sistema = $config->logo_producao;
				} else {
					$logo_sistema = $config->logo_homologacao;
				}
				
				$css_template = $config->css_template;
				$titulo_sistema = $config->titulo_sistema;
				
			}	
			Config::set('globals.logo_sistema', $logo_sistema);		
			Config::set('globals.url_css_navbar', $array_url_css_navbar[$css_template]);
                        Config::set('globals.url_css_loginmodal', $array_url_css_loginmodal[$css_template]);
 			
			//confirma inicialização
			Config::set('globals.initialize_params', True);
		}
	}	

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $this->execute();	

        return $next($request);
    }
}
