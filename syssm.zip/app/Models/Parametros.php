<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Parametros extends Model {
    /**
     * Fillable fields
     * 
     * @var array
     */
    protected $fillable = [
		'emp_razao_social',
		'emp_cnpj',
		'emp_endereco',
		'emp_complemento',
		'emp_nome_fantasia',
		'emp_numero',
		'emp_cep',
		'emp_bairro',
		'emp_cidade',
		'emp_uf',
		'par_val_salmin',
		'link_extratopgto',
		'link_cartaconcessao',
		'link_agendamento',
		'doc_procuracao',
		'doc_contrato',
		'tipo_impressao_relatorio'
    ];
}

