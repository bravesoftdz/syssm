<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\TipoMovimento;
use App\Models\Historico;
use App\Models\User;

class Financeiro extends Model {

	protected $table = 'movimento_financeiro';
	
    /** 
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'id_tipo_movimento',
		'data', 
		'id_historico', 
		'valor', 
		'documento_original', 
		'id_status',
		'id_user'
    ];
	
	public function valor_formatado()
	{	
		return number_format($this->valor, 2, ',', '.');
	}	
	
	/*
		1	Novo
		2	Cancelado
		3	Pendente
		4	Efetivado
	*/	
	
	public function movimentoAberto()
	{
		$statusAberto = array(/*1 /-*Novo*-/, */3 /* pendente */);
		return (in_array($this->id_status, $statusAberto));
	}
	
	public function movimentoCancelado()
	{
		return ($this->id_status == 2 /* Cancelado */);
	}
	
	public function tipoMovimento()
	{	
		return $this->hasOne('App\Models\TipoMovimento', 'id', 'id_tipo_movimento');
	}		

	public function historico()
	{	
		return $this->hasOne('App\Models\Historico', 'id', 'id_historico');
	}		
	
	public function status()
	{	
		return $this->hasOne('App\Models\StatusMovimentoFinanceiro', 'id', 'id_status');
	}
		
	public function user()
	{	
		return $this->hasOne('App\Models\User', 'id', 'id_user');
	}	
		
	public function getDates()
	{
		return ['data'];
	}		

}

