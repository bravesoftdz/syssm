<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Configuracao extends Model {

    protected $table = 'configuracoes';
	 
    protected $fillable = [
		'logo_producao',
		'logo_homologacao',
		'css_template',
		'loginCliPorContrato',
		'modelo_contrato',
    ];
}

