<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\User;

class Produto extends Model {
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'nome',
        'resumo',
        'codbarras',
        'preco_custo',
        'preco_venda',
        'estoque_minimo',
        'id_user_cadastro',
        'id_user_alteracao',
    ];
	
	public function usuarioCad()
	{	
		return $this->hasOne('App\Models\User', 'id', 'id_user_cadastro');
	}		

	public function usuarioAlt()
	{	
		return $this->hasOne('App\Models\User', 'id', 'id_user_alteracao');
	}		
	
}

