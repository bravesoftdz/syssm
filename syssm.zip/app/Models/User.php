<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;
use App\Models\TipoPerfil;

class User extends Authenticatable
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['name', 
	                       'email', 
						   'password', 
						   'nome_funcionario', 
						   'id_tipo_perfil', 
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];
	
	public function tipoperfil()
	{	
		return $this->hasOne('App\Models\TipoPerfil', 'id', 'id_tipo_perfil');
	}

}
