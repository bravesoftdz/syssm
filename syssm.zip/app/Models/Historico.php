<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Historico extends Model {

	//protected $table = 'historicos';
	
    /** 
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'descricao'
    ];	

}

