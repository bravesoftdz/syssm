<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Evento extends Model {
	
	protected $table = 'eventos';
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
		'descricao', 
		'id_tipo_evento',
		'template_descricao',
		'template_link',
		'prazo',
		'ativo',
    ];

/*
	descricao	varchar(255)
	id_tipo_evento	int(11)
	template_descricao	varchar(255)
	template_link	varchar(255)
	prazo	varchar(30)	
*/
	
	public function getDates()
	{
		return ['created_at', //default
		        'updated_at', //default
				];
	}	
	
	public function tipoEvento()
	{	
		return $this->hasOne('App\Models\TipoEvento', 'id', 'id_tipo_evento');
	}	
	
}