<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TipoMovimento extends Model {

	protected $table = 'tipo_movimento';
	
    /** 
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'descricao',
		'natureza'
    ];	

}

