<html>

<head>
	<title>CONTRATO DE PRESTA��O DE SERVI�OS</title>
</head>

<body>

	<div>
		<p align="center">
			<b><u>CONTRATO DE PRESTA��O DE SERVI�OS</u></b>
		</p>
	</div>
	
	<p align="justify">
		<b><u>CONTRATANTE:</u></b> <strong>[nomeBeneficiario]</strong><br>
		<b>RG:  [numeroRG]</b><br>
		<b>CPF:  [numeroCPF]</b><br>
		<b>DATA DE NASCIMENTO: [dataNascimento]</b><br>
		<b>RUA:�[endRua]�������������������������������� N� [endNumero]</b><br>
		<b>BAIRRO: [endBairro]�����������������CEP: [endCEP]������� Cidade:�[endCidade]��UF: [endUF]</b><br>
		<b>GRAU DE ESCOLARIDADE: [grauEscolaridade]</b><br>
		<b>FONE: [telefone]</b><br><br>
	</p>
	
	<p align="justify">
		<b><u>CONTRATADA</u>: L�DER CONSULTORIA LTDA, inscrita no CNPJ No. 24.808.811/0001-81, com sua sede Rua Jos� de Alvarenga, 394, sobreloja sala 5, Centro, Duque de Caxias/RJ, CEP: 25.020-140 e filiais� (Nova Igua�u) Avenida Governador Amaral Peixoto, 130, 8� andar, sala 801, Centro de Nova Igua�u/RJ, CEP 26.210-060; - (Rio de Janeiro) Avenida Presidente Vargas, 633, 11 andar, sala 1121, Centro, Rio de Janeiro/RJ, CEP 20.071-003; �- (Niter�i) Rua da Concei��o, 13, sala 308, 3�andar, Centro Niter�i/RJ, CEP 24.020-084, � (Campo Grande) Rua Campo Grande, 1014, sala 322, 5 andar, Centro, Campo Grande/RJ, CEP 23.080-000 �neste ato representada por quem de direito, doravante denominada simplesmente de CONTRATADA.</b>
		<br>
		<br>
	</p>
	
	<p align="justify">
		<b>As partes acima identificadas t�m entre si justas e acertadas o presente contrato, que ser� regido pelas seguintes cl�usulas: </b>
		<br>
		<br>
	</p>
	
	<p align="center">
		<b><u>OBJETO</u></b>
	</p>
	
	<p align="justify">
		<b>CL�USULA PRIMEIRA:</b> A<b> CONTRATADA</b> se obriga a prestar ao <b>CONTRATANTE</b> seus servi�os profissionais, com zelo e dedica��o, na defesa de seus direitos e interesses, cuja extens�o destes se refere a direitos mantidos pela autarquia, a fim de oportunizar os recebimentos de valores, aproximadamente equivalentes � m�dia aritm�tica simples das �ltimas 12 (doze) remunera��es do segurado, oficialmente obtidas em virtude do �ltimo contrato de emprego, tendo como par�metro o m�ltiplo de 4 (quatro), ter� o recebimento das quantias devidas , ficando ciente do dep�sito do valor a ser liberado pela Autarquia; ressalvada, entretanto, eventual mudan�a de legisla��o ou ordens normativas.
	</p>
	
	<p align="justify">
		<b>Par�grafo Primeiro:</b>A <b>CONTRATADA</b> representar� o <b>CONTRATANTE </b>perante �rg�os p�blicos (Reparti��es Federais, Estaduais, Municipais e outros) ou Privados, mediante procura��o com firma reconhecida por autenticidade em cart�rio de notas, sempre em conformidade com o servi�o para o qual foi contratado.
	</p>
	
	<p align="justify">
		<b>Par�grafo Segundo:</b> Fica vedado a <b>CONTRATADA</b> propor ou responder demandas al�m do previsto no <i>caput</i> desta Cl�usula, bem como atuar em desconformidade com os poderes que lhe foram outorgados, sem que haja pr�via autoriza��o expressa do <b>CONTRATANTE</b>.
		<br>
		<br>
	</p>
	
	<p align="center">
		<b><u>DAS OBRIGA��ES:</u></b>
	</p>
	
	<p align="justify">
		<b>CL�USULA SEGUNDA:</b> A <b>CONTRATADA</b> tem obriga��o de dedicar seus melhores esfor�os na presta��o dos servi�os contratados. Por�m, a <b>CONTRATANTE</b> fica desde j� ciente de que a presta��o de servi�o de intermedia��o � uma atividade de meio, e n�o de resultado, de modo que n�o � poss�vel garantir o �xito favor�vel ao <b>CONTRATANTE</b> no final da demanda.
	</p>
	
	<p align="justify">
		<b>Par�grafo Primeiro:</b> A <b>CONTRATADA</b> obriga-se a tratar como mat�ria sigilosa e confidencial todas as informa��es administrativas, comerciais ou de qualquer natureza que lhe forem fornecidas pelo(a) <b >CONTRATANTE</b>, com a ressalva do que for necess�rio para fundamentar pedidos e notifica��es, zelando pelo sigilo destas informa��es durante e ap�s o t�rmino da presta��o dos servi�os.
	</p>
	
	<p align="justify">
		<b>CL�USULA TERCEIRA:</b><u>O <b>CONTRATANTE</b> dever� informar a <b>CONTRATADA</b>, no ato da assinatura do presente, se j� recebeu algum benef�cio ou encontra-se recebendo-o, tais como: <b>Licen�a-Maternidade, Sal�rio Maternidade, Auxilio Maternidade, Sal�rio Natalidade ou outros de mesma natureza;</b> a qual firmar� declara��o competente; evitando-se com isso a cobran�a repetit�ria do direito aqui requerido. </u>
	</p>
	
	<p align="justify">
		<u><b>Par�grafo �nico:</b> Fica desde j� pactuado que os honor�rios pelos servi�os ora prestados, prevalecer�o mesmo em caso de diversidade de informa��es prestadas pelo <b>CONTRATANTE</b>.</u>
	</p>
	
	<p align="justify">
		<b>CL�USULA QUARTA:</b> A <b>CONTRATADA</b>s� poder� devolver os documentos originais ou prestar informa��es da <b>CONTRATANTE</b> a terceiros ou a parentes, devendo-se observar o seguinte:
		<blockquote>
			<ul>
				<li>A) Em caso de �bito o mesmo se dar� mediante apresenta��o de c�pia da certid�o de �bito autenticada;</li>
				<li>B) Na hip�tese de tratamento m�dico, no qual esteja impossibilitada de se locomover, conforme laudo m�dico, ficando assim vedado passar informa��es da <b>CONTRATANTE</b>a terceiros ou parentes.</li>
			</ul>
		</blockquote>
	</p>


<p align="justify">
<b>CL�USULA QUINTA:</b>A <b>CONTRATANTE</b> fica ciente que em
nenhuma hip�tese poder� receber valores decorrentes dos servi�os aqui
prestados, atrav�s de representa��o de terceiros, assim compreendidos: 

conjugue parentes, amigos, dentre outros; sendo
certo  
'>que
este direito somente poder� ser exercido atrav�s do acompanhamento de um
respons�vel indicado pela ora <b> 
;
color:black;mso-themecolor:text1'>CONTRATADA</b> 

mso-fareast-Arial;color:black;mso-themecolor:text1;mso-bidi-font-weight:
bold'>, conforme assim preceituam a <b>Cl�usula</b><b> 
'>
Vig�sima Primeira</b> 
;
color:red;mso-bidi-font-weight:bold'> <b> 

Par�grafo, Primeiro e Segundo da</b>

mso-fareast-Arial;color:red;mso-bidi-font-weight:bold'> <b
> 

Cl�usula Vig�sima Primeira.</b></p>

<p
> 

mso-fareast-Arial;color:red'></p>

<p
><b >

'>CL�USULA SEXTA:
</b> 
'>Caso
a<b >  '>CONTRATANTE
</b>esteja em cust�dia da justi�a, somente os advogados habilitados com
procura��o com firma reconhecida e v�lida, os quais poder�o ter acesso �s
informa��es e obter c�pia dos documentos anexa ao procedimento administrativo
competente, mediante, ainda a comprova��o da cust�dia de seu constituinte.� </p>

<p
> 

</p>

<p
><b >

'>CL�USULA SETIMA:
</b> 
'>A
<b >CONTRATANTE</b> dever� se dirigir ao
escrit�rio da<b > CONTRATADA</b> munida de
seus documentos pessoais originais (Rg, Cpf, comprovante de resid�ncia e, em
caso de casado, certid�o de casamento), sempre em hor�rio a ser previamente agendado
para obter o extrato e a libera��o do pagamento,<b> </b>juntamente com todos os documentos originais por ela deixados,
mesmo que tenha recebido qualquer correspond�ncia da autarquia, 
color:black;mso-themecolor:text1'>conforme assim disp�e na <b
>Cl�usula Vig�sima. color:red'> </b></p>

<p
> 

mso-fareast-Arial;color:red'></p>

<p
><b >

'>CL�USULA OITAVA</b><b>

: </b>  font-size:
12.0pt;mso-fareast-
A <b>CONTRATADA </b>devolver� a nota promiss�ria, hora emitida e assinada
pela <b >CONTRATANTE</b>, conforme se refere<b>
</b> mso-bidi-font-weight:bold'>o disposto no<b
> color:#0070C0'> Par�grafo
Primeiro e Segundo da Cl�usula D�cima Sexta</b> ;
mso-bidi-font-weight:bold'>, devolu��o esta que se dar� no ato do
pagamento dos honor�rios aqui pactuados neste contrato; excetuando-se a
hip�tese da<b> CONTRATANTE</b> omitir o que j� efetivamente recebeu, tais como:
<b><u>Licen�a-Maternidade, Sal�rio Maternidade, Auxilio Maternidade, Sal�rio Natalidade;</u>
</b></p>

<p
><b >

;color:#0070C0'></b></p>

<p
><b >

'>CL�USULA NONA</b><b
> 
'>:</b><u>

 A <b >CONTRATANTE
</b>fica ciente que os documentos havidos em xerox autenticada, assim como a o
instrumento de procura��o por esta deixada, ficar�o anexados e arquivados no
procedimento administrativo junto � autarquia.</u><b> 
'></b></p>

<p
><b >

'>CL�USULA D�CIMA</b><b
> 
'>:</b>

mso-fareast-Arial;'> A

 <b>CONTRATANTE</b> '>
se obriga a fornecer todos elementos necess�rios � defesa de seus direitos, 
mso-bidi-font-weight:bold'>conforme assim preceituam o <b>
background:red;mso-highlight:red'>Par�grafo Terceiro</b><b
> background:red;mso-highlight:
red'> Cl�usula Vig�sima Quarta</b> background:red;
mso-highlight:red;mso-shading:white'> <b >�e a letra � do </b><b> background:red;mso-highlight:red'>Par�grafo Primeiro
mso-shading:white'> da Cl�usula Vig�sima Quinta</b>
background:red;mso-highlight:red'>, assim como os 
'>documentos originais ess�ncias ao procedimento
administrativo, sendo estes: <b>Carteira Profissional, Rescis�o Contratual e
Seguro Desemprego</b> mso-bidi-font-weight:bold'>, assim xerox
autenticada dos mesmos; comprometendo-se a cumprir as instru��es que lhes forem
dadas a cada etapa pela <b>CONTRATADA.</b></p>

<p
><b> 
;
'></b></p>

<p
><b> 
;
'>Par�grafo �nico:</b>  font-size:
12.0pt;mso-fareast-
 Tendo em vista que durante a demanda  mso-bidi-font-weight:
bold'>haver� uma ou mais audi�ncias administrativas para periciar os documentos,
poder� o Agente P�blico requerer informa��es ou constatar a veracidade
das informa��es prestadas, para cujos atos ser�o instru�dos dos documentos
originais correspondentes<b>.</b><b > </b></p>

<p
><b >

</b></p>

<p
><b >

'>CL�USULA D�CIMA
PRIMEIRA:</b><b> line-height:
125%;'> </b>

mso-fareast-Arial;mso-bidi-font-weight:bold'>Considerando que
durante o procedimento administrativo o �rg�o P�blico venha a necessitar da
apresenta��o do original da Carteira Profissional de Trabalho para fins de certificar
a autenticidade das c�pias apresentadas, a <b>CONTRATADA </b>solicitara para a<b>
CONTRATANTE </b>o referido documento, que hora deixara voluntariamente de posse
da mso-spacerun:yes'>� <b>CONTRATADA</b> para que fique em
seu poder, at� o termino da demanda conforme assim lhe autorizam a Instru��o
Normativa 77/2015,  line-height:
125%;'>c

'>onforme assim
disp�e no<b> 
>
Par�grafo P</b><b > 

rimeiro </b>

'>e<b>

 Segundo</b> 

 mso-spacerun:yes'>� da <b
>Cl�usula Vig�sima Quarta</b>.</p>

<p
> 
;
mso-bidi-font-weight:bold'></p>

<p
><b> 
;
'>Par�grafo �nico: </b> 

mso-fareast-Arial;;mso-bidi-font-weight:bold'>Declara
a <b>CONTRATANTE</b> line-height:
125%;;mso-bidi-font-weight:
bold'> que este ato � de sua plena e irrevog�vel concord�ncia, a qual, para os
devidos fins de direito, permite e concorda em deixa-lo em poder da ora <b>CONTRATADA</b>
at� que terminem todas as etapas do procedimento administrativo. Findo o
procedimento, a <b>CONTRATADA</b> se obriga a devolver a <b>CONTRATANTE</b> o
original da Carteira Profissional de Trabalho, 

 conf

mso-fareast-Arial;mso-bidi-font-weight:bold'>orme as regras
estabelecidas n line-height:
125%;'>o <b>Par�grafo
Primeiro </b><b >e segundo da Cl�usula
Vig�sima Quarta mso-bidi-font-weight:bold'>,</b>
mso-bidi-font-weight:bold'> mediante assinatura de Termo de Reten��o e Restitui��o<b>.</b></p>

<p
> 
'></p>

<p
><b >

'>CL�USULA D�CIMA
SEGUNDA:</b><b> line-height:
125%;'> </b>

mso-fareast-Arial;mso-bidi-font-weight:bold'>Caso venha a ocorrer o
recebimento de alguma correspond�ncia da autarquia concessora, a<b> CONTRATANTE
</b>dever� levar imediatamente ao conhecimento da <b>CONTRATADA </b>a
exist�ncia desta, bastando para tanto que se dirija ao escrit�rio desta, independentemente
do que estiver escrito no corpo da respectiva correspond�ncia, observando-se
para tanto  
>as
instru��es procedimentais dadas pela <b> 

CONTRATADA </b> 

mso-fareast-Arial;mso-bidi-font-weight:bold'>em conformidade com a
letra (<b>a</b>) do <b >

Par�grafo Primeiro da Cl�usula Vig�sima Quinta.</b>

</p>

<p
'><b ><u> 

mso-fareast-'>DO PRAZO DE VIGENCIA</u></b><b
><u> 
'></u></b></p>

<p
><b >

</b></p>

<p
><b >

CL�USULA D�CIMA TERCEIRA: </b>

O prazo para t�rmino dos servi�os aqui
contratados � de 60 (sessenta dias) �teis, cujo prazo vigorar� no ato da
assinatura do presente contrato, ou do  

in�cio da data da entrega 

dos documentos estabelecidos neste contrato, o
que primeiro ocorrer; tudo conforme<b >

'> </b>

'>estabelece <b
>Par�grafo Segundo da </b><b
> 
'>Cl�usula
D�cima Terceira. mso-bidi-font-weight:bold'></b></p>

<p
><b> 
'>Par�grafo
Primeiro: </b> 
;mso-bidi-font-weight:
bold'>D 
'>entro do prazo estabelecido
no <i mso-bidi-font-style:normal'>caput</i> deste artigo, poder� haver haver�
audi�ncias administrativas para fins de realiza��o de per�cia dos documentos
deixados pela <b >CONTRATANTE. </b></p>

<p
><b >

</b></p>

<p
><b> 
'>Par�grafo
Segundo: </b> 
'>A <b>CONTRATANTE
</b>fica ciente<b> </b>que o prazo estabelecido no <i mso-bidi-font-style:
normal'>caput</i><b>, </b>poder� ser prorrogado de forma autom�tica e por lapso
de tempo indeterminado, nas seguintes hip�teses: </p>

<p
> 
'></p>

<p CxSpFirst margin-bottom:8.0pt;mso-add-space:
auto;text-indent:-.25in;
l2 level1 lfo3'><!>

 '>a)
 '>&nbsp;&nbsp;&nbsp; <![endif]>

No caso de existir greve dos funcion�rios e
servidores da autarquia;</p>

<p CxSpMiddle margin-bottom:8.0pt;mso-add-space:
auto;text-indent:-.25in;
l2 level1 lfo3'><!>

 '>b)
 '>&nbsp;&nbsp;&nbsp; <![endif]>

Para cumprir exig�ncias de documentos requeridas
pela autarquia;</p>

<p CxSpLast margin-bottom:8.0pt;mso-add-space:
auto;text-indent:-.25in;
l2 level1 lfo3'><!>

 '>c)
 '>&nbsp;&nbsp;&nbsp; <![endif]>

Greve banc�ria ou quaisquer outros motivos de
caso fortuito ou for�a maior que determine a extens�o dos prazos aqui
estabelecidos.</p>

<p
><b >

</b></p>

<p
><b >

CL�USULA D�CIMA QUARTA</b><b
> 

: </b>  font-size:
12.0pt;
Na falta de algum documento estabelecido neste
contrato, o <b >CONTRATANTE </b>ficar�
ciente que o prazo previsto na <b >Cl�usula D�cima
Terceira </b>ser� alterado e suspenso, e s� ter� rein�cio a partir da data da
entrega dos mesmos, se estendendo tamb�m para no caso de contratantes gestantes
em fase gestacional.<b > </b></p>

<p
><b >

CL�USULA D�CIMA QUINTA</b><b
> 

: </b>  font-size:
12.0pt;
A <b >CONTRATANTE
</b>fica ciente<b > </b>que ap�s an�lise
documental feita pela <b >CONTRATADA,</b> esta
fica autorizada a no prazo de 48(quarenta e oito horas) h
'>abilitar � per�cia junto � Autarquia, bem como a dar continuidade
a demanda no qual foi contratado, em conformidade com a <b>Cl�usula Primeira e </b><b >Par�grafo
Primeiro '> da Cl�usula Primeira
color:red'>. </b></p>

<p
><b >

;color:red;
'></b></p>

<p
><b >

'>Par�grafo Primeiro</b>

'>: Dentro do
prazo de 48 horas a <b >CONTRATANTE</b>
poder� cancelar a seu nuto o seu procedimento administrativo, mediante pr�vio pagamento
de uma taxa no valor de R$100,00 (Cem Reais), al�m dos valores correspondentes
as despesas e emolumentos cartor�rios (ex.: Xerox autenticadas, assinatura por
autenticidade,  mso-spacerun:yes'>�abertura de firma e outros).</p>

<p
> 

</p>

<p
><b >

'>Par�grafo Segundo:</b>

'> Ultrapassado o
prazo de 48 horas estabelecido no <i mso-bidi-font-style:normal'>caput</i>,
este instrumento somente poder� ser revogado, mediante o pagamento do valor da
nota promiss�ria a que se refere no  font-size:
12.0pt;mso-fareast-
Arial;mso-bidi-font-weight:bold'> Par�grafo Primeiro 

 da Cl�usula D�cima Sexta.
color:red></p>

<p
'><b > 

mso-fareast-Arial>DOS
HONOR�RIOS:</b><b > 

</b></p>

<p
><b >

'></b></p>

<p
><b >

'>CL�USULA D�CIMA
SEXTA: </b> 

Pelos servi�os aqui pactuados, a<b >
CONTRATANTE</b> color:red'> se obriga a pagar a <b
>CONTRATADA</b> o valor equivalente a <b
>30%</b> <b>(trinta por cento)</b> do valor l�quido liberado, que poder� variar de
R$2.000,00 (Dois Mil Reais) a R$4.000,00 (Quatro Mil Reais), sendo que para as
hip�teses de pagamento parcelado, o mesmo percentual incidir� sobre o valor de
cada uma das parcelas.</p>

<p
> 

mso-fareast-Arial;color:red'></p>

<p
><b> 
'>Par�grafo
Primeiro � Da Garantia: </b> 
'>A
<b> '>CONTRATANTE, </b>no ato da assinatura
deste contrato,  mso-bidi-font-weight:bold'>n�o se op�e em emitir
em favor da <b>CONTRATADA</b> uma nota promiss�ria no valor de R$1.500,00
(Hum mil e quinhentos Reais), que corresponder� a aproximadamente o percentual
de <b>30% (trinta por cento) </b>do valor informado na <b>Cl�usula D�cima Sexta</b>
mso-bidi-font-weight:bold'>, acrescido de <b>20%</b> <b>(vinte
por cento)</b> das despesas, conforme <b >Cl�usula
Vig�sima Terceira</b> podendo estes sofrer varia��es para mais ou para menos. <b>��</b></p>

<p
>  color:#00B0F0'></p>

<p
><b> 
'>Par�grafo
Segundo: </b> 
'>A nota
promiss�ria assinada, ser� devolvida a <b> '>CONTRATANTE</b>
no ato do efetivo pagamento dos honor�rios pactuados, mso-bidi-font-weight:
bold'> mediante assinatura de Termo de Restitui��o de Documento Original,
dando assim plena, rasa e total quita��o deste contrato  mso-bidi-font-weight:
bold'>em conformidade com a   font-size:
12.0pt;
mso-fareast-Arial;background:red;mso-highlight:red'>Cl�usula Oitava

mso-fareast-Arial;background:red;mso-highlight:red;mso-bidi-font-weight:
bold'>. 
;mso-bidi-font-weight:
bold'></p>

<p
> 

</p>

<p
><b> 
'>Par�grafo
Terceiro color:#0070C0'>: </b> 

mso-fareast-Arial;mso-bidi-font-weight:bold'>Sendo indeferido o
procedimento da <b> '>CONTRATANTE</b>

mso-fareast-Arial>, e sendo confirmada que esta
n�o fa�a jus em receber seu direito  font-size:
12.0pt;mso-fareast-
, a nota promiss�ria assinada ser� anulada e inutilizada na presen�a da <b>
'>CONTRATANTE. </b> ;
mso-bidi-font-weight:bold'>Este expediente n�o<b> </b>prevalecer�, entretanto,<b>
</b>para as hip�teses da <b> '>CONTRATANTE</b>
'> omitir que j� tenha recebido quaisquer outros valores
por meio de procedimentos fraudulentos de buscar receber o que j� recebera
anteriormente o que requer por meio deste contrato 
mso-bidi-font-weight:bold'>em conformidade com a o <b
>Par�grafo Primeiro e Segundo da Cl�usula
D�cima Sexta e mso-bidi-font-weight:bold'> </b><b
> 

Cl�usula Oitava</b><b> 

.</b></p>

<p
><b >

'></b></p>

<p
><b >

'>CL�USULA D�CIMA
S�TIMA: </b> 
;mso-bidi-font-weight:
bold'>Considerando que a 
;
color:red'> <b > 

CONTRATANTE</b> 

 omita dolosamente o que j� recebeu a t�tulo de <b>Licen�a-Maternidade,
Sal�rio Maternidade, Auxilio Maternidade, Sal�rio natalidade, </b>na ardil e
enganosa tentativa de receber estes benef�cios outra vez, a nota promiss�ria a
que se refere o <b >Par�grafo Primeiro e Segundo
da Cl�usula D�cima Sexta</b>, n�o ser� cancelada, anulada ou inutilizada, 
mso-bidi-font-weight:bold'>podendo a mesma servir de t�tulo executivo em
processo judicial de execu��o.</p>

<p
> 

</p>

<p
><b >

'>CL�USULA D�CIMA
OITAVA: </b> 

A <b > '>CONTRATANTE
</b> '>receber� uma �nica parcela no valor
que poder� variar entre R$2.000,00 (Dois Mil Reais) a R$4.000,00 (Quatro Mil
Reais) para a hip�tese de existir menores imp�beres com idade superior de 04 (quatro)
meses.</p>

<p
> 

mso-fareast-Arial></p>

<p
><b >

'>Par�grafo Primeiro:
</b> 
'>E
'>m caso de existir crian�a menor de 04 (Quatro)
meses na data do efetivo pagamento do benef�cio a ser creditado,
'> fica ciente a <b>CONTRATANTE</b> que receber� proporcional aos meses de idade da crian�a
ate no m�ximo 04 (Quatro) parcelas conforme <b> '>Cl�usula Primeira, </b>
'>do objeto deste contrato.</p>

<p
> 

mso-fareast-Arial></p>

<p
><b >

'>Par�grafo Segundo:
</b> 
;
'>A <b >CONTRATANTE</b> fica
ciente que em caso de retorno ao trabalho no per�odo correspondente a 04
(Quatro) meses do nascimento da crian�a, este receber� de forma proporcional
aos dias em que n�o trabalhou. </p>

<p
><b >

'>CL�USULA D�CIMA
NONA: </b> 

A <b >CONTRATADA</b>
color:black'> fica autorizada a deduzir dos valores recebidos
para o <b >CONTRATANTE</b>, � import�ncia
referente a honor�rios e despesas, aqui pactuados neste contrato, compreendidos
na <b > background:red;
mso-highlight:red'>Cl�usula D�cima Sexta</b> background:
red;mso-highlight:red'> e <b >

mso-fareast-Arial;background:red;mso-highlight:red'>Cl�usula
Vig�sima Terceira</b><b >

;background:red;
mso-highlight:red'> </b> 

mso-fareast-Arial;background:red;mso-highlight:red'>deste contrato

'>.</p>

<p
> 

</p>

<p
><b >

'>CL�USULA
VIG�SIMA: </b> 

Para libera��o do recebimento dos direitos da <b>CONTRATANTE</b> a mesma dever� dirigir-se ao escrit�rio da<b
> CONTRATADA</b>, munida de R.G., CPF, Certid�o
de Casamento (ser for casada legalmente) e Comprovante de Endere�o, em hor�rio
a ser previamente agendado, para o qual retirar� o extrato e a libera��o do
pagamento<b >,</b>  background:
red;mso-highlight:red'>juntamente com todos os documentos originais por
ela deixados, mesmo que tenha recebido anteriormente qualquer correspond�ncia
da autarquia concessora, conforme assim disp�e na<b> Cl�usula S�tima</b>. </p>

<p
> 

</p>

<p
><b >

'>CL�USULA VIG�SIMA
PRIMEIRA:</b> 
'> 
mso-bidi-font-weight:bold'>O requerimento do benef�cio objeto desta
contrata��o poder� tramitar em outros Munic�pios e Estados, ficando assim a <b>CONTRATANTE
</b>ciente que a <b>CONTRATADA </b>para tanto disponibilizar� de passagens
a�reas, transporte publico e de seus ve�culos pr�prio com seguran�as particulares
para fim de se fazer o traslado, e um �nico lugar, pois �poder� se valer de outras pessoas para o mesmo
dia e hor�rio combinado.  

mso-fareast-Arial;color:black;mso-themecolor:text1'>�</p>

<p
> 

mso-fareast-Arial;color:black;mso-themecolor:text1'></p>

<p
><b> 
'>Par�grafo
Primeiro:</b> 
;mso-bidi-font-weight:
bold'> No caso da <b>CONTRATANTE</b> se fazer acompanhada de conjugue,
parentes, amigos e outros afins, estes dever�o aguardar no endere�o do escrit�rio
da <b>CONTRATADA </b>at� que todo o procedimento de recebimento termine, 

;color:black;
mso-themecolor:text1'>conforme assim disp�e na<b> 
'>
 background:red;mso-highlight:red'>Cl�usula Q</b><b
>  
mso-fareast-Arial;background:red;mso-highlight:red'>uint</b><b
> 

mso-fareast-Arial;background:red;mso-highlight:red'>a</b><b>

mso-fareast-Arial;background:red;mso-highlight:red'> Cl�usula</b><b
> 

mso-fareast-Arial;background:red;mso-highlight:red'> Vig�sima
Primeira e</b><b> line-height:
125%;;background:
red;mso-highlight:red'> Par�grafo Segundo da </b><b> 
;
background:red;mso-highlight:red'>Cl�usula Vig�sima Primeira</b><b
> 

.</b></p>

<p
> 
;
color:red;mso-bidi-font-weight:bold'></p>

<p
><b> 
'>Par�grafo
Segundo: </b> 
'>A<b
> CONTRATANTE</b> fica ciente que em caso de
insistir em se fazer acompanhar de conjugue, parentes, amigos e outros afins junto
a reparti��o respons�vel pelo pagamento do benef�cio, que tenha por fim tentar
substituir a pr�pria <b >CONTRATANTE</b> no recebimento
do benef�cio aqui faz jus, este ser� imediatamente bloqueado, o que impedir� seu
recebimento no dia e hor�rio marcado pela <b >CONTRATADA,</b>
 
;
color:black;mso-themecolor:text1'>conforme assim disp�e na<b
> 

  color:red;background:red;
mso-highlight:red'>Cl�usula Q</b><b>  mso-fareast-
Arial;color:red;background:red;mso-highlight:red'>uint</b><b
> 

mso-fareast-Arial;color:red;background:red;mso-highlight:red'>a
Cl�usula Vig�sima Primeira e </b><b>  font-size:
12.0pt;mso-fareast-
Arial;color:red;background:red;mso-highlight:red'>Par�grafo Primeiro da </b><b
> 

mso-fareast-Arial;color:red;background:red;mso-highlight:red'>Cl�usula
Vig�sima Primeira.</b><b >

mso-fareast-Arial;color:red'></b></p>

<p
><b >

'>CL�USULA VIG�SIMA
SEGUNDA</b><b > 

: </b>  font-size:
12.0pt;mso-fareast-
Em caso de �bito da <b >
'>CONTRATANTE</b> poder� receber o benef�cio
pactuado na <b >Cl�usula D�cima Sexta</b> o legitimo
c�njuge sucessor ou quem legalmente estiver com as guardas judiciais da
crian�a, cujo procedimento atender� as normas e diretrizes normativas
estabelecidas pela autarquia, restringindo outros parentes ou afins do
recebimento deste. </p>

<p
'><b ><u> 

mso-fareast-Arial>DAS DESPESAS GERAIS</u></b><b
><u> 
'>:</u></b></p>

<p
><b >

</b></p>

<p
><b >

CL�USULA VIG�SIMA TERCEIRA: </b>

Ser�o cobrados <b> color:black'>20% (Vinte por Cento) </b>
color:black'>referente �s despesas, tais como,  background:
white'>Guias de Contribui��o, taxas, emolumentos, despesas cartor�rias, c�pias
reprogr�ficas, certid�es, dilig�ncias,  background:
white'>inclusive di�rias de  color:black'>viagens, dilig�ncia em
outra Comarca etc., bem como tudo  color:black'>o
mais que se fizer necess�rio para alcan�ar os objetivos aqui contratados.</p>

<p
><b> 
'></b></p>

<p'><b>

Par�grafo Primeiro:</b><b
> 
'>
</b> 
>O
valor dos servi�os pactuados na <b >

Cl�usula D�cima Sexta e Cl�usula Vig�sima
Terceira </b> 
>n�o
ser�o alterados nas seguintes hip�teses:</p>

<p CxSpFirst 
text-indent:-.25in;l0 level1 lfo4'><!>

mso-fareast-Arial;color:black'> '>a)
 '>&nbsp;&nbsp;&nbsp; <![endif]>

mso-fareast-Arial;color:black>De n�o se prosseguir
a execu��o dos servi�os aqui pactuados, que sejam provenientes por quaisquer circunstancias
n�o causada pela <b >CONTRATADA;</b><b
> 
;
color:black'></b></p>

<p CxSpMiddle text-justify:
inter-ideograph;text-indent:-.25in;l0 level1 lfo4'><!>

mso-fareast-Arial;color:black'> '>b)
 '>&nbsp;&nbsp;&nbsp; <![endif]>

mso-fareast-Arial;color:black>Para a hip�tese de
existir revoga��o da procura��o, sem culpa da<b> 
mso-fareast-Arial;color:black'> CONTRATADA</b></p>

<p CxSpLast 
text-indent:-.25in;l0 level1 lfo4'><!>

mso-fareast-Arial;color:black'> '>c)
 '>&nbsp;&nbsp;&nbsp; <![endif]>

mso-fareast-Arial;color:black'>Ou  '>a
pr�tica de quaisquer atos da <b >CONTRATANTE</b>
que de algum modo viole o presente contrato, seguindo assim o pagamento
normalmente ou a execu��o deste instrumento 

 at� o limite dos honor�rios pactuados
color:black>.<b> color:black'> </b></p>

<p
><b ><u>

 '>&nbsp;</u></b></p>

<p
'><b ><u> 

DA DECLARA��O</u></b></p>

<p
><b >

</b></p>

<p
><b >

CL�USULA VIG�SIMA QUARTA:</b>

mso-fareast-Arial;color:red'>  

mso-fareast-Arial;color:black'>A 

 <b >CONTRATANTE
</b>declara ter ci�ncia de que no final do cumprimento das obriga��es
contratuais, ou seja, tendo �xito junto � autarquia dos valores a serem
levantados pela <b >CONTRATADA</b>, os quais<b
> </b>dever�o ser recebidos juntamente com
os seus documentos originais, que se encontra em guarda junto a <b
>CONTRATADA</b> em seu escrit�rio. </p>

<p
> 
;
color:red'></p>

<p
><b> 
'>Par�grafo
Primeiro:</b> 
'> A <b
>CONTRATANTE</b> declara ter ci�ncia que o
documento original de (CTPS) Carteira Profissional de Trabalho deixada por ela
voluntariamente ficar� de posse da <b >CONTRATADA,
onde</b> s� ser� devidamente devolvido no final da execu��o dos servi�os aqui
contratados, ficando assim vedada a devolu��o da mesma durante o processo, c

'>onforme assim
disp�e no<b> 
>
Par�grafo �nico </b> line-height:
125%;;background:
white;mso-bidi-font-weight:bold'>da  font-size:
12.0pt;
 <b >Cl�usula
D�cima primeira </b>e<b > </b><b>

Par�grafo Segundo</b> 

 mso-spacerun:yes'>� da <b
>Cl�usula Vig�sima Quarta</b>.</p>

<p
> 
'></p>

<p
><b> 
'>Par�grafo
Segundo:</b> 
;mso-bidi-font-weight:
bold'> A <b>CONTRATANTE</b>  
'>declara
ter ci�ncia que o documento original de (CTPS) Carteira Profissional de
Trabalho deixada por ela voluntariamente Ficar� de posse da CONTRATADA, em
conformidade com o <b> '>Par�grafo �nico da</b>

'> <b
>Cl�usula D�cima primeira e </b><b>

Par�grafo Primeiro e Segundo</b>

 da <b >Cl�usula
Vig�sima Quarta, </b>sendo assim a<b > 
mso-bidi-font-weight:bold'>CONTRATANTE </b>fica orientada pela <b>CONTRATADA</b>
atrav�s deste contrato, o seu impedimento de tentar usar os �rg�os p�blicos no
intuito ardil de enganar as autoridades policiais, fazendo (boletim de
ocorr�ncia por perda ou roubo) em busca de obter outra Carteira Profissional de
Trabalho (2� via), neste caso ser� comunicado imediatamente a delegacia competente,
o dolo da <b>CONTRATANTE</b> mso-bidi-font-weight:bold'>, 
'>sob pena de incorrer nos termos previsto da lei,
cabendo assim a execu��o deste instrumento at� o limite dos honor�rios
pactuados. 

 </p>

<p
> 
;
color:red'></p>

<p
><b> 
'>Par�grafo
Terceiro:</b> 
;mso-bidi-font-weight:
bold'> <b>A CONTRATANTE</b> declara expressamente que n�o criar� obst�culos
para o sucesso deste procedimento administrativo em conformidade com a <b>Cl�usula</b><b
> 

 D</b><b>  mso-fareast-
�cima</b><b > 

mso-fareast-Arial> e a letra � do </b><b
> 
'>Par�grafo
Primeiro '> da Cl�usula Vig�sima Quinta, </b>

mso-fareast-Arial;mso-bidi-font-weight:bold'>sob pena de se criar
obst�culo no sentido de causar preju�zo � <b>CONTRATADA</b> na busca de seus
direitos e consequentemente o recebimento de seus honor�rios, a <b>CONTRATADA</b>
poder�, se sofrer preju�zo, ingressar com a��o de cobran�a de honor�rios
cumulado com danos morais.</p>

<p
> 
;
mso-bidi-font-weight:bold'></p>

<p
><b> 
'>Par�grafo
Quarto: color:red'> </b> 

mso-fareast-Arial;mso-bidi-font-weight:bold'>Tendo a<b> </b><b
> 
;
'>CONTRATANTE</b><b>  font-size:
12.0pt;mso-fareast-
 </b> 
;mso-bidi-font-weight:
bold'>efetuado o pagamento dos honor�rios pactuados na <b>C</b><b
> 

l�usula Quarta</b> 

 deste contrato<b
>,</b> 

mso-fareast-Arial;mso-bidi-font-weight:bold'> e n�o sendo devolvida
a NOTA PROMISS�RIA, a <b >

mso-fareast-Arial>CONTRATANTE</b><b>

 </b>  font-size:
12.0pt;mso-fareast-
Arial;mso-bidi-font-weight:bold'>poder� promover a��es contra a <b>CONTRATADA </b>em
busca de preservar os seus direitos.</p>

<p
> 
;
mso-bidi-font-weight:bold'></p>

<p'><b
> 
'>CL�USULA
VIG�SIMA QUINTA: </b> 
'>Deixando
a <b > '>CONTRATANTE
</b>de honrar os honor�rios contratados na <b >Cl�usula
D�cima Sexta e Cl�usula Vig�sima Terceira </b>deste contrato, a mesma autoriza
a <b >CONTRATADA</b> a executar
judicialmente o que lhe � devido, sejam atrav�s de demandas judiciais nas
esferas <b >PENAL e/ou</b> <b
>C�VEL </b>para exigir o cumprimento deste contrato,
at� o limite dos honor�rios pactuados, ou executar a nota promiss�ria garantidora
deste contrato, podendo ser levado a protesto junto aos cart�rios de t�tulos e
protestos, podendo at� ter seu nome incluso nos<b> SERVI�OS DE PROTE��O AO CREDITO (SPC) e SERASA.</b></p>

<p'><b
><u> 
'>Par�grafo
Primeiro: S�O MOTIVOS PARA QUE SE RESCINDA ESTE PRESENTE INSTRUMENTO:</u></b></p>

<p'><b
><u> 
'>
 '>&nbsp;</u></b></p>

<p  

'><!> 
'>
'>a)  '>&nbsp;&nbsp;&nbsp;&nbsp;S

;
'>A <b >CONTRATANTE</b> e a <b
>CONTRATADA</b> deixar de observar quaisquer
obriga��es que conste no presente contrato.</p>

<p'>

>b)
A <b >CONTRATANTE</b> descumprir com o
disposto na<b > Cl�usula </b><b
> 

D�cima Sexta �Cl�usula </b><b> 
Vig�sima Terceira</b>

>
deste contrato.</p>

<p'>

'>c) N�o apresentar
os documentos solicitados pela<b >
'> CONTRATADA, </b> '>conforme

mso-fareast-Arial;mso-bidi-font-weight:bold'> assim preceituam

mso-fareast-Arial> a <b> 
'>Cl�usula
D�cima</b><b> 
'> e Par�grafo
Terceiro</b><b > 

 Cl�usula Vig�sima Quarta.</b>

mso-fareast-Arial> <b> mso-spacerun:yes'>�</b><b> 
;
'></b></p>

<p'>

'>d) N�o
comunicar a<b > CONTRATADA</b> o recebimento
de algum benef�cio<b > </b>conforme <b>

Cl�usula Terceira</b><b> 
;
color:red>,</b> 

 ou qualquer outra viola��o das cl�usulas deste
contrato.</p>

<p'>

'>e) Criar
obst�culos  
;mso-bidi-font-weight:
bold'>para o sucesso deste demanda, no sentido de causar preju�zo � <b>CONTRATADA
conforme o Par�grafo Terceiro da </b><b> 
cl�usula Vig�sima Quarta.</b>

'></p>

<p'>

mso-fareast-Arial;color:black'>f 

)<b > </b>Tentar
induzir ou manter<b > </b>a<b
> CONTRATADA </b>a erro, mediante artif�cio
ardil de qualquer outro meio, prestando Informa��es falsas<b> </b>a<b > CONTRATADA em
conformidade com a cl�usula Vig�sima Sexta e o  mso-bidi-font-weight:
bold'>Par�grafo �nico. </b></p>

<p'><b
> 
;
color:red'></b></p>

<p'><b
> 
'>CL�USULA
VIG�SIMA SEXTA<u>: NO CASO DE INADIMPL�NCIA EM CONFORMIDADE COM A CL�USULA VIG�SIMA
QUINTA A </u></b><b ><u>

'>CONTRATANTE</u></b><b
><u> 
'>
DECLARA SER R� CONFESSA NOS CRIMES DE APROPRIA��O IND�BITA. </u></b></p>

<p'><b>

�Art. 168 - Apropriar-se de coisa alheia m�vel,
de que tem a posse ou a deten��o:�<br mso-special-character:line-break'>
<![if !supportLineBreakNewLine]><br mso-special-character:line-break'>
<![endif]></b></p>

<p'><b>

</b></p>

<p'><b>

��������������____________________________________________</b></p>

<p'><b>

</b></p>

<p'><b>

</b></p>

<p'><b>

Par�grafo �nico</b><b> 
"Arial","sans-serif"'>: </b> 
"Arial","sans-serif"'>A <b
> 
;
'>CONTRATANTE</b> 
"Arial","sans-serif"'> declara esta ciente sob
pena de incorre na pratica de crime previsto no artigo 299 do c�digo penal
brasileiro ser completas e verdadeiras as informa��es prestadas, isentando o
procurador a empresa <b> 
'>CONTRATADA,</b>
"Arial","sans-serif"'>
<b >LIDER CONSULTORIA CNPJ
24.808.801/0001-81</b> de qualquer responsabilidade Penal ou Civil.</p>

<p'>
"Arial","sans-serif"'></p>

<p'><b
> 

CL�USULA VIG�SIMA NONA: </b><u>

;
'>A</u><b ><u>

'> CONTRATANTE
'> </u></b><u> 

mso-fareast-Arial>declara
que, antes de assinar, examinou e leu o presente instrumento, reconhecendo-o em
tudo correto, sob pena de incorrer nos termos previsto no art. 299 do C�digo Penal,
declarando finalmente que reconhece, desde j�, como l�quida e certa a obriga��o
contra�da por este instrumento particular de contrato.</u></p>

<p'><b
> 

</b></p>

<ptext-align:center'><b><u> 
'>DO
FORO:</u></b></p>

<p'><b
> 

</b></p>

<p'>

>As
partes contratadas elegem o foro da cidade do Rio de Janeiro para dirimir
qualquer a��o oriunda deste contrato.</p>

<p'>

>&nbsp;E,
por assim terem contratado, assinam o presente em duas vias ou via e-mail de
igual teor e forma, na presen�a das testemunhas abaixo qualificadas que tamb�m
assinam.</p>

<palign=right text-align:right'><b> 
;
'></b></p>

<palign=right text-align:right'><b> 
;
'>Rio de Janeiro </b>  font-size:
12.0pt;
mso-fareast-Arial>________<b>de</b>________________________<b >
de 2017</b></p>

<palign=right text-align:right'><b> 
;
'></b></p>

<p'>

'><br>
 '>___________________________
��������� ___________________________</p>

<p'>

></p>

<p'>

>Testemunhas:&nbsp;</p>

<p'>

'><br>
<br>
 '>___________________________&nbsp;
�������� ___________________________<br>
 '>Nome:���������������������������� 
mso-tab-count:3'>����������������������������� Nome:&nbsp;<br>
 '>CPF:�������������������������������������������������������
CPF:</p>
<p'>&nbsp;</p>
<p'>&nbsp;</p>
<p'>&nbsp;</p>
<p'>&nbsp;</p>
<h5'>

'> '><em>Contrato cadastrado por: [cod_funcionario] - [nome_funcionario].      
        
</em></h5>

</body>

</html>