<html xmlns:v="urn:schemas-microsoft-com:vml"
xmlns:o="urn:schemas-microsoft-com:office:office"
xmlns:w="urn:schemas-microsoft-com:office:word"
xmlns:m="http://schemas.microsoft.com/office/2004/12/omml"
xmlns="http://www.w3.org/TR/REC-html40">

<head>
<meta http-equiv=Content-Type content="text/html; charset=windows-1252">
<meta name=ProgId content=Word.Document>
<meta name=Generator content="Microsoft Word 14">
<meta name=Originator content="Microsoft Word 14">
<link rel=File-List href="filelist.xml">
<title>CONTRATO DE PRESTA��O DE SERVI�OS</title>
<!--[if gte mso 9]><xml>
 <o:DocumentProperties>
  <o:Author>user</o:Author>
  <o:Template>Normal</o:Template>
  <o:LastAuthor>MX</o:LastAuthor>
  <o:Revision>2</o:Revision>
  <o:TotalTime>1293</o:TotalTime>
  <o:LastPrinted>2017-04-18T00:52:00Z</o:LastPrinted>
  <o:Created>2017-07-12T04:45:00Z</o:Created>
  <o:LastSaved>2017-07-12T04:45:00Z</o:LastSaved>
  <o:Pages>12</o:Pages>
  <o:Words>3387</o:Words>
  <o:Characters>19312</o:Characters>
  <o:Company>Microsoft</o:Company>
  <o:Lines>160</o:Lines>
  <o:Paragraphs>45</o:Paragraphs>
  <o:CharactersWithSpaces>22654</o:CharactersWithSpaces>
  <o:Version>14.00</o:Version>
 </o:DocumentProperties>
 <o:OfficeDocumentSettings>
  <o:RelyOnVML/>
  <o:AllowPNG/>
 </o:OfficeDocumentSettings>
</xml><![endif]-->
<link rel=dataStoreItem href="item0001.xml"
target="props002.xml">
<link rel=themeData href="themedata.thmx">
<link rel=colorSchemeMapping
href="colorschememapping.xml">
<!--[if gte mso 9]><xml>
 <w:WordDocument>
  <w:TrackMoves>false</w:TrackMoves>
  <w:TrackFormatting/>
  <w:HyphenationZone>21</w:HyphenationZone>
  <w:PunctuationKerning/>
  <w:ValidateAgainstSchemas/>
  <w:SaveIfXMLInvalid>false</w:SaveIfXMLInvalid>
  <w:IgnoreMixedContent>false</w:IgnoreMixedContent>
  <w:AlwaysShowPlaceholderText>false</w:AlwaysShowPlaceholderText>
  <w:DoNotPromoteQF/>
  <w:LidThemeOther>PT-BR</w:LidThemeOther>
  <w:LidThemeAsian>X-NONE</w:LidThemeAsian>
  <w:LidThemeComplexScript>X-NONE</w:LidThemeComplexScript>
  <w:Compatibility>
   <w:BreakWrappedTables/>
   <w:SnapToGridInCell/>
   <w:WrapTextWithPunct/>
   <w:UseAsianBreakRules/>
   <w:DontGrowAutofit/>
   <w:SplitPgBreakAndParaMark/>
   <w:EnableOpenTypeKerning/>
   <w:DontFlipMirrorIndents/>
   <w:OverrideTableStyleHps/>
   <w:UseFELayout/>
  </w:Compatibility>
  <w:DoNotOptimizeForBrowser/>
  <m:mathPr>
   <m:mathFont m:val="Cambria Math"/>
   <m:brkBin m:val="before"/>
   <m:brkBinSub m:val="&#45;-"/>
   <m:smallFrac m:val="off"/>
   <m:dispDef/>
   <m:lMargin m:val="0"/>
   <m:rMargin m:val="0"/>
   <m:defJc m:val="centerGroup"/>
   <m:wrapIndent m:val="1440"/>
   <m:intLim m:val="subSup"/>
   <m:naryLim m:val="undOvr"/>
  </m:mathPr></w:WordDocument>
</xml><![endif]--><!--[if gte mso 9]><xml>
 <w:LatentStyles DefLockedState="false" DefUnhideWhenUsed="true"
  DefSemiHidden="true" DefQFormat="false" DefPriority="99"
  LatentStyleCount="267">
  <w:LsdException Locked="false" Priority="0" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Normal"/>
  <w:LsdException Locked="false" Priority="9" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="heading 1"/>
  <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 2"/>
  <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 3"/>
  <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 4"/>
  <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 5"/>
  <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 6"/>
  <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 7"/>
  <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 8"/>
  <w:LsdException Locked="false" Priority="9" QFormat="true" Name="heading 9"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 1"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 2"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 3"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 4"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 5"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 6"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 7"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 8"/>
  <w:LsdException Locked="false" Priority="39" Name="toc 9"/>
  <w:LsdException Locked="false" Priority="35" QFormat="true" Name="caption"/>
  <w:LsdException Locked="false" Priority="10" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Title"/>
  <w:LsdException Locked="false" Priority="1" Name="Default Paragraph Font"/>
  <w:LsdException Locked="false" Priority="11" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Subtitle"/>
  <w:LsdException Locked="false" Priority="22" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Strong"/>
  <w:LsdException Locked="false" Priority="20" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Emphasis"/>
  <w:LsdException Locked="false" Priority="59" SemiHidden="false"
   UnhideWhenUsed="false" Name="Table Grid"/>
  <w:LsdException Locked="false" UnhideWhenUsed="false" Name="Placeholder Text"/>
  <w:LsdException Locked="false" Priority="1" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="No Spacing"/>
  <w:LsdException Locked="false" Priority="60" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Shading"/>
  <w:LsdException Locked="false" Priority="61" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light List"/>
  <w:LsdException Locked="false" Priority="62" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Grid"/>
  <w:LsdException Locked="false" Priority="63" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 1"/>
  <w:LsdException Locked="false" Priority="64" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 2"/>
  <w:LsdException Locked="false" Priority="65" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 1"/>
  <w:LsdException Locked="false" Priority="66" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 2"/>
  <w:LsdException Locked="false" Priority="67" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 1"/>
  <w:LsdException Locked="false" Priority="68" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 2"/>
  <w:LsdException Locked="false" Priority="69" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 3"/>
  <w:LsdException Locked="false" Priority="70" SemiHidden="false"
   UnhideWhenUsed="false" Name="Dark List"/>
  <w:LsdException Locked="false" Priority="71" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Shading"/>
  <w:LsdException Locked="false" Priority="72" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful List"/>
  <w:LsdException Locked="false" Priority="73" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Grid"/>
  <w:LsdException Locked="false" Priority="60" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Shading Accent 1"/>
  <w:LsdException Locked="false" Priority="61" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light List Accent 1"/>
  <w:LsdException Locked="false" Priority="62" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Grid Accent 1"/>
  <w:LsdException Locked="false" Priority="63" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 1 Accent 1"/>
  <w:LsdException Locked="false" Priority="64" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 2 Accent 1"/>
  <w:LsdException Locked="false" Priority="65" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 1 Accent 1"/>
  <w:LsdException Locked="false" UnhideWhenUsed="false" Name="Revision"/>
  <w:LsdException Locked="false" Priority="34" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="List Paragraph"/>
  <w:LsdException Locked="false" Priority="29" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Quote"/>
  <w:LsdException Locked="false" Priority="30" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Intense Quote"/>
  <w:LsdException Locked="false" Priority="66" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 2 Accent 1"/>
  <w:LsdException Locked="false" Priority="67" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 1 Accent 1"/>
  <w:LsdException Locked="false" Priority="68" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 2 Accent 1"/>
  <w:LsdException Locked="false" Priority="69" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 3 Accent 1"/>
  <w:LsdException Locked="false" Priority="70" SemiHidden="false"
   UnhideWhenUsed="false" Name="Dark List Accent 1"/>
  <w:LsdException Locked="false" Priority="71" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Shading Accent 1"/>
  <w:LsdException Locked="false" Priority="72" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful List Accent 1"/>
  <w:LsdException Locked="false" Priority="73" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Grid Accent 1"/>
  <w:LsdException Locked="false" Priority="60" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Shading Accent 2"/>
  <w:LsdException Locked="false" Priority="61" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light List Accent 2"/>
  <w:LsdException Locked="false" Priority="62" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Grid Accent 2"/>
  <w:LsdException Locked="false" Priority="63" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 1 Accent 2"/>
  <w:LsdException Locked="false" Priority="64" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 2 Accent 2"/>
  <w:LsdException Locked="false" Priority="65" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 1 Accent 2"/>
  <w:LsdException Locked="false" Priority="66" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 2 Accent 2"/>
  <w:LsdException Locked="false" Priority="67" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 1 Accent 2"/>
  <w:LsdException Locked="false" Priority="68" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 2 Accent 2"/>
  <w:LsdException Locked="false" Priority="69" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 3 Accent 2"/>
  <w:LsdException Locked="false" Priority="70" SemiHidden="false"
   UnhideWhenUsed="false" Name="Dark List Accent 2"/>
  <w:LsdException Locked="false" Priority="71" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Shading Accent 2"/>
  <w:LsdException Locked="false" Priority="72" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful List Accent 2"/>
  <w:LsdException Locked="false" Priority="73" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Grid Accent 2"/>
  <w:LsdException Locked="false" Priority="60" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Shading Accent 3"/>
  <w:LsdException Locked="false" Priority="61" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light List Accent 3"/>
  <w:LsdException Locked="false" Priority="62" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Grid Accent 3"/>
  <w:LsdException Locked="false" Priority="63" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 1 Accent 3"/>
  <w:LsdException Locked="false" Priority="64" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 2 Accent 3"/>
  <w:LsdException Locked="false" Priority="65" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 1 Accent 3"/>
  <w:LsdException Locked="false" Priority="66" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 2 Accent 3"/>
  <w:LsdException Locked="false" Priority="67" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 1 Accent 3"/>
  <w:LsdException Locked="false" Priority="68" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 2 Accent 3"/>
  <w:LsdException Locked="false" Priority="69" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 3 Accent 3"/>
  <w:LsdException Locked="false" Priority="70" SemiHidden="false"
   UnhideWhenUsed="false" Name="Dark List Accent 3"/>
  <w:LsdException Locked="false" Priority="71" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Shading Accent 3"/>
  <w:LsdException Locked="false" Priority="72" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful List Accent 3"/>
  <w:LsdException Locked="false" Priority="73" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Grid Accent 3"/>
  <w:LsdException Locked="false" Priority="60" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Shading Accent 4"/>
  <w:LsdException Locked="false" Priority="61" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light List Accent 4"/>
  <w:LsdException Locked="false" Priority="62" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Grid Accent 4"/>
  <w:LsdException Locked="false" Priority="63" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 1 Accent 4"/>
  <w:LsdException Locked="false" Priority="64" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 2 Accent 4"/>
  <w:LsdException Locked="false" Priority="65" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 1 Accent 4"/>
  <w:LsdException Locked="false" Priority="66" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 2 Accent 4"/>
  <w:LsdException Locked="false" Priority="67" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 1 Accent 4"/>
  <w:LsdException Locked="false" Priority="68" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 2 Accent 4"/>
  <w:LsdException Locked="false" Priority="69" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 3 Accent 4"/>
  <w:LsdException Locked="false" Priority="70" SemiHidden="false"
   UnhideWhenUsed="false" Name="Dark List Accent 4"/>
  <w:LsdException Locked="false" Priority="71" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Shading Accent 4"/>
  <w:LsdException Locked="false" Priority="72" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful List Accent 4"/>
  <w:LsdException Locked="false" Priority="73" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Grid Accent 4"/>
  <w:LsdException Locked="false" Priority="60" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Shading Accent 5"/>
  <w:LsdException Locked="false" Priority="61" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light List Accent 5"/>
  <w:LsdException Locked="false" Priority="62" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Grid Accent 5"/>
  <w:LsdException Locked="false" Priority="63" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 1 Accent 5"/>
  <w:LsdException Locked="false" Priority="64" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 2 Accent 5"/>
  <w:LsdException Locked="false" Priority="65" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 1 Accent 5"/>
  <w:LsdException Locked="false" Priority="66" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 2 Accent 5"/>
  <w:LsdException Locked="false" Priority="67" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 1 Accent 5"/>
  <w:LsdException Locked="false" Priority="68" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 2 Accent 5"/>
  <w:LsdException Locked="false" Priority="69" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 3 Accent 5"/>
  <w:LsdException Locked="false" Priority="70" SemiHidden="false"
   UnhideWhenUsed="false" Name="Dark List Accent 5"/>
  <w:LsdException Locked="false" Priority="71" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Shading Accent 5"/>
  <w:LsdException Locked="false" Priority="72" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful List Accent 5"/>
  <w:LsdException Locked="false" Priority="73" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Grid Accent 5"/>
  <w:LsdException Locked="false" Priority="60" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Shading Accent 6"/>
  <w:LsdException Locked="false" Priority="61" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light List Accent 6"/>
  <w:LsdException Locked="false" Priority="62" SemiHidden="false"
   UnhideWhenUsed="false" Name="Light Grid Accent 6"/>
  <w:LsdException Locked="false" Priority="63" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 1 Accent 6"/>
  <w:LsdException Locked="false" Priority="64" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Shading 2 Accent 6"/>
  <w:LsdException Locked="false" Priority="65" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 1 Accent 6"/>
  <w:LsdException Locked="false" Priority="66" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium List 2 Accent 6"/>
  <w:LsdException Locked="false" Priority="67" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 1 Accent 6"/>
  <w:LsdException Locked="false" Priority="68" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 2 Accent 6"/>
  <w:LsdException Locked="false" Priority="69" SemiHidden="false"
   UnhideWhenUsed="false" Name="Medium Grid 3 Accent 6"/>
  <w:LsdException Locked="false" Priority="70" SemiHidden="false"
   UnhideWhenUsed="false" Name="Dark List Accent 6"/>
  <w:LsdException Locked="false" Priority="71" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Shading Accent 6"/>
  <w:LsdException Locked="false" Priority="72" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful List Accent 6"/>
  <w:LsdException Locked="false" Priority="73" SemiHidden="false"
   UnhideWhenUsed="false" Name="Colorful Grid Accent 6"/>
  <w:LsdException Locked="false" Priority="19" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Subtle Emphasis"/>
  <w:LsdException Locked="false" Priority="21" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Intense Emphasis"/>
  <w:LsdException Locked="false" Priority="31" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Subtle Reference"/>
  <w:LsdException Locked="false" Priority="32" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Intense Reference"/>
  <w:LsdException Locked="false" Priority="33" SemiHidden="false"
   UnhideWhenUsed="false" QFormat="true" Name="Book Title"/>
  <w:LsdException Locked="false" Priority="37" Name="Bibliography"/>
  <w:LsdException Locked="false" Priority="39" QFormat="true" Name="TOC Heading"/>
 </w:LatentStyles>
</xml><![endif]-->
<style>
<!--
 /* Font Definitions */
 @font-face
	{font-family:Calibri;
	panose-1:2 15 5 2 2 2 4 3 2 4;
	mso-font-charset:0;
	mso-generic-font-family:swiss;
	mso-font-pitch:variable;
	mso-font-signature:-536870145 1073786111 1 0 415 0;}
@font-face
	{font-family:"Segoe UI";
	panose-1:2 11 5 2 4 2 4 2 2 3;
	mso-font-charset:0;
	mso-generic-font-family:swiss;
	mso-font-pitch:variable;
	mso-font-signature:-469750017 -1073683329 9 0 511 0;}
 /* Style Definitions */
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	{mso-style-unhide:no;
	mso-style-qformat:yes;
	mso-style-parent:"";
	margin-top:0in;
	margin-right:0in;
	margin-bottom:10.0pt;
	margin-left:0in;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Calibri","sans-serif";
	mso-ascii-font-family:Calibri;
	mso-ascii-theme-font:minor-latin;
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	mso-hansi-font-family:Calibri;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;
	mso-ansi-language:PT-BR;
	mso-fareast-language:PT-BR;}
p.MsoHeader, li.MsoHeader, div.MsoHeader
	{mso-style-priority:99;
	mso-style-link:"Header Char";
	margin:0in;
	margin-bottom:.0001pt;
	mso-pagination:widow-orphan;
	tab-stops:center 212.6pt right 425.2pt;
	font-size:11.0pt;
	font-family:"Calibri","sans-serif";
	mso-ascii-font-family:Calibri;
	mso-ascii-theme-font:minor-latin;
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	mso-hansi-font-family:Calibri;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;
	mso-ansi-language:PT-BR;
	mso-fareast-language:PT-BR;}
p.MsoFooter, li.MsoFooter, div.MsoFooter
	{mso-style-priority:99;
	mso-style-link:"Footer Char";
	margin:0in;
	margin-bottom:.0001pt;
	mso-pagination:widow-orphan;
	tab-stops:center 212.6pt right 425.2pt;
	font-size:11.0pt;
	font-family:"Calibri","sans-serif";
	mso-ascii-font-family:Calibri;
	mso-ascii-theme-font:minor-latin;
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	mso-hansi-font-family:Calibri;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;
	mso-ansi-language:PT-BR;
	mso-fareast-language:PT-BR;}
p.MsoAcetate, li.MsoAcetate, div.MsoAcetate
	{mso-style-noshow:yes;
	mso-style-priority:99;
	mso-style-link:"Balloon Text Char";
	margin:0in;
	margin-bottom:.0001pt;
	mso-pagination:widow-orphan;
	font-size:9.0pt;
	font-family:"Segoe UI","sans-serif";
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	mso-ansi-language:PT-BR;
	mso-fareast-language:PT-BR;}
p.MsoListParagraph, li.MsoListParagraph, div.MsoListParagraph
	{mso-style-priority:34;
	mso-style-unhide:no;
	mso-style-qformat:yes;
	margin-top:0in;
	margin-right:0in;
	margin-bottom:10.0pt;
	margin-left:.5in;
	mso-add-space:auto;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Calibri","sans-serif";
	mso-ascii-font-family:Calibri;
	mso-ascii-theme-font:minor-latin;
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	mso-hansi-font-family:Calibri;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;
	mso-ansi-language:PT-BR;
	mso-fareast-language:PT-BR;}
p.MsoListParagraphCxSpFirst, li.MsoListParagraphCxSpFirst, div.MsoListParagraphCxSpFirst
	{mso-style-priority:34;
	mso-style-unhide:no;
	mso-style-qformat:yes;
	mso-style-type:export-only;
	margin-top:0in;
	margin-right:0in;
	margin-bottom:0in;
	margin-left:.5in;
	margin-bottom:.0001pt;
	mso-add-space:auto;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Calibri","sans-serif";
	mso-ascii-font-family:Calibri;
	mso-ascii-theme-font:minor-latin;
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	mso-hansi-font-family:Calibri;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;
	mso-ansi-language:PT-BR;
	mso-fareast-language:PT-BR;}
p.MsoListParagraphCxSpMiddle, li.MsoListParagraphCxSpMiddle, div.MsoListParagraphCxSpMiddle
	{mso-style-priority:34;
	mso-style-unhide:no;
	mso-style-qformat:yes;
	mso-style-type:export-only;
	margin-top:0in;
	margin-right:0in;
	margin-bottom:0in;
	margin-left:.5in;
	margin-bottom:.0001pt;
	mso-add-space:auto;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Calibri","sans-serif";
	mso-ascii-font-family:Calibri;
	mso-ascii-theme-font:minor-latin;
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	mso-hansi-font-family:Calibri;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;
	mso-ansi-language:PT-BR;
	mso-fareast-language:PT-BR;}
p.MsoListParagraphCxSpLast, li.MsoListParagraphCxSpLast, div.MsoListParagraphCxSpLast
	{mso-style-priority:34;
	mso-style-unhide:no;
	mso-style-qformat:yes;
	mso-style-type:export-only;
	margin-top:0in;
	margin-right:0in;
	margin-bottom:10.0pt;
	margin-left:.5in;
	mso-add-space:auto;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Calibri","sans-serif";
	mso-ascii-font-family:Calibri;
	mso-ascii-theme-font:minor-latin;
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	mso-hansi-font-family:Calibri;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;
	mso-ansi-language:PT-BR;
	mso-fareast-language:PT-BR;}
span.HeaderChar
	{mso-style-name:"Header Char";
	mso-style-priority:99;
	mso-style-unhide:no;
	mso-style-locked:yes;
	mso-style-link:Header;}
span.FooterChar
	{mso-style-name:"Footer Char";
	mso-style-priority:99;
	mso-style-unhide:no;
	mso-style-locked:yes;
	mso-style-link:Footer;}
span.BalloonTextChar
	{mso-style-name:"Balloon Text Char";
	mso-style-noshow:yes;
	mso-style-priority:99;
	mso-style-unhide:no;
	mso-style-locked:yes;
	mso-style-link:"Balloon Text";
	mso-ansi-font-size:9.0pt;
	mso-bidi-font-size:9.0pt;
	font-family:"Segoe UI","sans-serif";
	mso-ascii-font-family:"Segoe UI";
	mso-hansi-font-family:"Segoe UI";
	mso-bidi-font-family:"Segoe UI";}
.MsoChpDefault
	{mso-style-type:export-only;
	mso-default-props:yes;
	font-family:"Calibri","sans-serif";
	mso-ascii-font-family:Calibri;
	mso-ascii-theme-font:minor-latin;
	mso-fareast-font-family:"Times New Roman";
	mso-fareast-theme-font:minor-fareast;
	mso-hansi-font-family:Calibri;
	mso-hansi-theme-font:minor-latin;
	mso-bidi-font-family:"Times New Roman";
	mso-bidi-theme-font:minor-bidi;
	mso-ansi-language:PT-BR;
	mso-fareast-language:PT-BR;}
.MsoPapDefault
	{mso-style-type:export-only;
	margin-bottom:10.0pt;
	line-height:115%;}
 /* Page Definitions */
 @page
	{mso-footnote-separator:url("header.htm") fs;
	mso-footnote-continuation-separator:url("header.htm") fcs;
	mso-endnote-separator:url("header.htm") es;
	mso-endnote-continuation-separator:url("header.htm") ecs;}
@page WordSection1
	{size:595.3pt 841.9pt;
	margin:70.85pt 85.05pt 70.85pt 85.05pt;
	mso-header-margin:35.4pt;
	mso-footer-margin:35.4pt;
	mso-header:url("header.htm") h1;
	mso-footer:url("header.htm") f1;
	mso-paper-source:0;}
div.WordSection1
	{page:WordSection1;}
 /* List Definitions */
 @list l0
	{mso-list-id:219900767;
	mso-list-type:hybrid;
	mso-list-template-ids:1519432216 68550679 68550681 68550683 68550671 68550681 68550683 68550671 68550681 68550683;}
@list l0:level1
	{mso-level-number-format:alpha-lower;
	mso-level-text:"%1\)";
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-.25in;
	mso-ansi-font-weight:normal;}
@list l0:level2
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-.25in;}
@list l0:level3
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:right;
	text-indent:-9.0pt;}
@list l0:level4
	{mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-.25in;}
@list l0:level5
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-.25in;}
@list l0:level6
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:right;
	text-indent:-9.0pt;}
@list l0:level7
	{mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-.25in;}
@list l0:level8
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-.25in;}
@list l0:level9
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:right;
	text-indent:-9.0pt;}
@list l1
	{mso-list-id:445152246;
	mso-list-type:hybrid;
	mso-list-template-ids:461012028 68550679 68550681 68550683 68550671 68550681 68550683 68550671 68550681 68550683;}
@list l1:level1
	{mso-level-number-format:alpha-lower;
	mso-level-text:"%1\)";
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-.25in;}
@list l1:level2
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-.25in;}
@list l1:level3
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:right;
	text-indent:-9.0pt;}
@list l1:level4
	{mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-.25in;}
@list l1:level5
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-.25in;}
@list l1:level6
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:right;
	text-indent:-9.0pt;}
@list l1:level7
	{mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-.25in;}
@list l1:level8
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-.25in;}
@list l1:level9
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:right;
	text-indent:-9.0pt;}
@list l2
	{mso-list-id:1373189663;
	mso-list-type:hybrid;
	mso-list-template-ids:506200924 68550679 68550681 68550683 68550671 68550681 68550683 68550671 68550681 68550683;}
@list l2:level1
	{mso-level-number-format:alpha-lower;
	mso-level-text:"%1\)";
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-.25in;}
@list l2:level2
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-.25in;}
@list l2:level3
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:right;
	text-indent:-9.0pt;}
@list l2:level4
	{mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-.25in;}
@list l2:level5
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-.25in;}
@list l2:level6
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:right;
	text-indent:-9.0pt;}
@list l2:level7
	{mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-.25in;}
@list l2:level8
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-.25in;}
@list l2:level9
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:right;
	text-indent:-9.0pt;}
@list l3
	{mso-list-id:2033991805;
	mso-list-type:hybrid;
	mso-list-template-ids:-1835115680 -1202006860 68550681 68550683 68550671 68550681 68550683 68550671 68550681 68550683;}
@list l3:level1
	{mso-level-number-format:alpha-upper;
	mso-level-text:"%1\)";
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-.25in;}
@list l3:level2
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-.25in;}
@list l3:level3
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:right;
	text-indent:-9.0pt;}
@list l3:level4
	{mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-.25in;}
@list l3:level5
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-.25in;}
@list l3:level6
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:right;
	text-indent:-9.0pt;}
@list l3:level7
	{mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-.25in;}
@list l3:level8
	{mso-level-number-format:alpha-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:left;
	text-indent:-.25in;}
@list l3:level9
	{mso-level-number-format:roman-lower;
	mso-level-tab-stop:none;
	mso-level-number-position:right;
	text-indent:-9.0pt;}
ol
	{margin-bottom:0in;}
ul
	{margin-bottom:0in;}
-->
</style>
<!--[if gte mso 10]>
<style>
 /* Style Definitions */
 table.MsoNormalTable
	{mso-style-name:"Table Normal";
	mso-tstyle-rowband-size:0;
	mso-tstyle-colband-size:0;
	mso-style-noshow:yes;
	mso-style-priority:99;
	mso-style-parent:"";
	mso-padding-alt:0in 5.4pt 0in 5.4pt;
	mso-para-margin-top:0in;
	mso-para-margin-right:0in;
	mso-para-margin-bottom:10.0pt;
	mso-para-margin-left:0in;
	line-height:115%;
	mso-pagination:widow-orphan;
	font-size:11.0pt;
	font-family:"Calibri","sans-serif";
	mso-ascii-font-family:Calibri;
	mso-ascii-theme-font:minor-latin;
	mso-hansi-font-family:Calibri;
	mso-hansi-theme-font:minor-latin;
	mso-ansi-language:PT-BR;
	mso-fareast-language:PT-BR;}
</style>
<![endif]--><!--[if gte mso 9]><xml>
 <o:shapedefaults v:ext="edit" spidmax="2049"/>
</xml><![endif]--><!--[if gte mso 9]><xml>
 <o:shapelayout v:ext="edit">
  <o:idmap v:ext="edit" data="1"/>
 </o:shapelayout></xml><![endif]-->
</head>

<body lang=RU style='tab-interval:35.4pt'>

<div class=WordSection1>

<div style='mso-element:para-border-div;border:solid windowtext 1.0pt;
mso-border-alt:solid windowtext .5pt;padding:1.0pt 4.0pt 1.0pt 4.0pt'>

<p class=MsoNormal align=center style='margin-bottom:8.0pt;text-align:center;
line-height:125%;border:none;mso-border-alt:solid windowtext .5pt;padding:0in;
mso-padding-alt:1.0pt 4.0pt 1.0pt 4.0pt'><b style='mso-bidi-font-weight:normal'><u><span
lang=PT-BR style='font-size:14.0pt;mso-bidi-font-size:11.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>CONTRATO DE
PRESTA��O DE SERVI�OS<o:p></o:p></span></u></b></p>

</div>

<p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;text-align:
justify;text-justify:inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:
normal'><span lang=PT-BR style='font-size:10.0pt;mso-bidi-font-size:11.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'><o:p>&nbsp;</o:p></span></b></p>

<p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;text-align:
justify;text-justify:inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:
normal'><u><span lang=PT-BR style='font-size:10.0pt;mso-bidi-font-size:11.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>CONTRATANTE:</span></u></b><span lang=PT-BR style='font-size:10.0pt;mso-bidi-font-size:11.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'> <strong>[nomeBeneficiario]</strong></span><strong><u><span lang=PT-BR style='font-size:10.0pt;mso-bidi-font-size:11.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>
  <o:p></o:p>
</span></u></strong></p>

<p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;text-align:
justify;text-justify:inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:
normal'><span lang=PT-BR style='font-size:10.0pt;mso-bidi-font-size:11.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>RG:
[numeroRG]
  <o:p></o:p></span></b></p>

<p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;text-align:
justify;text-justify:inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:
normal'><span lang=PT-BR style='font-size:10.0pt;mso-bidi-font-size:11.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>CPF:<span
style='mso-spacerun:yes'>� [numeroCPF]</span>
      <o:p></o:p></span></b></p>

<p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;text-align:
justify;text-justify:inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:
normal'><span lang=PT-BR style='font-size:10.0pt;mso-bidi-font-size:11.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>DATA
DE NASCIMENTO: [dataNascimento]
      <o:p></o:p></span></b></p>

<p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;text-align:
justify;text-justify:inter-ideograph;line-height:125%;tab-stops:329.25pt'><b
style='mso-bidi-font-weight:normal'><span lang=PT-BR style='font-size:10.0pt;
mso-bidi-font-size:11.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'>RUA:<span style='mso-tab-count:1'>�[endRua]�������������������������������� </span>N� [endNumero]
  <o:p></o:p></span></b></p>

<p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;text-align:
justify;text-justify:inter-ideograph;line-height:125%;tab-stops:329.25pt'><b
style='mso-bidi-font-weight:normal'><span lang=PT-BR style='font-size:10.0pt;
mso-bidi-font-size:11.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'>BAIRRO:<span
style='mso-spacerun:yes'>�[endBairro]�����������������</span>CEP: [endCEP]<span
style='mso-spacerun:yes'>������� </span>Cidade:<span
style='mso-spacerun:yes'>�[endCidade]��</span>UF: [endUF]
      <o:p></o:p></span></b></p>

<p align="left" class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;text-align:
justify;text-justify:inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:
normal'><span lang=PT-BR style='font-size:10.0pt;mso-bidi-font-size:11.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>GRAU
DE ESCOLARIDADE: [grauEscolaridade]
      <o:p></o:p></span></b></p>

<p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;text-align:
justify;text-justify:inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:
normal'><span lang=PT-BR style='font-size:10.0pt;mso-bidi-font-size:11.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>FONE: [telefone]
      <o:p></o:p></span></b></p>

<p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;text-align:
justify;text-justify:inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:
normal'><span lang=PT-BR style='font-size:10.0pt;mso-bidi-font-size:11.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'><o:p>&nbsp;</o:p></span></b></p>

<p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;text-align:
justify;text-justify:inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:
normal'><u><span lang=PT-BR style='font-size:10.0pt;mso-bidi-font-size:11.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>CONTRATADA</span></u></b><b
style='mso-bidi-font-weight:normal'><span lang=PT-BR style='font-size:10.0pt;
mso-bidi-font-size:11.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'>: L�DER CONSULTORIA LTDA, inscrita no CNPJ No.
24.808.811/0001-81, com sua sede Rua Jos� de Alvarenga, 394, sobreloja sala 5,
Centro, Duque de Caxias/RJ, CEP: 25.020-140 e filiais<span
style='mso-spacerun:yes'>� </span>(Nova Igua�u) Avenida Governador Amaral
Peixoto, 130, 8� andar, sala 801, Centro de Nova Igua�u/RJ, CEP 26.210-060; -
(Rio de Janeiro) Avenida Presidente Vargas, 633, 11 andar, sala 1121, Centro, Rio
de Janeiro/RJ, CEP 20.071-003; �- (Niter�i) Rua da Concei��o, 13, sala 308,
3�andar, Centro Niter�i/RJ, CEP 24.020-084, � (Campo Grande) Rua Campo Grande,
1014, sala 322, 5 andar, Centro, Campo Grande/RJ, CEP 23.080-000 <span
style='mso-spacerun:yes'>�</span>neste ato representada por quem de direito,
doravante denominada simplesmente de CONTRATADA</span></b><b style='mso-bidi-font-weight:
normal'><span lang=PT-BR style='font-size:9.0pt;mso-bidi-font-size:11.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>.<span
style='mso-tab-count:1'>�������������� </span> <o:p></o:p></span></b></p>

<p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;text-align:
justify;text-justify:inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:
normal'><span lang=PT-BR style='font-size:9.0pt;mso-bidi-font-size:11.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'><span
style='mso-spacerun:yes'>�������������������������� </span><span
style='mso-tab-count:1'>��� </span></span></b><b style='mso-bidi-font-weight:
normal'><span lang=PT-BR style='font-size:10.0pt;mso-bidi-font-size:11.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'><o:p></o:p></span></b></p>

<p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;text-align:
justify;text-justify:inter-ideograph;line-height:normal'><b style='mso-bidi-font-weight:
normal'><span lang=PT-BR style='font-size:9.0pt;mso-bidi-font-size:11.0pt;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'><o:p>&nbsp;</o:p></span></b></p>

<p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;text-align:
justify;text-justify:inter-ideograph;line-height:normal'><b style='mso-bidi-font-weight:
normal'><span lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>As partes acima
identificadas t�m entre si justas e acertadas o presente contrato, que ser�
regido pelas seguintes cl�usulas: <o:p></o:p></span></b></p>

<p class=MsoNormal style='margin-bottom:0in;margin-bottom:.0001pt;text-align:
justify;text-justify:inter-ideograph;line-height:normal'><b style='mso-bidi-font-weight:
normal'><span lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'><o:p>&nbsp;</o:p></span></b></p>

<p class=MsoNormal align=center style='margin-bottom:0in;margin-bottom:.0001pt;
text-align:center;line-height:normal'><b style='mso-bidi-font-weight:normal'><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'><o:p></o:p></span></b></p>

<p class=MsoNormal align=center style='margin-bottom:8.0pt;text-align:center;
line-height:125%'><b style='mso-bidi-font-weight:normal'><u><span lang=PT-BR
style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;font-family:
"Arial","sans-serif";mso-fareast-font-family:Arial'>DO <span style='background:
white'>OBJETO<o:p></o:p></span></span></u></b></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:normal'><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;background:white'><o:p>&nbsp;</o:p></span></b></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:normal'><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;background:white'>CL�USULA
PRIMEIRA</span></b><b style='mso-bidi-font-weight:normal'><span lang=PT-BR
style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;font-family:
"Arial","sans-serif";mso-fareast-font-family:Arial'>: </span></b><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>A<b
style='mso-bidi-font-weight:normal'> CONTRATADA</b> se obriga a prestar ao <b
style='mso-bidi-font-weight:normal'>CONTRATANTE</b> seus servi�os
profissionais, com zelo e dedica��o, na defesa de seus direitos e interesses,
cuja extens�o destes se refere a<b style='mso-bidi-font-weight:normal'> </b>direitos
mantidos pela autarquia, a fim de oportunizar os recebimentos de valores,
aproximadamente equivalentes � m�dia aritm�tica simples das �ltimas 12 (doze)
remunera��es do segurado, oficialmente obtidas em virtude do �ltimo contrato de
emprego, tendo como par�metro o m�ltiplo de 4 (quatro), ter� o recebimento das
quantias devidas , ficando ciente do dep�sito do valor a ser liberado pela
Autarquia; ressalvada, entretanto, eventual mudan�a de legisla��o ou ordens
normativas.<o:p></o:p></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:normal'><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>Par�grafo
Primeiro: </span></b><span lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:
11.0pt;line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:
Arial'>A<b style='mso-bidi-font-weight:normal'> CONTRATADA</b> representar� a <b
style='mso-bidi-font-weight:normal'>CONTRATANTE </b>perante �rg�os p�blicos
(Reparti��es Federais, Estaduais, Municipais e outros) ou Privados, mediante
procura��o com firma reconhecida por autenticidade em cart�rio de notas, sempre
em conformidade com o servi�o para o qual foi contratado.<o:p></o:p></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:normal'><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>Par�grafo
Segundo:</span></b><span lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:
11.0pt;line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:
Arial'> Fica vedado a<b style='mso-bidi-font-weight:normal'> CONTRATADA</b>
propor ou responder demandas al�m do previsto no <i style='mso-bidi-font-style:
normal'>caput </i>desta Cl�usula, bem como atuar em desconformidade com os
poderes que lhe foram outorgados, sem que haja pr�via autoriza��o expressa do <b
style='mso-bidi-font-weight:normal'>CONTRATANTE</b>.<o:p></o:p></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:normal'><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'><o:p>&nbsp;</o:p></span></b></p>

<p class=MsoNormal align=center style='margin-bottom:8.0pt;text-align:center;
line-height:125%'><b style='mso-bidi-font-weight:normal'><u><span lang=PT-BR
style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;font-family:
"Arial","sans-serif";mso-fareast-font-family:Arial'>DAS OBRIGA��ES:<o:p></o:p></span></u></b></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:normal'><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>CL�USULA
SEGUNDA: </span></b><span lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:
11.0pt;line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:
Arial'>A<b style='mso-bidi-font-weight:normal'> CONTRATADA</b> tem obriga��o de
dedicar seus melhores esfor�os na presta��o dos servi�os contratados. Por�m, a <b
style='mso-bidi-font-weight:normal'>CONTRATANTE</b> fica desde j� ciente de que
a presta��o de servi�o de intermedia��o � uma atividade de meio, e n�o de
resultado, de modo que n�o � poss�vel garantir o �xito favor�vel ao <b
style='mso-bidi-font-weight:normal'>CONTRATANTE </b>no final da demanda.</span><b
style='mso-bidi-font-weight:normal'><span lang=PT-BR style='font-size:13.0pt;
mso-bidi-font-size:11.0pt;line-height:125%;font-family:"Times New Roman","serif";
mso-fareast-font-family:"Times New Roman"'> <o:p></o:p></span></b></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:normal'><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>Par�grafo
Primeiro: </span></b><span lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:
11.0pt;line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:
Arial'>A<b style='mso-bidi-font-weight:normal'> CONTRATADA</b> obriga-se a
tratar como mat�ria sigilosa e confidencial todas as informa��es
administrativas, comerciais ou de qualquer natureza que lhe forem fornecidas
pelo(a) <b style='mso-bidi-font-weight:normal'>CONTRATANTE</b>, com a ressalva
do que for necess�rio para fundamentar pedidos e notifica��es, zelando pelo
sigilo destas informa��es durante e ap�s o t�rmino da presta��o dos servi�os.<b
style='mso-bidi-font-weight:normal'> <o:p></o:p></b></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b><span lang=PT-BR style='font-size:12.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>CL�USULA
TERCEIRA:</span></b><b style='mso-bidi-font-weight:normal'><u><span lang=PT-BR
style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;font-family:
"Arial","sans-serif";mso-fareast-font-family:Arial;text-transform:uppercase'> </span></u></b><u><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>A <b
style='mso-bidi-font-weight:normal'>CONTRATANTE</b> dever� informar a<b
style='mso-bidi-font-weight:normal'> CONTRATADA,</b> no ato da assinatura do
presente, se j� recebeu algum benef�cio ou encontra-se recebendo-o, tais como: <b
style='mso-bidi-font-weight:normal'>Licen�a-Maternidade, Sal�rio Maternidade,
Auxilio Maternidade, Sal�rio Natalidade ou outros de mesma natureza;</b> a qual
firmar� declara��o competente; evitando-se com isso a cobran�a repetit�ria do
direito aqui requerido. <o:p></o:p></span></u></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:normal'><u><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>Par�grafo
�nico:</span></u></b><u><span lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:
11.0pt;line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:
Arial'> Fica desde j� pactuado que os honor�rios pelos servi�os ora prestados,
prevalecer�o mesmo em caso de diversidade de informa��es prestadas pelo <b
style='mso-bidi-font-weight:normal'>CONTRATANTE. <o:p></o:p></b></span></u></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:normal'><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'><o:p>&nbsp;</o:p></span></b></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:normal'><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>CL�USULA QUARTA:
</span></b><span lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>A<b
style='mso-bidi-font-weight:normal'> CONTRATADA<span style='background:white'> s</span></b>�
poder� devolver os documentos originais ou prestar informa��es da <b
style='mso-bidi-font-weight:normal'><span style='text-transform:uppercase'>CONTRATANTE</span></b>
a terceiros ou a parentes, devendo-se observar o seguinte: <o:p></o:p></span></p>

<p class=MsoListParagraphCxSpFirst style='margin-bottom:8.0pt;mso-add-space:
auto;text-align:justify;text-justify:inter-ideograph;text-indent:-.5in;
line-height:125%;mso-list:l3 level1 lfo2'><![if !supportLists]><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'><span
style='mso-list:Ignore'>A)<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span></span><![endif]><span lang=PT-BR style='font-size:12.0pt;
mso-bidi-font-size:11.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'>Em caso de �bito o mesmo se dar� mediante
apresenta��o de c�pia da certid�o de �bito autenticada;<o:p></o:p></span></p>

<p class=MsoListParagraphCxSpLast style='margin-top:0in;margin-right:0in;
margin-bottom:8.0pt;margin-left:0in;mso-add-space:auto;text-align:justify;
text-justify:inter-ideograph;text-indent:0in;line-height:125%;mso-list:l3 level1 lfo2'><![if !supportLists]><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'><span
style='mso-list:Ignore'>B)<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</span></span></span><![endif]><span lang=PT-BR style='font-size:12.0pt;
mso-bidi-font-size:11.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'>Na hip�tese de tratamento m�dico, no qual esteja
impossibilitada de se locomover, conforme laudo m�dico, ficando assim vedado
passar informa��es da <b style='mso-bidi-font-weight:normal'><span
style='text-transform:uppercase'>CONTRATANTE </span></b>a terceiros ou
parentes.<o:p></o:p></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:normal'><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'><o:p>&nbsp;</o:p></span></b></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:normal'><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>CL�USULA QUINTA:
</span></b><span lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>A
<b style='mso-bidi-font-weight:normal'>CONTRATANTE</b> fica ciente que em
nenhuma hip�tese poder� receber valores decorrentes dos servi�os aqui
prestados, atrav�s de representa��o de terceiros, assim compreendidos: </span><span
lang=PT-BR style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'>conjugue parentes, amigos, dentre outros; sendo
certo </span><span lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>que
este direito somente poder� ser exercido atrav�s do acompanhamento de um
respons�vel indicado pela ora </span><b><span lang=PT-BR style='font-size:12.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;
color:black;mso-themecolor:text1'>CONTRATADA</span></b><span lang=PT-BR
style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial;color:black;mso-themecolor:text1;mso-bidi-font-weight:
bold'>, conforme assim preceituam a <b>Cl�usula</b></span><b style='mso-bidi-font-weight:
normal'><span lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>
Vig�sima Primeira</span></b><span lang=PT-BR style='font-size:12.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;
color:red;mso-bidi-font-weight:bold'> </span><b><span lang=PT-BR
style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'>Par�grafo, Primeiro e Segundo da</span></b><span
lang=PT-BR style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial;color:red;mso-bidi-font-weight:bold'> </span><b
style='mso-bidi-font-weight:normal'><span lang=PT-BR style='font-size:12.0pt;
mso-bidi-font-size:11.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'>Cl�usula Vig�sima Primeira.<o:p></o:p></span></b></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><span lang=PT-BR style='font-size:12.0pt;
mso-bidi-font-size:11.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial;color:red'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:normal'><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>CL�USULA SEXTA:
</span></b><span lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>Caso
a<b style='mso-bidi-font-weight:normal'> <span style='text-transform:uppercase'>CONTRATANTE</span>
</b>esteja em cust�dia da justi�a, somente os advogados habilitados com
procura��o com firma reconhecida e v�lida, os quais poder�o ter acesso �s
informa��es e obter c�pia dos documentos anexa ao procedimento administrativo
competente, mediante, ainda a comprova��o da cust�dia de seu constituinte.<span
style='mso-spacerun:yes'>� </span><o:p></o:p></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><span lang=PT-BR style='font-size:12.0pt;
mso-bidi-font-size:11.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:normal'><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>CL�USULA SETIMA:
</span></b><span lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>A
<b style='mso-bidi-font-weight:normal'>CONTRATANTE</b> dever� se dirigir ao
escrit�rio da<b style='mso-bidi-font-weight:normal'> CONTRATADA</b> munida de
seus documentos pessoais originais (Rg, Cpf, comprovante de resid�ncia e, em
caso de casado, certid�o de casamento), sempre em hor�rio a ser previamente agendado
para obter o extrato e a libera��o do pagamento,<b style='mso-bidi-font-weight:
normal'> </b>juntamente com todos os documentos originais por ela deixados,
mesmo que tenha recebido qualquer correspond�ncia da autarquia, <span
style='color:black;mso-themecolor:text1'>conforme assim disp�e na </span><b
style='mso-bidi-font-weight:normal'>Cl�usula Vig�sima.<span style='color:red'> <o:p></o:p></span></b></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><span lang=PT-BR style='font-size:12.0pt;
mso-bidi-font-size:11.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial;color:red'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:normal'><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>CL�USULA OITAVA</span></b><b><span
lang=PT-BR style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'>: </span></b><span lang=PT-BR style='font-size:
12.0pt;line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:
Arial'>A <b>CONTRATADA </b>devolver� a nota promiss�ria, hora emitida e assinada
pela <b style='mso-bidi-font-weight:normal'>CONTRATANTE</b>, conforme se refere<b>
</b><span style='mso-bidi-font-weight:bold'>o disposto no</span><b
style='mso-bidi-font-weight:normal'><span style='color:#0070C0'> </span>Par�grafo
Primeiro e Segundo da Cl�usula D�cima Sexta</b><span style='background:white;
mso-bidi-font-weight:bold'>,</span> devolu��o esta que se dar� no ato do
pagamento dos honor�rios aqui pactuados neste contrato; excetuando-se a
hip�tese da<b> CONTRATANTE</b> omitir o que j� efetivamente recebeu, tais como:
<b><u>Licen�a-Maternidade, Sal�rio Maternidade, Auxilio Maternidade, Sal�rio Natalidade;</u>
<o:p></o:p></b></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:normal'><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;color:#0070C0'><o:p>&nbsp;</o:p></span></b></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:normal'><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>CL�USULA NONA</span></b><b
style='mso-bidi-font-weight:normal'><span lang=PT-BR style='font-size:12.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>:</span></b><u><span
lang=PT-BR style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'> A <b style='mso-bidi-font-weight:normal'>CONTRATANTE
</b>fica ciente que os documentos havidos em xerox autenticada, assim como a o
instrumento de procura��o por esta deixada, ficar�o anexados e arquivados no
procedimento administrativo junto � autarquia.</span></u><b style='mso-bidi-font-weight:
normal'><span lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'><o:p></o:p></span></b></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:normal'><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>CL�USULA D�CIMA</span></b><b
style='mso-bidi-font-weight:normal'><span lang=PT-BR style='font-size:12.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>:</span></b><span
lang=PT-BR style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial;text-transform:uppercase'> A</span><span
lang=PT-BR style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'> <b>CONTRATANTE</b><span style='background:white'>
se obriga a fornecer todos elementos necess�rios � defesa de seus direitos, </span><span
style='mso-bidi-font-weight:bold'>conforme assim preceituam o <b><span
style='background:red;mso-highlight:red'>Par�grafo Terceiro</span></b></span><b
style='mso-bidi-font-weight:normal'><span style='background:red;mso-highlight:
red'> Cl�usula Vig�sima Quarta</span></b><span style='background:red;
mso-highlight:red;mso-shading:white'> <b style='mso-bidi-font-weight:normal'><span
style='mso-spacerun:yes'>�</span>e a letra � do </b></span><b style='mso-bidi-font-weight:
normal'><span style='background:red;mso-highlight:red'>Par�grafo Primeiro<span
style='mso-shading:white'> da </span>Cl�usula Vig�sima Quinta</span></b><span
style='background:red;mso-highlight:red'>,</span> assim como os <span
style='background:white'>documentos originais ess�ncias ao procedimento
administrativo, sendo estes: <b>Carteira Profissional, Rescis�o Contratual e
Seguro Desemprego</b><span style='mso-bidi-font-weight:bold'>, assim </span>xerox
autenticada dos mesmos; comprometendo-se a cumprir as instru��es que lhes forem
dadas a cada etapa pela <b>CONTRATADA.<o:p></o:p></b></span></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b><span lang=PT-BR style='font-size:12.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;
background:white'><o:p>&nbsp;</o:p></span></b></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b><span lang=PT-BR style='font-size:12.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;
background:white'>Par�grafo �nico:</span></b><span lang=PT-BR style='font-size:
12.0pt;line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:
Arial'> Tendo em vista que durante a demanda <span style='mso-bidi-font-weight:
bold'>haver� uma ou mais audi�ncias administrativas para periciar os documentos,
</span>poder� o Agente P�blico requerer informa��es ou constatar a veracidade
das informa��es prestadas, para cujos atos ser�o instru�dos dos documentos
originais correspondentes<b>.</b><b style='mso-bidi-font-weight:normal'> <o:p></o:p></b></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:normal'><span
lang=PT-BR style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'><o:p>&nbsp;</o:p></span></b></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:normal'><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>CL�USULA D�CIMA
PRIMEIRA:</span></b><b><span lang=PT-BR style='font-size:12.0pt;line-height:
125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'> </span></b><span
lang=PT-BR style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial;mso-bidi-font-weight:bold'>Considerando que
durante o procedimento administrativo o �rg�o P�blico venha a necessitar da
apresenta��o do original da Carteira Profissional de Trabalho para fins de certificar
a autenticidade das c�pias apresentadas, a <b>CONTRATADA </b>solicitara para a<b>
CONTRATANTE </b>o referido documento, que hora deixara voluntariamente de posse
da<span style='mso-spacerun:yes'>� </span><b>CONTRATADA</b> para que fique em
seu poder, at� o termino da demanda conforme assim lhe autorizam a Instru��o
Normativa 77/2015, </span><span lang=PT-BR style='font-size:12.0pt;line-height:
125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>c</span><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>onforme assim
disp�e no</span><b><span lang=PT-BR style='font-size:12.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;background:white'>
Par�grafo P</span></b><b style='mso-bidi-font-weight:normal'><span lang=PT-BR
style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;font-family:
"Arial","sans-serif";mso-fareast-font-family:Arial'>rimeiro </span></b><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>e</span><b><span
lang=PT-BR style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'> Segundo</span></b><span lang=PT-BR
style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'><span style='mso-spacerun:yes'>� </span>da <b
style='mso-bidi-font-weight:normal'>Cl�usula Vig�sima Quarta</b>.<o:p></o:p></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><span lang=PT-BR style='font-size:12.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;
mso-bidi-font-weight:bold'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b><span lang=PT-BR style='font-size:12.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;
background:white'>Par�grafo �nico: </span></b><span lang=PT-BR
style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial;background:white;mso-bidi-font-weight:bold'>Declara
a <b>CONTRATANTE</b></span><span lang=PT-BR style='font-size:12.0pt;line-height:
125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;mso-bidi-font-weight:
bold'> que este ato � de sua plena e irrevog�vel concord�ncia, a qual, para os
devidos fins de direito, permite e concorda em deixa-lo em poder da ora <b>CONTRATADA</b>
at� que terminem todas as etapas do procedimento administrativo. Findo o
procedimento, a <b>CONTRATADA</b> se obriga a devolver a <b>CONTRATANTE</b> o
original da Carteira Profissional de Trabalho,</span><span lang=PT-BR
style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;font-family:
"Arial","sans-serif";mso-fareast-font-family:Arial'> conf</span><span
lang=PT-BR style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial;mso-bidi-font-weight:bold'>orme as regras
estabelecidas n</span><span lang=PT-BR style='font-size:12.0pt;line-height:
125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>o <b>Par�grafo
Primeiro </b><b style='mso-bidi-font-weight:normal'>e segundo da Cl�usula
Vig�sima Quarta<span style='mso-bidi-font-weight:bold'>,</span></b><span
style='mso-bidi-font-weight:bold'> mediante assinatura de Termo de Reten��o e Restitui��o<b>.<o:p></o:p></b></span></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><span lang=PT-BR style='font-size:12.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:normal'><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>CL�USULA D�CIMA
SEGUNDA:</span></b><b><span lang=PT-BR style='font-size:12.0pt;line-height:
125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'> </span></b><span
lang=PT-BR style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial;mso-bidi-font-weight:bold'>Caso venha a ocorrer o
recebimento de alguma correspond�ncia da autarquia concessora, a<b> CONTRATANTE
</b>dever� levar imediatamente ao conhecimento da <b>CONTRATADA </b>a
exist�ncia desta, bastando para tanto que se dirija ao escrit�rio desta, independentemente
do que estiver escrito no corpo da respectiva correspond�ncia, observando-se
para tanto </span><span lang=PT-BR style='font-size:12.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;background:white'>as
instru��es procedimentais dadas pela </span><b><span lang=PT-BR
style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'>CONTRATADA </span></b><span lang=PT-BR
style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial;mso-bidi-font-weight:bold'>em conformidade com a
letra (<b>a</b>) do </span><b style='mso-bidi-font-weight:normal'><span
lang=PT-BR style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'>Par�grafo Primeiro da Cl�usula Vig�sima Quinta.</span></b><span
lang=PT-BR style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'><o:p></o:p></span></p>

<p class=MsoNormal align=center style='margin-bottom:8.0pt;text-align:center;
line-height:125%'><b style='mso-bidi-font-weight:normal'><u><span lang=PT-BR
style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:"Times New Roman"'>DO PRAZO DE VIGENCIA</span></u></b><b
style='mso-bidi-font-weight:normal'><u><span lang=PT-BR style='font-size:12.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'><o:p></o:p></span></u></b></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:normal'><span
lang=PT-BR style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'><o:p>&nbsp;</o:p></span></b></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:normal'><span
lang=PT-BR style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'>CL�USULA D�CIMA TERCEIRA: </span></b><span
lang=PT-BR style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'>O prazo para t�rmino dos servi�os aqui
contratados � de 60 (sessenta dias) �teis, cujo prazo vigorar� no ato da
assinatura do presente contrato, ou do </span><span lang=PT-BR
style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;font-family:
"Arial","sans-serif";mso-fareast-font-family:Arial'>in�cio da data da entrega </span><span
lang=PT-BR style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'>dos documentos estabelecidos neste contrato, o
que primeiro ocorrer; tudo conforme</span><b style='mso-bidi-font-weight:normal'><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'> </span></b><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>estabelece <b
style='mso-bidi-font-weight:normal'>Par�grafo Segundo da </b></span><b
style='mso-bidi-font-weight:normal'><span lang=PT-BR style='font-size:12.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>Cl�usula
D�cima Terceira.<span style='mso-bidi-font-weight:bold'><o:p></o:p></span></span></b></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b><span lang=PT-BR style='font-size:12.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>Par�grafo
Primeiro: </span></b><span lang=PT-BR style='font-size:12.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;mso-bidi-font-weight:
bold'>D</span><span lang=PT-BR style='font-size:12.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>entro do prazo estabelecido
no <i style='mso-bidi-font-style:normal'>caput</i> deste artigo, poder� haver haver�
audi�ncias administrativas para fins de realiza��o de per�cia dos documentos
deixados pela <b style='mso-bidi-font-weight:normal'>CONTRATANTE. <o:p></o:p></b></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:normal'><span
lang=PT-BR style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'><o:p>&nbsp;</o:p></span></b></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b><span lang=PT-BR style='font-size:12.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>Par�grafo
Segundo: </span></b><span lang=PT-BR style='font-size:12.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>A <b>CONTRATANTE
</b>fica ciente<b> </b>que o prazo estabelecido no <i style='mso-bidi-font-style:
normal'>caput</i><b>, </b>poder� ser prorrogado de forma autom�tica e por lapso
de tempo indeterminado, nas seguintes hip�teses: <o:p></o:p></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><span lang=PT-BR style='font-size:12.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'><o:p>&nbsp;</o:p></span></p>

<p class=MsoListParagraphCxSpFirst style='margin-bottom:8.0pt;mso-add-space:
auto;text-align:justify;text-justify:inter-ideograph;text-indent:-.25in;
line-height:125%;mso-list:l2 level1 lfo3'><![if !supportLists]><span
lang=PT-BR style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'><span style='mso-list:Ignore'>a)<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp; </span></span></span><![endif]><span
lang=PT-BR style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'>No caso de existir greve dos funcion�rios e
servidores da autarquia;<o:p></o:p></span></p>

<p class=MsoListParagraphCxSpMiddle style='margin-bottom:8.0pt;mso-add-space:
auto;text-align:justify;text-justify:inter-ideograph;text-indent:-.25in;
line-height:125%;mso-list:l2 level1 lfo3'><![if !supportLists]><span
lang=PT-BR style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'><span style='mso-list:Ignore'>b)<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp; </span></span></span><![endif]><span
lang=PT-BR style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'>Para cumprir exig�ncias de documentos requeridas
pela autarquia;<o:p></o:p></span></p>

<p class=MsoListParagraphCxSpLast style='margin-bottom:8.0pt;mso-add-space:
auto;text-align:justify;text-justify:inter-ideograph;text-indent:-.25in;
line-height:125%;mso-list:l2 level1 lfo3'><![if !supportLists]><span
lang=PT-BR style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'><span style='mso-list:Ignore'>c)<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp; </span></span></span><![endif]><span
lang=PT-BR style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'>Greve banc�ria ou quaisquer outros motivos de
caso fortuito ou for�a maior que determine a extens�o dos prazos aqui
estabelecidos.<o:p></o:p></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:normal'><span
lang=PT-BR style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'><o:p>&nbsp;</o:p></span></b></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:normal'><span
lang=PT-BR style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'>CL�USULA D�CIMA QUARTA</span></b><b
style='mso-bidi-font-weight:normal'><span lang=PT-BR style='font-size:12.0pt;
mso-bidi-font-size:11.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'>: </span></b><span lang=PT-BR style='font-size:
12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'>Na falta de algum documento estabelecido neste
contrato, o <b style='mso-bidi-font-weight:normal'>CONTRATANTE </b>ficar�
ciente que o prazo previsto na <b style='mso-bidi-font-weight:normal'>Cl�usula D�cima
Terceira </b>ser� alterado e suspenso, e s� ter� rein�cio a partir da data da
entrega dos mesmos, se estendendo tamb�m para no caso de contratantes gestantes
em fase gestacional.<b style='mso-bidi-font-weight:normal'> </b><o:p></o:p></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:normal'><span
lang=PT-BR style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'>CL�USULA D�CIMA QUINTA</span></b><b
style='mso-bidi-font-weight:normal'><span lang=PT-BR style='font-size:12.0pt;
mso-bidi-font-size:11.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'>: </span></b><span lang=PT-BR style='font-size:
12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'>A <b style='mso-bidi-font-weight:normal'>CONTRATANTE
</b>fica ciente<b style='mso-bidi-font-weight:normal'> </b>que ap�s an�lise
documental feita pela <b style='mso-bidi-font-weight:normal'>CONTRATADA,</b> esta
fica autorizada a no prazo de 48(quarenta e oito horas) h<span
style='background:white'>abilitar � per�cia junto � Autarquia, bem como a dar continuidade
a demanda no qual foi contratado, em conformidade com a <b style='mso-bidi-font-weight:
normal'>Cl�usula Primeira e </b></span><b style='mso-bidi-font-weight:normal'>Par�grafo
Primeiro<span style='background:white'> da Cl�usula Primeira<span
style='color:red'>. <o:p></o:p></span></span></b></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:normal'><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;color:red;
background:white'><o:p>&nbsp;</o:p></span></b></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:normal'><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>Par�grafo Primeiro</span></b><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>: Dentro do
prazo de 48 horas a <b style='mso-bidi-font-weight:normal'>CONTRATANTE</b>
poder� cancelar a seu nuto o seu procedimento administrativo, mediante pr�vio pagamento
de uma taxa no valor de R$100,00 (Cem Reais), al�m dos valores correspondentes
as despesas e emolumentos cartor�rios (ex.: Xerox autenticadas, assinatura por
autenticidade, <span style='mso-spacerun:yes'>�</span>abertura de firma e outros).<o:p></o:p></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><span lang=PT-BR style='font-size:12.0pt;
mso-bidi-font-size:11.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:normal'><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>Par�grafo Segundo:</span></b><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'> Ultrapassado o
prazo de 48 horas estabelecido no <i style='mso-bidi-font-style:normal'>caput</i>,
este instrumento somente poder� ser revogado, mediante o pagamento do valor da
nota promiss�ria a que se refere no</span><span lang=PT-BR style='font-size:
12.0pt;line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:
Arial;mso-bidi-font-weight:bold'> Par�grafo Primeiro</span><span lang=PT-BR
style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;font-family:
"Arial","sans-serif";mso-fareast-font-family:Arial'> da Cl�usula D�cima Sexta.<span
style='color:red;background:white'><o:p></o:p></span></span></p>

<p class=MsoNormal align=center style='margin-bottom:8.0pt;text-align:center;
line-height:125%'><b style='mso-bidi-font-weight:normal'><span lang=PT-BR
style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;font-family:
"Arial","sans-serif";mso-fareast-font-family:Arial;background:white'>DOS
HONOR�RIOS:</span></b><b style='mso-bidi-font-weight:normal'><span lang=PT-BR
style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;font-family:
"Arial","sans-serif";mso-fareast-font-family:Arial'><o:p></o:p></span></b></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:normal'><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'><o:p>&nbsp;</o:p></span></b></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:normal'><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>CL�USULA D�CIMA
SEXTA: </span></b><span lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:
11.0pt;line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:
Arial'>Pelos servi�os aqui pactuados, a<b style='mso-bidi-font-weight:normal'>
CONTRATANTE</b><span style='color:red'> </span>se obriga a pagar a <b
style='mso-bidi-font-weight:normal'>CONTRATADA</b> o valor equivalente a <b
style='mso-bidi-font-weight:normal'>30%</b> <b style='mso-bidi-font-weight:
normal'>(trinta por cento)</b> do valor l�quido liberado, que poder� variar de
R$2.000,00 (Dois Mil Reais) a R$4.000,00 (Quatro Mil Reais), sendo que para as
hip�teses de pagamento parcelado, o mesmo percentual incidir� sobre o valor de
cada uma das parcelas.<o:p></o:p></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><span lang=PT-BR style='font-size:12.0pt;
mso-bidi-font-size:11.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial;color:red'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b><span lang=PT-BR style='font-size:12.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>Par�grafo
Primeiro � Da Garantia: </span></b><span lang=PT-BR style='font-size:12.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>A
<b><span style='background:white'>CONTRATANTE,</span> </b>no ato da assinatura
deste contrato, <span style='mso-bidi-font-weight:bold'>n�o se op�e em emitir
em favor da <b>CONTRATADA</b></span> uma nota promiss�ria no valor de R$1.500,00
(Hum mil e quinhentos Reais), que corresponder� a aproximadamente o percentual
de <b>30% (trinta por cento) </b>do valor informado na <b>Cl�usula D�cima Sexta</b><span
style='mso-bidi-font-weight:bold'>, acrescido de <b>20%</b></span> <b>(vinte
por cento)</b> das despesas, conforme <b style='mso-bidi-font-weight:normal'>Cl�usula
Vig�sima Terceira</b> podendo estes sofrer varia��es para mais ou para menos. <b><span
style='mso-spacerun:yes'>��</span><o:p></o:p></b></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><span lang=PT-BR style='color:#00B0F0'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b><span lang=PT-BR style='font-size:12.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>Par�grafo
Segundo: </span></b><span lang=PT-BR style='font-size:12.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>A nota
promiss�ria assinada, ser� devolvida a <b><span style='background:white'>CONTRATANTE</span></b>
no ato do efetivo pagamento dos honor�rios pactuados,<span style='mso-bidi-font-weight:
bold'> mediante assinatura de Termo de Restitui��o de Documento Original</span>,
dando assim plena, rasa e total quita��o deste contrato <span style='mso-bidi-font-weight:
bold'>em conformidade com a </span></span><span lang=PT-BR style='font-size:
12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial;background:red;mso-highlight:red'>Cl�usula Oitava</span><span
lang=PT-BR style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial;background:red;mso-highlight:red;mso-bidi-font-weight:
bold'>.</span><span lang=PT-BR style='font-size:12.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;mso-bidi-font-weight:
bold'><o:p></o:p></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><span lang=PT-BR style='font-size:12.0pt;
mso-bidi-font-size:11.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b><span lang=PT-BR style='font-size:12.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>Par�grafo
Terceiro<span style='color:#0070C0'>:</span> </span></b><span lang=PT-BR
style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial;mso-bidi-font-weight:bold'>Sendo indeferido o
procedimento da <b><span style='background:white'>CONTRATANTE</span></b></span><span
lang=PT-BR style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial;background:white'>, e sendo confirmada que esta
n�o fa�a jus em receber seu direito</span><span lang=PT-BR style='font-size:
12.0pt;line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:
Arial'>, a nota promiss�ria assinada ser� anulada e inutilizada na presen�a da <b><span
style='background:white'>CONTRATANTE. </span></b><span style='background:white;
mso-bidi-font-weight:bold'>Este expediente n�o<b> </b>prevalecer�, entretanto,<b>
</b>para as hip�teses d</span>a <b><span style='background:white'>CONTRATANTE</span></b><span
style='background:white'> omitir que j� tenha recebido quaisquer outros valores
por meio de procedimentos fraudulentos de buscar receber o que j� recebera
anteriormente o que requer por meio deste contrato</span> <span
style='mso-bidi-font-weight:bold'>em conformidade com a</span> o <b
style='mso-bidi-font-weight:normal'>Par�grafo Primeiro e Segundo da Cl�usula
D�cima Sexta e<span style='mso-bidi-font-weight:bold'> </span></b></span><b
style='mso-bidi-font-weight:normal'><span lang=PT-BR style='font-size:12.0pt;
mso-bidi-font-size:11.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'>Cl�usula Oitava</span></b><b><span lang=PT-BR
style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'>.<o:p></o:p></span></b></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:normal'><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'><o:p>&nbsp;</o:p></span></b></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:normal'><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>CL�USULA D�CIMA
S�TIMA: </span></b><span lang=PT-BR style='font-size:12.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;mso-bidi-font-weight:
bold'>Considerando que a</span><span lang=PT-BR style='font-size:12.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;
color:red'> </span><b style='mso-bidi-font-weight:normal'><span lang=PT-BR
style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'>CONTRATANTE</span></b><span lang=PT-BR
style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'> omita dolosamente o que j� recebeu a t�tulo de <b>Licen�a-Maternidade,
Sal�rio Maternidade, Auxilio Maternidade, Sal�rio natalidade, </b>na ardil e
enganosa tentativa de receber estes benef�cios outra vez, a nota promiss�ria a
que se refere o <b style='mso-bidi-font-weight:normal'>Par�grafo Primeiro e Segundo
da Cl�usula D�cima Sexta</b>, n�o ser� cancelada, anulada ou inutilizada, <span
style='mso-bidi-font-weight:bold'>podendo a mesma servir de t�tulo executivo em
processo judicial de execu��o</span>.<o:p></o:p></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><span lang=PT-BR style='font-size:12.0pt;
mso-bidi-font-size:11.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:normal'><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>CL�USULA D�CIMA
OITAVA: </span></b><span lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:
11.0pt;line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:
Arial'>A <b style='mso-bidi-font-weight:normal'><span style='background:white'>CONTRATANTE
</span></b><span style='background:white'>receber� uma �nica parcela no valor
que poder� variar entre R$2.000,00 (Dois Mil Reais) a R$4.000,00 (Quatro Mil
Reais) para a hip�tese de existir menores imp�beres com idade superior de 04 (quatro)
meses.<o:p></o:p></span></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><span lang=PT-BR style='font-size:12.0pt;
mso-bidi-font-size:11.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial;background:white'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:normal'><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>Par�grafo Primeiro:
</span></b><span lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>E<span
style='background:white'>m caso de existir </span>crian�a menor de 04 (Quatro)
meses na data do efetivo pagamento do benef�cio a ser creditado,<span
style='background:white'> fica ciente a </span><b style='mso-bidi-font-weight:
normal'>CONTRATANTE</b> que receber� proporcional aos meses de idade da crian�a
ate no m�ximo 04 (Quatro) parcelas conforme <b style='mso-bidi-font-weight:
normal'><span style='background:white'>Cl�usula Primeira, </span></b><span
style='background:white'>do objeto deste contrato.<o:p></o:p></span></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><span lang=PT-BR style='font-size:12.0pt;
mso-bidi-font-size:11.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial;background:white'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:normal'><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>Par�grafo Segundo:
</span></b><span lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;
background:white'>A <b style='mso-bidi-font-weight:normal'>CONTRATANTE</b> fica
ciente que em caso de retorno ao trabalho no per�odo correspondente a 04
(Quatro) meses do nascimento da crian�a, este receber� de forma proporcional
aos dias em que n�o trabalhou. <o:p></o:p></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:normal'><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>CL�USULA D�CIMA
NONA: </span></b><span lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:
11.0pt;line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:
Arial'>A <b style='mso-bidi-font-weight:normal'>CONTRATADA</b><span
style='color:black'> </span>fica autorizada a deduzir dos valores recebidos
para o <b style='mso-bidi-font-weight:normal'>CONTRATANTE</b>, � import�ncia
referente a honor�rios e despesas, aqui pactuados neste contrato, compreendidos
na <b style='mso-bidi-font-weight:normal'><span style='background:red;
mso-highlight:red'>Cl�usula D�cima Sexta</span></b><span style='background:
red;mso-highlight:red'> e </span></span><b style='mso-bidi-font-weight:normal'><span
lang=PT-BR style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial;background:red;mso-highlight:red'>Cl�usula
Vig�sima Terceira</span></b><b style='mso-bidi-font-weight:normal'><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;background:red;
mso-highlight:red'> </span></b><span lang=PT-BR style='font-size:12.0pt;
mso-bidi-font-size:11.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial;background:red;mso-highlight:red'>deste contrato</span><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>.<o:p></o:p></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><span lang=PT-BR style='font-size:12.0pt;
mso-bidi-font-size:11.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:normal'><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>CL�USULA
VIG�SIMA: </span></b><span lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:
11.0pt;line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:
Arial'>Para libera��o do recebimento dos direitos da <b style='mso-bidi-font-weight:
normal'>CONTRATANTE</b> a mesma dever� dirigir-se ao escrit�rio da<b
style='mso-bidi-font-weight:normal'> CONTRATADA</b>, munida de R.G., CPF, Certid�o
de Casamento (ser for casada legalmente) e Comprovante de Endere�o, em hor�rio
a ser previamente agendado, para o qual retirar� o extrato e a libera��o do
pagamento<b style='mso-bidi-font-weight:normal'>,</b> <span style='background:
red;mso-highlight:red'>juntamente com todos</span> os documentos originais por
ela deixados, mesmo que tenha recebido anteriormente qualquer correspond�ncia
da autarquia concessora, conforme assim disp�e na<b style='mso-bidi-font-weight:
normal'> Cl�usula S�tima</b>. <o:p></o:p></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><span lang=PT-BR style='font-size:12.0pt;
mso-bidi-font-size:11.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:normal'><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>CL�USULA VIG�SIMA
PRIMEIRA:</span></b><span lang=PT-BR style='font-size:12.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'> <span
style='mso-bidi-font-weight:bold'>O requerimento do benef�cio objeto desta
contrata��o poder� tramitar em outros Munic�pios e Estados, ficando assim a <b>CONTRATANTE
</b>ciente que a <b>CONTRATADA </b>para tanto disponibilizar� de passagens
a�reas, transporte publico e de seus ve�culos pr�prio com seguran�as particulares
para fim de se fazer o traslado, e um �nico lugar, pois <span
style='mso-spacerun:yes'>�</span>poder� se valer de outras pessoas para o mesmo
dia e hor�rio combinado. </span></span><span lang=PT-BR style='font-size:12.0pt;
mso-bidi-font-size:11.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial;color:black;mso-themecolor:text1'><span
style='mso-spacerun:yes'>�</span><o:p></o:p></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><span lang=PT-BR style='font-size:12.0pt;
mso-bidi-font-size:11.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial;color:black;mso-themecolor:text1'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b><span lang=PT-BR style='font-size:12.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>Par�grafo
Primeiro:</span></b><span lang=PT-BR style='font-size:12.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;mso-bidi-font-weight:
bold'> No caso da <b>CONTRATANTE</b> se fazer acompanhada de conjugue,
parentes, amigos e outros afins, estes dever�o aguardar no endere�o do escrit�rio
da <b>CONTRATADA </b>at� que todo o procedimento de recebimento termine, </span><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;color:black;
mso-themecolor:text1'>conforme assim disp�e na</span><b style='mso-bidi-font-weight:
normal'><span lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>
<span style='background:red;mso-highlight:red'>Cl�usula Q</span></span></b><b
style='mso-bidi-font-weight:normal'><span lang=PT-BR style='font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial;background:red;mso-highlight:red'>uint</span></b><b
style='mso-bidi-font-weight:normal'><span lang=PT-BR style='font-size:12.0pt;
mso-bidi-font-size:11.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial;background:red;mso-highlight:red'>a</span></b><b><span
lang=PT-BR style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial;background:red;mso-highlight:red'> Cl�usula</span></b><b
style='mso-bidi-font-weight:normal'><span lang=PT-BR style='font-size:12.0pt;
mso-bidi-font-size:11.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial;background:red;mso-highlight:red'> Vig�sima
Primeira e</span></b><b><span lang=PT-BR style='font-size:12.0pt;line-height:
125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;background:
red;mso-highlight:red'> Par�grafo Segundo da </span></b><b style='mso-bidi-font-weight:
normal'><span lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;
background:red;mso-highlight:red'>Cl�usula Vig�sima Primeira</span></b><b
style='mso-bidi-font-weight:normal'><span lang=PT-BR style='font-size:12.0pt;
mso-bidi-font-size:11.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'>.<o:p></o:p></span></b></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><span lang=PT-BR style='font-size:12.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;
color:red;mso-bidi-font-weight:bold'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b><span lang=PT-BR style='font-size:12.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>Par�grafo
Segundo: </span></b><span lang=PT-BR style='font-size:12.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>A<b
style='mso-bidi-font-weight:normal'> CONTRATANTE</b> fica ciente que em caso de
insistir em se fazer acompanhar de conjugue, parentes, amigos e outros afins junto
a reparti��o respons�vel pelo pagamento do benef�cio, que tenha por fim tentar
substituir a pr�pria <b style='mso-bidi-font-weight:normal'>CONTRATANTE</b> no recebimento
do benef�cio aqui faz jus, este ser� imediatamente bloqueado, o que impedir� seu
recebimento no dia e hor�rio marcado pela <b style='mso-bidi-font-weight:normal'>CONTRATADA,</b>
</span><span lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;
color:black;mso-themecolor:text1'>conforme assim disp�e na</span><b
style='mso-bidi-font-weight:normal'><span lang=PT-BR style='font-size:12.0pt;
mso-bidi-font-size:11.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'> <span style='color:red;background:red;
mso-highlight:red'>Cl�usula Q</span></span></b><b style='mso-bidi-font-weight:
normal'><span lang=PT-BR style='font-family:"Arial","sans-serif";mso-fareast-font-family:
Arial;color:red;background:red;mso-highlight:red'>uint</span></b><b
style='mso-bidi-font-weight:normal'><span lang=PT-BR style='font-size:12.0pt;
mso-bidi-font-size:11.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial;color:red;background:red;mso-highlight:red'>a
Cl�usula Vig�sima Primeira e </span></b><b><span lang=PT-BR style='font-size:
12.0pt;line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:
Arial;color:red;background:red;mso-highlight:red'>Par�grafo Primeiro da </span></b><b
style='mso-bidi-font-weight:normal'><span lang=PT-BR style='font-size:12.0pt;
mso-bidi-font-size:11.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial;color:red;background:red;mso-highlight:red'>Cl�usula
Vig�sima Primeira.</span></b><b style='mso-bidi-font-weight:normal'><span
lang=PT-BR style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial;color:red'><o:p></o:p></span></b></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:normal'><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>CL�USULA VIG�SIMA
SEGUNDA</span></b><b style='mso-bidi-font-weight:normal'><span lang=PT-BR
style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'>: </span></b><span lang=PT-BR style='font-size:
12.0pt;line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:
Arial'>Em caso de �bito da <b style='mso-bidi-font-weight:normal'><span
style='background:white'>CONTRATANTE</span></b> poder� receber o benef�cio
pactuado na <b style='mso-bidi-font-weight:normal'>Cl�usula D�cima Sexta</b> o legitimo
c�njuge sucessor ou quem legalmente estiver com as guardas judiciais da
crian�a, cujo procedimento atender� as normas e diretrizes normativas
estabelecidas pela autarquia, restringindo outros parentes ou afins do
recebimento deste. <o:p></o:p></span></p>

<p class=MsoNormal align=center style='margin-bottom:8.0pt;text-align:center;
line-height:125%'><b style='mso-bidi-font-weight:normal'><u><span lang=PT-BR
style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial;background:white'>DAS DESPESAS GERAIS</span></u></b><b
style='mso-bidi-font-weight:normal'><u><span lang=PT-BR style='font-size:12.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>:<o:p></o:p></span></u></b></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:normal'><span
lang=PT-BR style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'><o:p>&nbsp;</o:p></span></b></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:normal'><span
lang=PT-BR style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'>CL�USULA VIG�SIMA TERCEIRA: </span></b><span
lang=PT-BR style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'>Ser�o cobrados <b style='mso-bidi-font-weight:
normal'><span style='color:black'>20% (Vinte por Cento) </span></b><span
style='color:black'>referente �s despesas, tais como, <span style='background:
white'>Guias de Contribui��o, taxas, emolumentos, despesas cartor�rias, c�pias
reprogr�ficas, certid�es, dilig�ncias, </span></span><span style='background:
white'>inclusive di�rias de <span style='color:black'>viagens, dilig�ncia em
outra Comarca etc., bem como tudo </span></span><span style='color:black'>o
mais que se fizer necess�rio para alcan�ar os objetivos aqui contratados.<o:p></o:p></span></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b><span lang=PT-BR style='font-size:12.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'><o:p>&nbsp;</o:p></span></b></p>

<p class=MsoNormal style='text-align:justify;text-justify:inter-ideograph'><b><span
lang=PT-BR style='font-size:12.0pt;line-height:115%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'>Par�grafo Primeiro:</span></b><b
style='mso-bidi-font-weight:normal'><span lang=PT-BR style='font-size:12.0pt;
line-height:115%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>
</span></b><span lang=PT-BR style='font-size:12.0pt;line-height:115%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;background:white'>O
valor dos servi�os pactuados na </span><b style='mso-bidi-font-weight:normal'><span
lang=PT-BR style='font-size:12.0pt;line-height:115%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'>Cl�usula D�cima Sexta e Cl�usula Vig�sima
Terceira </span></b><span lang=PT-BR style='font-size:12.0pt;line-height:115%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;background:white'>n�o
ser�o alterados nas seguintes hip�teses:<o:p></o:p></span></p>

<p class=MsoListParagraphCxSpFirst style='text-align:justify;text-justify:inter-ideograph;
text-indent:-.25in;mso-list:l0 level1 lfo4'><![if !supportLists]><span
lang=PT-BR style='font-size:12.0pt;line-height:115%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>a)<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp; </span></span></span><![endif]><span
lang=PT-BR style='font-size:12.0pt;line-height:115%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial;color:black;background:white'>De n�o se prosseguir
a execu��o dos servi�os aqui pactuados, que sejam provenientes por quaisquer circunstancias
n�o causada pela <b style='mso-bidi-font-weight:normal'>CONTRATADA;</b></span><b
style='mso-bidi-font-weight:normal'><span lang=PT-BR style='font-size:12.0pt;
line-height:115%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;
color:black'><o:p></o:p></span></b></p>

<p class=MsoListParagraphCxSpMiddle style='text-align:justify;text-justify:
inter-ideograph;text-indent:-.25in;mso-list:l0 level1 lfo4'><![if !supportLists]><span
lang=PT-BR style='font-size:12.0pt;line-height:115%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>b)<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp; </span></span></span><![endif]><span
lang=PT-BR style='font-size:12.0pt;line-height:115%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial;color:black;background:white'>Para a hip�tese de
existir revoga��o da procura��o, sem culpa da</span><b style='mso-bidi-font-weight:
normal'><span lang=PT-BR style='font-size:12.0pt;line-height:115%;font-family:
"Arial","sans-serif";mso-fareast-font-family:Arial;color:black'> CONTRATADA<o:p></o:p></span></b></p>

<p class=MsoListParagraphCxSpLast style='text-align:justify;text-justify:inter-ideograph;
text-indent:-.25in;mso-list:l0 level1 lfo4'><![if !supportLists]><span
lang=PT-BR style='font-size:12.0pt;line-height:115%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>c)<span
style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp; </span></span></span><![endif]><span
lang=PT-BR style='font-size:12.0pt;line-height:115%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial;color:black'>Ou <span style='background:white'>a
pr�tica de quaisquer atos da <b style='mso-bidi-font-weight:normal'>CONTRATANTE</b>
que de algum modo viole o presente contrato, seguindo assim o pagamento
normalmente ou a execu��o deste instrumento</span></span><span lang=PT-BR
style='font-size:12.0pt;line-height:115%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'> at� o limite dos honor�rios pactuados<span
style='color:black;background:white'>.</span><b style='mso-bidi-font-weight:
normal'><span style='color:black'> <o:p></o:p></span></b></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:normal'><u><span
lang=PT-BR style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'><o:p><span style='text-decoration:none'>&nbsp;</span></o:p></span></u></b></p>

<p class=MsoNormal align=center style='margin-bottom:8.0pt;text-align:center;
line-height:125%'><b style='mso-bidi-font-weight:normal'><u><span lang=PT-BR
style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'>DA DECLARA��O<o:p></o:p></span></u></b></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:normal'><span
lang=PT-BR style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'><o:p>&nbsp;</o:p></span></b></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b style='mso-bidi-font-weight:normal'><span
lang=PT-BR style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'>CL�USULA VIG�SIMA QUARTA:</span></b><span
lang=PT-BR style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial;color:red'> </span><span lang=PT-BR
style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial;color:black'>A</span><span lang=PT-BR
style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'> <b style='mso-bidi-font-weight:normal'>CONTRATANTE
</b>declara ter ci�ncia de que no final do cumprimento das obriga��es
contratuais, ou seja, tendo �xito junto � autarquia dos valores a serem
levantados pela <b style='mso-bidi-font-weight:normal'>CONTRATADA</b>, os quais<b
style='mso-bidi-font-weight:normal'> </b>dever�o ser recebidos juntamente com
os seus documentos originais, que se encontra em guarda junto a <b
style='mso-bidi-font-weight:normal'>CONTRATADA</b> em seu escrit�rio. <o:p></o:p></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><span lang=PT-BR style='font-size:12.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;
color:red'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b><span lang=PT-BR style='font-size:12.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>Par�grafo
Primeiro:</span></b><span lang=PT-BR style='font-size:12.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'> A <b
style='mso-bidi-font-weight:normal'>CONTRATANTE</b> declara ter ci�ncia que o
documento original de (CTPS) Carteira Profissional de Trabalho deixada por ela
voluntariamente ficar� de posse da <b style='mso-bidi-font-weight:normal'>CONTRATADA,
onde</b> s� ser� devidamente devolvido no final da execu��o dos servi�os aqui
contratados, ficando assim vedada a devolu��o da mesma durante o processo, c</span><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>onforme assim
disp�e no</span><b><span lang=PT-BR style='font-size:12.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;background:white'>
Par�grafo �nico </span></b><span lang=PT-BR style='font-size:12.0pt;line-height:
125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;background:
white;mso-bidi-font-weight:bold'>da</span><span lang=PT-BR style='font-size:
12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'> <b style='mso-bidi-font-weight:normal'>Cl�usula
D�cima primeira </b>e<b style='mso-bidi-font-weight:normal'> </b></span><b><span
lang=PT-BR style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'>Par�grafo Segundo</span></b><span lang=PT-BR
style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'><span style='mso-spacerun:yes'>� </span>da <b
style='mso-bidi-font-weight:normal'>Cl�usula Vig�sima Quarta</b>.<o:p></o:p></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><span lang=PT-BR style='font-size:12.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b><span lang=PT-BR style='font-size:12.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>Par�grafo
Segundo:</span></b><span lang=PT-BR style='font-size:12.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;mso-bidi-font-weight:
bold'> A <b>CONTRATANTE</b> </span><span lang=PT-BR style='font-size:12.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>declara
ter ci�ncia que o documento original de (CTPS) Carteira Profissional de
Trabalho deixada por ela voluntariamente Ficar� de posse da CONTRATADA, em
conformidade com o <b><span style='background:white'>Par�grafo �nico da</span></b></span><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'> <b
style='mso-bidi-font-weight:normal'>Cl�usula D�cima primeira e </b></span><b><span
lang=PT-BR style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'>Par�grafo Primeiro e Segundo</span></b><span
lang=PT-BR style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'> da <b style='mso-bidi-font-weight:normal'>Cl�usula
Vig�sima Quarta, </b>sendo assim a<b style='mso-bidi-font-weight:normal'> <span
style='mso-bidi-font-weight:bold'>CONTRATANTE</span> </b>fica orientada pela <b>CONTRATADA</b>
atrav�s deste contrato, o seu impedimento de tentar usar os �rg�os p�blicos no
intuito ardil de enganar as autoridades policiais, fazendo (boletim de
ocorr�ncia por perda ou roubo) em busca de obter outra Carteira Profissional de
Trabalho (2� via), neste caso ser� comunicado imediatamente a delegacia competente,
o dolo da <b>CONTRATANTE</b><span style='mso-bidi-font-weight:bold'>,</span> <span
style='background:white'>sob pena de incorrer nos termos previsto da lei,
cabendo assim a execu��o deste instrumento </span>at� o limite dos honor�rios
pactuados.</span><span lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:
11.0pt;line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:
Arial'> <o:p></o:p></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><span lang=PT-BR style='font-size:12.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;
color:red'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b><span lang=PT-BR style='font-size:12.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>Par�grafo
Terceiro:</span></b><span lang=PT-BR style='font-size:12.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;mso-bidi-font-weight:
bold'> <b>A CONTRATANTE</b> declara expressamente que n�o criar� obst�culos
para o sucesso deste procedimento administrativo em conformidade com a <b>Cl�usula</b></span><b
style='mso-bidi-font-weight:normal'><span lang=PT-BR style='font-size:12.0pt;
mso-bidi-font-size:11.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'> D</span></b><b style='mso-bidi-font-weight:
normal'><span lang=PT-BR style='font-family:"Arial","sans-serif";mso-fareast-font-family:
Arial'>�cima</span></b><b style='mso-bidi-font-weight:normal'><span lang=PT-BR
style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial;background:white'> e a letra � do </span></b><b
style='mso-bidi-font-weight:normal'><span lang=PT-BR style='font-size:12.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>Par�grafo
Primeiro<span style='background:white'> da </span>Cl�usula Vig�sima Quinta, </span></b><span
lang=PT-BR style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial;mso-bidi-font-weight:bold'>sob pena de se criar
obst�culo no sentido de causar preju�zo � <b>CONTRATADA</b> na busca de seus
direitos e consequentemente o recebimento de seus honor�rios, a <b>CONTRATADA</b>
poder�, se sofrer preju�zo, ingressar com a��o de cobran�a de honor�rios
cumulado com danos morais.<o:p></o:p></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><span lang=PT-BR style='font-size:12.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;
mso-bidi-font-weight:bold'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><b><span lang=PT-BR style='font-size:12.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>Par�grafo
Quarto:<span style='color:red'> </span></span></b><span lang=PT-BR
style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial;mso-bidi-font-weight:bold'>Tendo a<b> </b></span><b
style='mso-bidi-font-weight:normal'><span lang=PT-BR style='font-size:12.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;
background:white'>CONTRATANTE</span></b><b><span lang=PT-BR style='font-size:
12.0pt;line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:
Arial'> </span></b><span lang=PT-BR style='font-size:12.0pt;line-height:125%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;mso-bidi-font-weight:
bold'>efetuado o pagamento dos honor�rios pactuados na <b>C</b></span><b
style='mso-bidi-font-weight:normal'><span lang=PT-BR style='font-size:12.0pt;
mso-bidi-font-size:11.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'>l�usula Quarta</span></b><span lang=PT-BR
style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:125%;font-family:
"Arial","sans-serif";mso-fareast-font-family:Arial'> deste contrato<b
style='mso-bidi-font-weight:normal'>,</b></span><span lang=PT-BR
style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial;mso-bidi-font-weight:bold'> e n�o sendo devolvida
a NOTA PROMISS�RIA, a </span><b style='mso-bidi-font-weight:normal'><span
lang=PT-BR style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial;background:white'>CONTRATANTE</span></b><b><span
lang=PT-BR style='font-size:12.0pt;line-height:125%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'> </span></b><span lang=PT-BR style='font-size:
12.0pt;line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:
Arial;mso-bidi-font-weight:bold'>poder� promover a��es contra a <b>CONTRATADA </b>em
busca de preservar os seus direitos.<o:p></o:p></span></p>

<p class=MsoNormal style='margin-bottom:8.0pt;text-align:justify;text-justify:
inter-ideograph;line-height:125%'><span lang=PT-BR style='font-size:12.0pt;
line-height:125%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;
mso-bidi-font-weight:bold'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal style='text-align:justify;text-justify:inter-ideograph'><b
style='mso-bidi-font-weight:normal'><span lang=PT-BR style='font-size:12.0pt;
line-height:115%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>CL�USULA
VIG�SIMA QUINTA: </span></b><span lang=PT-BR style='font-size:12.0pt;
line-height:115%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>Deixando
a <b style='mso-bidi-font-weight:normal'><span style='background:white'>CONTRATANTE</span>
</b>de honrar os honor�rios contratados na <b style='mso-bidi-font-weight:normal'>Cl�usula
D�cima Sexta e Cl�usula Vig�sima Terceira </b>deste contrato, a mesma autoriza
a <b style='mso-bidi-font-weight:normal'>CONTRATADA</b> a executar
judicialmente o que lhe � devido, sejam atrav�s de demandas judiciais nas
esferas <b style='mso-bidi-font-weight:normal'>PENAL e/ou</b> <b
style='mso-bidi-font-weight:normal'>C�VEL </b>para exigir o cumprimento deste contrato,
at� o limite dos honor�rios pactuados, ou executar a nota promiss�ria garantidora
deste contrato, podendo ser levado a protesto junto aos cart�rios de t�tulos e
protestos, podendo at� ter seu nome incluso nos<b style='mso-bidi-font-weight:
normal'> SERVI�OS DE PROTE��O AO CREDITO (SPC) e SERASA.<o:p></o:p></b></span></p>

<p class=MsoNormal style='text-align:justify;text-justify:inter-ideograph'><b
style='mso-bidi-font-weight:normal'><u><span lang=PT-BR style='font-size:12.0pt;
line-height:115%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>Par�grafo
Primeiro: S�O MOTIVOS PARA QUE SE RESCINDA ESTE PRESENTE INSTRUMENTO:<o:p></o:p></span></u></b></p>

<p class=MsoNormal style='text-align:justify;text-justify:inter-ideograph'><b
style='mso-bidi-font-weight:normal'><u><span lang=PT-BR style='font-size:12.0pt;
line-height:115%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'><o:p><span
 style='text-decoration:none'>&nbsp;</span></o:p></span></u></b></p>

<p class=MsoListParagraph style='margin-left:21.3pt;mso-add-space:auto;
text-align:justify;text-justify:inter-ideograph;text-indent:-21.3pt;mso-list:
l1 level1 lfo1'><![if !supportLists]><span lang=PT-BR style='font-size:12.0pt;
line-height:115%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'><span
style='mso-list:Ignore'>a)<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;
</span></span></span><![endif]><span lang=PT-BR style='font-size:12.0pt;
line-height:115%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;
background:white'>A <b style='mso-bidi-font-weight:normal'>CONTRATANTE</b> e a <b
style='mso-bidi-font-weight:normal'>CONTRATADA</b> deixar de observar quaisquer
obriga��es que conste no presente contrato.<o:p></o:p></span></p>

<p class=MsoNormal style='text-align:justify;text-justify:inter-ideograph'><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:115%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;background:white'>b)
A <b style='mso-bidi-font-weight:normal'>CONTRATANTE</b> descumprir com o
disposto na<b style='mso-bidi-font-weight:normal'> Cl�usula </b></span><b
style='mso-bidi-font-weight:normal'><span lang=PT-BR style='font-size:12.0pt;
mso-bidi-font-size:11.0pt;line-height:115%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'>D�cima Sexta <span
style='mso-spacerun:yes'>�</span>Cl�usula </span></b><b style='mso-bidi-font-weight:
normal'><span lang=PT-BR style='font-size:12.0pt;line-height:115%;font-family:
"Arial","sans-serif";mso-fareast-font-family:Arial'>Vig�sima Terceira</span></b><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:115%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;background:white'>
deste contrato.<o:p></o:p></span></p>

<p class=MsoNormal style='text-align:justify;text-justify:inter-ideograph'><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:115%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>c) N�o apresentar
os documentos solicitados pela<b style='mso-bidi-font-weight:normal'><span
style='background:white'> CONTRATADA, </span></b><span style='background:white'>conforme</span></span><span
lang=PT-BR style='font-size:12.0pt;line-height:115%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial;mso-bidi-font-weight:bold'> assim preceituam</span><span
lang=PT-BR style='font-size:12.0pt;line-height:115%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial;background:white'> a </span><b style='mso-bidi-font-weight:
normal'><span lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;
line-height:115%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>Cl�usula
D�cima</span></b><b><span lang=PT-BR style='font-size:12.0pt;line-height:115%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'> e Par�grafo
Terceiro</span></b><b style='mso-bidi-font-weight:normal'><span lang=PT-BR
style='font-size:12.0pt;line-height:115%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'> Cl�usula Vig�sima Quarta.</span></b><span
lang=PT-BR style='font-size:12.0pt;line-height:115%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial;background:white'> <b style='mso-bidi-font-weight:
normal'><span style='mso-spacerun:yes'>�</span></b></span><b style='mso-bidi-font-weight:
normal'><span lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;
line-height:115%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;
background:white'><o:p></o:p></span></b></p>

<p class=MsoNormal style='text-align:justify;text-justify:inter-ideograph'><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:115%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>d) N�o
comunicar a<b style='mso-bidi-font-weight:normal'> CONTRATADA</b> o recebimento
de algum benef�cio<b style='mso-bidi-font-weight:normal'> </b>conforme </span><b><span
lang=PT-BR style='font-size:12.0pt;line-height:115%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'>Cl�usula Terceira</span></b><b style='mso-bidi-font-weight:
normal'><span lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;
line-height:115%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;
color:red;background:white'>,</span></b><span lang=PT-BR style='font-size:12.0pt;
mso-bidi-font-size:11.0pt;line-height:115%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'> ou qualquer outra viola��o das cl�usulas deste
contrato.<o:p></o:p></span></p>

<p class=MsoNormal style='text-align:justify;text-justify:inter-ideograph'><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:115%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>e) Criar
obst�culos </span><span lang=PT-BR style='font-size:12.0pt;line-height:115%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;mso-bidi-font-weight:
bold'>para o sucesso deste demanda, no sentido de causar preju�zo � <b>CONTRATADA
conforme o Par�grafo Terceiro da </b></span><b style='mso-bidi-font-weight:
normal'><span lang=PT-BR style='font-size:12.0pt;line-height:115%;font-family:
"Arial","sans-serif";mso-fareast-font-family:Arial'>cl�usula Vig�sima Quarta.</span></b><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:115%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'><o:p></o:p></span></p>

<p class=MsoNormal style='text-align:justify;text-justify:inter-ideograph'><span
lang=PT-BR style='font-size:12.0pt;line-height:115%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial;color:black'>f</span><span lang=PT-BR
style='font-size:12.0pt;line-height:115%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'>)<b style='mso-bidi-font-weight:normal'> </b>Tentar
induzir ou manter<b style='mso-bidi-font-weight:normal'> </b>a<b
style='mso-bidi-font-weight:normal'> CONTRATADA </b>a erro, mediante artif�cio
ardil de qualquer outro meio, prestando Informa��es falsas<b style='mso-bidi-font-weight:
normal'> </b>a<b style='mso-bidi-font-weight:normal'> CONTRATADA em
conformidade com a cl�usula Vig�sima Sexta e o <span style='mso-bidi-font-weight:
bold'>Par�grafo �nico</span>. <o:p></o:p></b></span></p>

<p class=MsoNormal style='text-align:justify;text-justify:inter-ideograph'><b
style='mso-bidi-font-weight:normal'><span lang=PT-BR style='font-size:12.0pt;
line-height:115%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;
color:red'><o:p>&nbsp;</o:p></span></b></p>

<p class=MsoNormal style='text-align:justify;text-justify:inter-ideograph'><b
style='mso-bidi-font-weight:normal'><span lang=PT-BR style='font-size:12.0pt;
line-height:115%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>CL�USULA
VIG�SIMA SEXTA<u>: NO CASO DE INADIMPL�NCIA EM CONFORMIDADE COM A CL�USULA VIG�SIMA
QUINTA A </u></span></b><b style='mso-bidi-font-weight:normal'><u><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:115%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>CONTRATANTE</span></u></b><b
style='mso-bidi-font-weight:normal'><u><span lang=PT-BR style='font-size:12.0pt;
line-height:115%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>
DECLARA SER R� CONFESSA NOS CRIMES DE APROPRIA��O IND�BITA. <o:p></o:p></span></u></b></p>

<p class=MsoNormal style='text-align:justify;text-justify:inter-ideograph'><b><span
lang=PT-BR style='font-size:12.0pt;line-height:115%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'>�Art. 168 - Apropriar-se de coisa alheia m�vel,
de que tem a posse ou a deten��o:�<br style='mso-special-character:line-break'>
<![if !supportLineBreakNewLine]><br style='mso-special-character:line-break'>
<![endif]><o:p></o:p></span></b></p>

<p class=MsoNormal style='text-align:justify;text-justify:inter-ideograph'><b><span
lang=PT-BR style='font-size:12.0pt;line-height:115%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'><o:p>&nbsp;</o:p></span></b></p>

<p class=MsoNormal style='text-align:justify;text-justify:inter-ideograph'><b><span
lang=PT-BR style='font-size:12.0pt;line-height:115%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'>��������������____________________________________________<o:p></o:p></span></b></p>

<p class=MsoNormal style='text-align:justify;text-justify:inter-ideograph'><b><span
lang=PT-BR style='font-size:12.0pt;line-height:115%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'><o:p>&nbsp;</o:p></span></b></p>

<p class=MsoNormal style='text-align:justify;text-justify:inter-ideograph'><b><span
lang=PT-BR style='font-size:12.0pt;line-height:115%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'><o:p>&nbsp;</o:p></span></b></p>

<p class=MsoNormal style='text-align:justify;text-justify:inter-ideograph'><b><span
lang=PT-BR style='font-size:12.0pt;line-height:115%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'>Par�grafo �nico</span></b><b style='mso-bidi-font-weight:
normal'><span lang=PT-BR style='font-size:12.0pt;line-height:115%;font-family:
"Arial","sans-serif"'>: </span></b><span lang=PT-BR style='font-size:12.0pt;
line-height:115%;font-family:"Arial","sans-serif"'>A </span><b
style='mso-bidi-font-weight:normal'><span lang=PT-BR style='font-size:12.0pt;
line-height:115%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;
background:white'>CONTRATANTE</span></b><span lang=PT-BR style='font-size:12.0pt;
line-height:115%;font-family:"Arial","sans-serif"'> declara esta ciente sob
pena de incorre na pratica de crime previsto no artigo 299 do c�digo penal
brasileiro ser completas e verdadeiras as informa��es prestadas, isentando o
procurador a empresa </span><b><span lang=PT-BR style='font-size:12.0pt;
line-height:115%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>CONTRATADA,</span></b><span
lang=PT-BR style='font-size:12.0pt;line-height:115%;font-family:"Arial","sans-serif"'>
<b style='mso-bidi-font-weight:normal'>LIDER CONSULTORIA CNPJ
24.808.801/0001-81</b> de qualquer responsabilidade Penal ou Civil.<o:p></o:p></span></p>

<p class=MsoNormal style='text-align:justify;text-justify:inter-ideograph'><span
lang=PT-BR style='font-size:12.0pt;line-height:115%;font-family:"Arial","sans-serif"'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal style='text-align:justify;text-justify:inter-ideograph'><b
style='mso-bidi-font-weight:normal'><span lang=PT-BR style='font-size:12.0pt;
mso-bidi-font-size:11.0pt;line-height:115%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'>CL�USULA VIG�SIMA NONA: </span></b><u><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:115%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;text-transform:
uppercase'>A</span></u><b style='mso-bidi-font-weight:normal'><u><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:115%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'> CONTRATANTE<span
style='background:white'> </span></span></u></b><u><span lang=PT-BR
style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:115%;font-family:
"Arial","sans-serif";mso-fareast-font-family:Arial;background:white'>declara
que, antes de assinar, examinou e leu o presente instrumento, reconhecendo-o em
tudo correto, sob pena de incorrer nos termos previsto no art. 299 do C�digo Penal,
declarando finalmente que reconhece, desde j�, como l�quida e certa a obriga��o
contra�da por este instrumento particular de contrato.<o:p></o:p></span></u></p>

<p class=MsoNormal style='text-align:justify;text-justify:inter-ideograph'><b
style='mso-bidi-font-weight:normal'><span lang=PT-BR style='font-size:12.0pt;
mso-bidi-font-size:11.0pt;line-height:115%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'><o:p>&nbsp;</o:p></span></b></p>

<p class=MsoNormal align=center style='text-align:center'><b style='mso-bidi-font-weight:
normal'><u><span lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;
line-height:115%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'>DO
FORO:<o:p></o:p></span></u></b></p>

<p class=MsoNormal style='text-align:justify;text-justify:inter-ideograph'><b
style='mso-bidi-font-weight:normal'><span lang=PT-BR style='font-size:12.0pt;
mso-bidi-font-size:11.0pt;line-height:115%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial'><o:p>&nbsp;</o:p></span></b></p>

<p class=MsoNormal style='text-align:justify;text-justify:inter-ideograph'><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:115%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;background:white'>As
partes contratadas elegem o foro da cidade do Rio de Janeiro para dirimir
qualquer a��o oriunda deste contrato.<o:p></o:p></span></p>

<p class=MsoNormal style='text-align:justify;text-justify:inter-ideograph'><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:115%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;background:white'>&nbsp;E,
por assim terem contratado, assinam o presente em duas vias ou via e-mail de
igual teor e forma, na presen�a das testemunhas abaixo qualificadas que tamb�m
assinam.<o:p></o:p></span></p>

<p class=MsoNormal align=right style='text-align:right'><b style='mso-bidi-font-weight:
normal'><span lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;
line-height:115%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;
background:white'><o:p>&nbsp;</o:p></span></b></p>

<p class=MsoNormal align=right style='text-align:right'><b style='mso-bidi-font-weight:
normal'><span lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;
line-height:115%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;
background:white'>Rio de Janeiro </span></b><span lang=PT-BR style='font-size:
12.0pt;mso-bidi-font-size:11.0pt;line-height:115%;font-family:"Arial","sans-serif";
mso-fareast-font-family:Arial;background:white'>________<b style='mso-bidi-font-weight:
normal'>de</b>________________________<b style='mso-bidi-font-weight:normal'>
de 2017<o:p></o:p></b></span></p>

<p class=MsoNormal align=right style='text-align:right'><b style='mso-bidi-font-weight:
normal'><span lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;
line-height:115%;font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;
background:white'><o:p>&nbsp;</o:p></span></b></p>

<p class=MsoNormal style='text-align:justify;text-justify:inter-ideograph'><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:115%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'><br>
<span style='background:white'>___________________________<span
style='mso-tab-count:1'>��������� </span>___________________________<o:p></o:p></span></span></p>

<p class=MsoNormal style='text-align:justify;text-justify:inter-ideograph'><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:115%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;background:white'><o:p>&nbsp;</o:p></span></p>

<p class=MsoNormal style='text-align:justify;text-justify:inter-ideograph'><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:115%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial;background:white'>Testemunhas:&nbsp;<o:p></o:p></span></p>

<p class=MsoNormal style='text-align:justify;text-justify:inter-ideograph'><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:115%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'><br>
<br>
<span style='background:white'>___________________________&nbsp;<span
style='mso-tab-count:1'>�������� </span>___________________________</span><br>
<span style='background:white'>Nome:<span
style='mso-spacerun:yes'>���������������������������� </span><span
style='mso-tab-count:3'>����������������������������� </span>Nome:&nbsp;</span><br>
<span style='background:white'>CPF:<span
style='mso-spacerun:yes'>�������������������������������������������������������
</span>CPF:</span></span></p>
<p class=MsoNormal style='text-align:justify;text-justify:inter-ideograph'>&nbsp;</p>
<p class=MsoNormal style='text-align:justify;text-justify:inter-ideograph'>&nbsp;</p>
<p class=MsoNormal style='text-align:justify;text-justify:inter-ideograph'>&nbsp;</p>
<p class=MsoNormal style='text-align:justify;text-justify:inter-ideograph'>&nbsp;</p>
<h5 class=MsoNormal style='text-align:justify;text-justify:inter-ideograph'><span
lang=PT-BR style='font-size:12.0pt;mso-bidi-font-size:11.0pt;line-height:115%;
font-family:"Arial","sans-serif";mso-fareast-font-family:Arial'><span style='background:white'><em>Contrato cadastrado por: [cod_funcionario] - [nome_funcionario].      
        <o:p></o:p>
</em></span></span></h5>

</div>

</body>

</html>
