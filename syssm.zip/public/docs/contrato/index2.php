﻿<style type="text/css">
body p {
	font-family: Arial, Helvetica, sans-serif;
}
strong {
	font-family: Arial, Helvetica, sans-serif;
}
</style>
<div>
    <p align="center">&nbsp;
    </p>
    <table width="100%" height="62" border="1">
      <tr>
        <td align="center" valign="middle"><strong><u>CONTRATO DE PRESTAÇÃO DE SERVIÇOS</u></strong></td>
      </tr>
    </table>
    <p align="center">&nbsp;</p>
</div>
<p>
    <strong></strong>
</p>
<p>
    <strong><u>CONTRATANTE:</u></strong>
</p>
<p>
    <strong>RG: </strong>
</p>
<p>
    <strong>CPF: </strong>
</p>
<p>
    <strong>DATA DE NASCIMENTO:</strong>
</p>
<p>
    <strong>RUA: Nº</strong>
</p>
<p>
    <strong>BAIRRO: CEP: Cidade: UF: </strong>
</p>
<p>
    <strong>GRAU DE ESCOLARIDADE: </strong>
</p>
<p>
    <strong>FONE:</strong>
</p>
<p>
    <strong></strong>
</p>
<p>
    <strong><u>CONTRATADA</u></strong>
    <strong>
        : LÍDER CONSULTORIA LTDA, inscrita no CNPJ No. 24.808.811/0001-81, com
        sua sede Rua José de Alvarenga, 394, sobreloja sala 5, Centro, Duque de
        Caxias/RJ, CEP: 25.020-140 e filiais (Nova Iguaçu) Avenida Governador
        Amaral Peixoto, 130, 8º andar, sala 801, Centro de Nova Iguaçu/RJ, CEP
        26.210-060; - (Rio de Janeiro) Avenida Presidente Vargas, 633, 11
        andar, sala 1121, Centro, Rio de Janeiro/RJ, CEP 20.071-003; ­-
        (Niterói) Rua da Conceição, 13, sala 308, 3ºandar, Centro Niterói/RJ,
        CEP 24.020-084, – (Campo Grande) Rua Campo Grande, 1014, sala 322, 5
        andar, Centro, Campo Grande/RJ, CEP 23.080-000 neste ato representada
        por quem de direito, doravante denominada simplesmente de CONTRATADA
    </strong>
    <strong>. </strong>
</p>
<p>
    <strong> </strong>
    <strong></strong>
</p>
<p>
    <strong></strong>
</p>
<p>
    <strong>
        As partes acima identificadas têm entre si justas e acertadas o
        presente contrato, que será regido pelas seguintes cláusulas:
    </strong>
</p>
<p>
    <strong> </strong>
</p>
<p align="center">
    <strong> </strong>
</p>
<p align="center">
    <strong><u>DO OBJETO</u></strong>
</p>
<p>
    <strong></strong>
</p>
<p>
    <strong>CLÁUSULA PRIMEIRA</strong>
    <strong>: </strong>
A<strong> CONTRATADA</strong> se obriga a prestar ao    <strong>CONTRATANTE</strong> seus serviços profissionais, com zelo e
    dedicação, na defesa de seus direitos e interesses, cuja extensão destes se
    refere a<strong> </strong>direitos mantidos pela autarquia, a fim de
    oportunizar os recebimentos de valores, aproximadamente equivalentes à
    média aritmética simples das últimas 12 (doze) remunerações do segurado,
    oficialmente obtidas em virtude do último contrato de emprego, tendo como
    parâmetro o múltiplo de 4 (quatro), terá o recebimento das quantias devidas
    , ficando ciente do depósito do valor a ser liberado pela Autarquia;
    ressalvada, entretanto, eventual mudança de legislação ou ordens
    normativas.
</p>
<p>
    <strong>Parágrafo Primeiro: </strong>
    A<strong> CONTRATADA</strong> representará a <strong>CONTRATANTE </strong>
    perante órgãos públicos (Repartições Federais, Estaduais, Municipais e
    outros) ou Privados, mediante procuração com firma reconhecida por
    autenticidade em cartório de notas, sempre em conformidade com o serviço
    para o qual foi contratado.
</p>
<p>
    <strong>Parágrafo Segundo:</strong>
    Fica vedado a<strong> CONTRATADA</strong> propor ou responder demandas além
    do previsto no <em>caput </em>desta Cláusula, bem como atuar em
    desconformidade com os poderes que lhe foram outorgados, sem que haja
    prévia autorização expressa do <strong>CONTRATANTE</strong>.
</p>
<p>
    <strong> </strong>
</p>
<p align="center">
    <strong><u>DAS OBRIGAÇÕES:</u></strong>
</p>
<p>
    <strong>CLÁUSULA SEGUNDA: </strong>
    A<strong> CONTRATADA</strong> tem obrigação de dedicar seus melhores
esforços na prestação dos serviços contratados. Porém, a    <strong>CONTRATANTE</strong> fica desde já ciente de que a prestação de
    serviço de intermediação é uma atividade de meio, e não de resultado, de
modo que não é possível garantir o êxito favorável ao    <strong>CONTRATANTE </strong>no final da demanda.<strong> </strong>
</p>
<p>
    <strong>Parágrafo Primeiro: </strong>
    A<strong> CONTRATADA</strong> obriga-se a tratar como matéria sigilosa e
    confidencial todas as informações administrativas, comerciais ou de
qualquer natureza que lhe forem fornecidas pelo(a)    <strong>CONTRATANTE</strong>, com a ressalva do que for necessário para
    fundamentar pedidos e notificações, zelando pelo sigilo destas informações
    durante e após o término da prestação dos serviços.<strong> </strong>
</p>
<p>
    <strong>CLÁUSULA TERCEIRA:</strong>
    <strong><u> </u></strong>
    <u>
A <strong>CONTRATANTE</strong> deverá informar a        <strong> CONTRATADA,</strong> no ato da assinatura do presente, se já
        recebeu algum benefício ou encontra-se recebendo-o, tais como:
        <strong>
            Licença-Maternidade, Salário Maternidade, Auxilio Maternidade,
            Salário Natalidade ou outros de mesma natureza;
        </strong>
        a qual firmará declaração competente; evitando-se com isso a cobrança
        repetitória do direito aqui requerido.
    </u>
</p>
<p>
    <strong><u>Parágrafo único:</u></strong>
    <u>
        Fica desde já pactuado que os honorários pelos serviços ora prestados,
prevalecerão mesmo em caso de diversidade de informações prestadas pelo        <strong>CONTRATANTE. </strong>
    </u>
</p>
<p>
    <strong> </strong>
</p>
<p>
    <strong>CLÁUSULA QUARTA: </strong>
    A<strong> CONTRATADA s</strong>ó poderá devolver os documentos originais ou
    prestar informações da <strong>CONTRATANTE</strong> a terceiros ou a
    parentes, devendo-se observar o seguinte:
</p>
<p>
    A) Em caso de óbito o mesmo se dará mediante apresentação de cópia da
    certidão de óbito autenticada;
</p>
<p>
    B) Na hipótese de tratamento médico, no qual esteja impossibilitada de se
    locomover, conforme laudo médico, ficando assim vedado passar informações
    da <strong>CONTRATANTE </strong>a terceiros ou parentes.
</p>
<p>
    <strong> </strong>
</p>
<p>
    <strong>CLÁUSULA QUINTA: </strong>
    A <strong>CONTRATANTE</strong> fica ciente que em nenhuma hipótese poderá
    receber valores decorrentes dos serviços aqui prestados, através de
    representação de terceiros, assim compreendidos: conjugue parentes, amigos,
    dentre outros; sendo certo que este direito somente poderá ser exercido
através do acompanhamento de um responsável indicado pela ora<strong>CONTRATADA</strong>, conforme assim preceituam a<strong>Cláusula</strong><strong> Vigésima Primeira</strong><strong>Parágrafo, Primeiro e Segundo da</strong>    <strong>Cláusula Vigésima Primeira.</strong>
</p>
<p>
    <strong>CLÁUSULA SEXTA: </strong>
    Caso a<strong> CONTRATANTE </strong>esteja em custódia da justiça, somente
    os advogados habilitados com procuração com firma reconhecida e válida, os
    quais poderão ter acesso às informações e obter cópia dos documentos anexa
    ao procedimento administrativo competente, mediante, ainda a comprovação da
    custódia de seu constituinte.
</p>
<p>
    <strong>CLÁUSULA SETIMA: </strong>
A <strong>CONTRATANTE</strong> deverá se dirigir ao escritório da    <strong> CONTRATADA</strong> munida de seus documentos pessoais originais
    (Rg, Cpf, comprovante de residência e, em caso de casado, certidão de
    casamento), sempre em horário a ser previamente agendado para obter o
    extrato e a liberação do pagamento,<strong> </strong>juntamente com todos
    os documentos originais por ela deixados, mesmo que tenha recebido qualquer
correspondência da autarquia, conforme assim dispõe na    <strong>Cláusula Vigésima. </strong>
</p>
<p>
    <strong>CLÁUSULA OITAVA</strong>
    <strong>: </strong>
    A <strong>CONTRATADA </strong>devolverá a nota promissória, hora emitida e
assinada pela <strong>CONTRATANTE</strong>, conforme se refere<strong> </strong>o disposto no    <strong> Parágrafo Primeiro e Segundo da Cláusula Décima Sexta</strong>,
    devolução esta que se dará no ato do pagamento dos honorários aqui
pactuados neste contrato; excetuando-se a hipótese da    <strong> CONTRATANTE</strong> omitir o que já efetivamente recebeu, tais
    como:
    <strong>
        <u>
            Licença-Maternidade, Salário Maternidade, Auxilio Maternidade,
            Salário Natalidade;
        </u>
    </strong>
</p>
<p>
    <strong> </strong>
</p>
<p>
    <strong>CLÁUSULA NONA</strong>
    <strong>:</strong>
    <u>
        A <strong>CONTRATANTE </strong>fica ciente que os documentos havidos em
        xerox autenticada, assim como a o instrumento de procuração por esta
        deixada, ficarão anexados e arquivados no procedimento administrativo
        junto à autarquia.
    </u>
    <strong></strong>
</p>
<p>
    <strong>CLÁUSULA DÉCIMA</strong>
    <strong>:</strong>
    A <strong>CONTRATANTE</strong> se obriga a fornecer todos elementos
necessários à defesa de seus direitos, conforme assim preceituam o<strong>Parágrafo Terceiro</strong><strong> Cláusula Vigésima Quarta</strong><strong> e a letra © do </strong>    <strong>Parágrafo Primeiro da Cláusula Vigésima Quinta</strong>, assim como
    os documentos originais essências ao procedimento administrativo, sendo
    estes:
    <strong>
        Carteira Profissional, Rescisão Contratual e Seguro Desemprego
    </strong>
    , assim xerox autenticada dos mesmos; comprometendo-se a cumprir as
instruções que lhes forem dadas a cada etapa pela    <strong>CONTRATADA.</strong>
</p>
<p>
    <strong></strong>
</p>
<p>
    <strong>Parágrafo Único:</strong>
    Tendo em vista que durante a demanda haverá uma ou mais audiências
    administrativas para periciar os documentos, poderá o Agente Público
    requerer informações ou constatar a veracidade das informações prestadas,
para cujos atos serão instruídos dos documentos originais correspondentes    <strong>.</strong><strong> </strong>
</p>
<p>
    <strong> </strong>
</p>
<p>
    <strong>CLÁUSULA DÉCIMA PRIMEIRA:</strong>
    <strong> </strong>
    Considerando que durante o procedimento administrativo o Órgão Público
    venha a necessitar da apresentação do original da Carteira Profissional de
Trabalho para fins de certificar a autenticidade das cópias apresentadas, a    <strong>CONTRATADA </strong>solicitara para a<strong> CONTRATANTE </strong>
o referido documento, que hora deixara voluntariamente de posse da    <strong>CONTRATADA</strong> para que fique em seu poder, até o termino da
    demanda conforme assim lhe autorizam a Instrução Normativa 77/2015,
conforme assim dispõe no<strong> Parágrafo P</strong><strong>rimeiro </strong>e<strong> Segundo</strong> da    <strong>Cláusula Vigésima Quarta</strong>.
</p>
<p>
    <strong>Parágrafo Único: </strong>
    Declara a <strong>CONTRATANTE</strong> que este ato é de sua plena e
    irrevogável concordância, a qual, para os devidos fins de direito, permite
    e concorda em deixa-lo em poder da ora <strong>CONTRATADA</strong> até que
    terminem todas as etapas do procedimento administrativo. Findo o
procedimento, a <strong>CONTRATADA</strong> se obriga a devolver a    <strong>CONTRATANTE</strong> o original da Carteira Profissional de
Trabalho, conforme as regras estabelecidas no<strong>Parágrafo Primeiro </strong>    <strong>e segundo da Cláusula Vigésima Quarta,</strong> mediante assinatura
    de Termo de Retenção e Restituição<strong>.</strong>
</p>
<p>
    <strong>CLÁUSULA DÉCIMA SEGUNDA:</strong>
    <strong> </strong>
    Caso venha a ocorrer o recebimento de alguma correspondência da autarquia
    concessora, a<strong> CONTRATANTE </strong>deverá levar imediatamente ao
    conhecimento da <strong>CONTRATADA </strong>a existência desta, bastando
    para tanto que se dirija ao escritório desta, independentemente do que
    estiver escrito no corpo da respectiva correspondência, observando-se para
    tanto as instruções procedimentais dadas pela <strong>CONTRATADA </strong>
em conformidade com a letra (<strong>a</strong>) do    <strong>Parágrafo Primeiro da Cláusula Vigésima Quinta.</strong>
</p>
<p align="center">
    <strong><u>DO PRAZO DE VIGENCIA</u></strong>
    <strong><u></u></strong>
</p>
<p>
    <strong> </strong>
</p>
<p>
    <strong>CLÁUSULA DÉCIMA TERCEIRA: </strong>
    O prazo para término dos serviços aqui contratados é de 60 (sessenta dias)
    úteis, cujo prazo vigorará no ato da assinatura do presente contrato, ou do
    início da data da entrega dos documentos estabelecidos neste contrato, o
que primeiro ocorrer; tudo conforme<strong> </strong>estabelece<strong>Parágrafo Segundo da </strong>    <strong>Cláusula Décima Terceira.</strong>
</p>
<p>
    <strong>Parágrafo Primeiro: </strong>
    Dentro do prazo estabelecido no <em>caput</em> deste artigo, poderá haver
    haverá audiências administrativas para fins de realização de perícia dos
    documentos deixados pela <strong>CONTRATANTE. </strong>
</p>
<p>
    <strong> </strong>
</p>
<p>
    <strong>Parágrafo Segundo: </strong>
    A <strong>CONTRATANTE </strong>fica ciente<strong> </strong>que o prazo
    estabelecido no <em>caput</em><strong>, </strong>poderá ser prorrogado de
    forma automática e por lapso de tempo indeterminado, nas seguintes
    hipóteses:
</p>
<p>
    a) No caso de existir greve dos funcionários e servidores da autarquia;
</p>
<p>
    b) Para cumprir exigências de documentos requeridas pela autarquia;
</p>
<p>
    c) Greve bancária ou quaisquer outros motivos de caso fortuito ou força
    maior que determine a extensão dos prazos aqui estabelecidos.
</p>
<p>
    <strong> </strong>
</p>
<p>
    <strong>CLÁUSULA DÉCIMA QUARTA</strong>
    <strong>: </strong>
Na falta de algum documento estabelecido neste contrato, o<strong>CONTRATANTE </strong>ficará ciente que o prazo previsto na    <strong>Cláusula Décima Terceira </strong>será alterado e suspenso, e só
    terá reinício a partir da data da entrega dos mesmos, se estendendo também
para no caso de contratantes gestantes em fase gestacional.    <strong> </strong>
</p>
<p>
    <strong>CLÁUSULA DÉCIMA QUINTA</strong>
    <strong>: </strong>
    A <strong>CONTRATANTE </strong>fica ciente<strong> </strong>que após
    análise documental feita pela <strong>CONTRATADA,</strong> esta fica
    autorizada a no prazo de 48(quarenta e oito horas) habilitar à perícia
    junto à Autarquia, bem como a dar continuidade a demanda no qual foi
contratado, em conformidade com a <strong>Cláusula Primeira e </strong>    <strong>Parágrafo Primeiro da Cláusula Primeira. </strong>
</p>
<p>
    <strong></strong>
</p>
<p>
    <strong>Parágrafo Primeiro</strong>
    : Dentro do prazo de 48 horas a <strong>CONTRATANTE</strong> poderá
    cancelar a seu nuto o seu procedimento administrativo, mediante prévio
    pagamento de uma taxa no valor de R$100,00 (Cem Reais), além dos valores
    correspondentes as despesas e emolumentos cartorários (ex.: Xerox
    autenticadas, assinatura por autenticidade, abertura de firma e outros).
</p>
<p>
    <strong>Parágrafo Segundo:</strong>
    Ultrapassado o prazo de 48 horas estabelecido no <em>caput</em>, este
    instrumento somente poderá ser revogado, mediante o pagamento do valor da
    nota promissória a que se refere no Parágrafo Primeiro da Cláusula Décima
    Sexta.
</p>
<p align="center">
    <strong>DOS HONORÁRIOS:</strong>
    <strong></strong>
</p>
<p>
    <strong> </strong>
</p>
<p>
    <strong>CLÁUSULA DÉCIMA SEXTA: </strong>
    Pelos serviços aqui pactuados, a<strong> CONTRATANTE</strong> se obriga a
pagar a <strong>CONTRATADA</strong> o valor equivalente a    <strong>30%</strong> <strong>(trinta por cento)</strong> do valor líquido
    liberado, que poderá variar de R$2.000,00 (Dois Mil Reais) a R$4.000,00
    (Quatro Mil Reais), sendo que para as hipóteses de pagamento parcelado, o
    mesmo percentual incidirá sobre o valor de cada uma das parcelas.
</p>
<p>
    <strong>Parágrafo Primeiro – Da Garantia: </strong>
    A <strong>CONTRATANTE, </strong>no ato da assinatura deste contrato, não se
    opõe em emitir em favor da <strong>CONTRATADA</strong> uma nota promissória
    no valor de R$1.500,00 (Hum mil e quinhentos Reais), que corresponderá a
    aproximadamente o percentual de <strong>30% (trinta por cento) </strong>do
valor informado na <strong>Cláusula Décima Sexta</strong>, acrescido de    <strong>20%</strong> <strong>(vinte por cento)</strong> das despesas,
    conforme <strong>Cláusula Vigésima Terceira</strong> podendo estes sofrer
    variações para mais ou para menos. <strong> </strong>
</p>
<p>
    <strong>Parágrafo Segundo: </strong>
    A nota promissória assinada, será devolvida a <strong>CONTRATANTE</strong>
    no ato do efetivo pagamento dos honorários pactuados, mediante assinatura
    de Termo de Restituição de Documento Original, dando assim plena, rasa e
    total quitação deste contrato em conformidade com a Cláusula Oitava.
</p>
<p>
    <strong>Parágrafo Terceiro: </strong>
    Sendo indeferido o procedimento da <strong>CONTRATANTE</strong>, e sendo
    confirmada que esta não faça jus em receber seu direito, a nota promissória
assinada será anulada e inutilizada na presença da    <strong>CONTRATANTE. </strong>Este expediente não<strong> </strong>
prevalecerá, entretanto,<strong> </strong>para as hipóteses da    <strong>CONTRATANTE</strong> omitir que já tenha recebido quaisquer outros
    valores por meio de procedimentos fraudulentos de buscar receber o que já
    recebera anteriormente o que requer por meio deste contrato em conformidade
com a o<strong>Parágrafo Primeiro e Segundo da Cláusula Décima Sexta e </strong>    <strong>Cláusula Oitava</strong><strong>.</strong>
</p>
<p>
    <strong> </strong>
</p>
<p>
    <strong>CLÁUSULA DÉCIMA SÉTIMA: </strong>
    Considerando que a <strong>CONTRATANTE</strong> omita dolosamente o que já
    recebeu a título de
    <strong>
        Licença-Maternidade, Salário Maternidade, Auxilio Maternidade, Salário
        natalidade,
    </strong>
    na ardil e enganosa tentativa de receber estes benefícios outra vez, a nota
promissória a que se refere o    <strong>Parágrafo Primeiro e Segundo da Cláusula Décima Sexta</strong>, não
    será cancelada, anulada ou inutilizada, podendo a mesma servir de título
    executivo em processo judicial de execução.
</p>
<p>
    <strong>CLÁUSULA DÉCIMA OITAVA: </strong>
    A <strong>CONTRATANTE </strong>receberá uma única parcela no valor que
    poderá variar entre R$2.000,00 (Dois Mil Reais) a R$4.000,00 (Quatro Mil
    Reais) para a hipótese de existir menores impúberes com idade superior de
    04 (quatro) meses.
</p>
<p>
    <strong>Parágrafo Primeiro: </strong>
    Em caso de existir criança menor de 04 (Quatro) meses na data do efetivo
pagamento do benefício a ser creditado, fica ciente a    <strong>CONTRATANTE</strong> que receberá proporcional aos meses de idade
da criança ate no máximo 04 (Quatro) parcelas conforme    <strong>Cláusula Primeira, </strong>do objeto deste contrato.
</p>
<p>
    <strong>Parágrafo Segundo: </strong>
    A <strong>CONTRATANTE</strong> fica ciente que em caso de retorno ao
    trabalho no período correspondente a 04 (Quatro) meses do nascimento da
    criança, este receberá de forma proporcional aos dias em que não trabalhou.
</p>
<p>
    <strong>CLÁUSULA DÉCIMA NONA: </strong>
    A <strong>CONTRATADA</strong> fica autorizada a deduzir dos valores
    recebidos para o <strong>CONTRATANTE</strong>, à importância referente a
honorários e despesas, aqui pactuados neste contrato, compreendidos na<strong>Cláusula Décima Sexta</strong> e    <strong>Cláusula Vigésima Terceira</strong><strong> </strong>deste
    contrato.
</p>
<p>
    <strong>CLÁUSULA VIGÉSIMA: </strong>
    Para liberação do recebimento dos direitos da <strong>CONTRATANTE</strong>
    a mesma deverá dirigir-se ao escritório da<strong> CONTRATADA</strong>,
    munida de R.G., CPF, Certidão de Casamento (ser for casada legalmente) e
    Comprovante de Endereço, em horário a ser previamente agendado, para o qual
    retirará o extrato e a liberação do pagamento<strong>,</strong> juntamente
    com todos os documentos originais por ela deixados, mesmo que tenha
    recebido anteriormente qualquer correspondência da autarquia concessora,
    conforme assim dispõe na<strong> Cláusula Sétima</strong>.
</p>
<p>
    <strong>CLÁUSULA VIGÉSIMA PRIMEIRA:</strong>
    O requerimento do benefício objeto desta contratação poderá tramitar em
    outros Municípios e Estados, ficando assim a <strong>CONTRATANTE </strong>
    ciente que a <strong>CONTRATADA </strong>para tanto disponibilizará de
    passagens aéreas, transporte publico e de seus veículos próprio com
    seguranças particulares para fim de se fazer o traslado, e um único lugar,
    pois poderá se valer de outras pessoas para o mesmo dia e horário
    combinado.
</p>
<p>
    <strong>Parágrafo Primeiro:</strong>
    No caso da <strong>CONTRATANTE</strong> se fazer acompanhada de conjugue,
    parentes, amigos e outros afins, estes deverão aguardar no endereço do
    escritório da <strong>CONTRATADA </strong>até que todo o procedimento de
recebimento termine, conforme assim dispõe na<strong> Cláusula Q</strong><strong>uint</strong><strong>a</strong><strong> Cláusula</strong><strong> Vigésima Primeira e</strong><strong> Parágrafo Segundo da </strong>    <strong>Cláusula Vigésima Primeira</strong><strong>.</strong>
</p>
<p>
    <strong>Parágrafo Segundo: </strong>
    A<strong> CONTRATANTE</strong> fica ciente que em caso de insistir em se
    fazer acompanhar de conjugue, parentes, amigos e outros afins junto a
    repartição responsável pelo pagamento do benefício, que tenha por fim
    tentar substituir a própria <strong>CONTRATANTE</strong> no recebimento do
    benefício aqui faz jus, este será imediatamente bloqueado, o que impedirá
    seu recebimento no dia e horário marcado pela <strong>CONTRATADA,</strong>
conforme assim dispõe na<strong> Cláusula Q</strong><strong>uint</strong><strong>a Cláusula Vigésima Primeira e </strong><strong>Parágrafo Primeiro da </strong>    <strong>Cláusula Vigésima Primeira.</strong><strong></strong>
</p>
<p>
    <strong>CLÁUSULA VIGÉSIMA SEGUNDA</strong>
    <strong>: </strong>
    Em caso de óbito da <strong>CONTRATANTE</strong> poderá receber o benefício
    pactuado na <strong>Cláusula Décima Sexta</strong> o legitimo cônjuge
    sucessor ou quem legalmente estiver com as guardas judiciais da criança,
    cujo procedimento atenderá as normas e diretrizes normativas estabelecidas
    pela autarquia, restringindo outros parentes ou afins do recebimento deste.
</p>
<p align="center">
    <strong><u>DAS DESPESAS GERAIS</u></strong>
    <strong><u>:</u></strong>
</p>
<p>
    <strong> </strong>
</p>
<p>
    <strong>CLÁUSULA VIGÉSIMA TERCEIRA: </strong>
    Serão cobrados <strong>20% (Vinte por Cento) </strong>referente às
    despesas, tais como, Guias de Contribuição, taxas, emolumentos, despesas
    cartorárias, cópias reprográficas, certidões, diligências, inclusive
    diárias de viagens, diligência em outra Comarca etc., bem como tudo o mais
    que se fizer necessário para alcançar os objetivos aqui contratados.
</p>
<p>
    <strong> </strong>
</p>
<p>
    <strong>Parágrafo Primeiro:</strong>
    <strong> </strong>
O valor dos serviços pactuados na    <strong>Cláusula Décima Sexta e Cláusula Vigésima Terceira </strong>não
    serão alterados nas seguintes hipóteses:
</p>
<p>
    a) De não se prosseguir a execução dos serviços aqui pactuados, que sejam
provenientes por quaisquer circunstancias não causada pela    <strong>CONTRATADA;</strong><strong></strong>
</p>
<p>
b) Para a hipótese de existir revogação da procuração, sem culpa da    <strong> CONTRATADA</strong>
</p>
<p>
    c) Ou a prática de quaisquer atos da <strong>CONTRATANTE</strong> que de
    algum modo viole o presente contrato, seguindo assim o pagamento
    normalmente ou a execução deste instrumento até o limite dos honorários
    pactuados.<strong> </strong>
</p>
<p>
    <strong><u> </u></strong>
</p>
<p align="center">
    <strong><u>DA DECLARAÇÃO</u></strong>
</p>
<p>
    <strong> </strong>
</p>
<p>
    <strong>CLÁUSULA VIGÉSIMA QUARTA:</strong>
    A <strong>CONTRATANTE </strong>declara ter ciência de que no final do
    cumprimento das obrigações contratuais, ou seja, tendo êxito junto à
    autarquia dos valores a serem levantados pela <strong>CONTRATADA</strong>,
    os quais<strong> </strong>deverão ser recebidos juntamente com os seus
documentos originais, que se encontra em guarda junto a    <strong>CONTRATADA</strong> em seu escritório.
</p>
<p>
    <strong>Parágrafo Primeiro:</strong>
    A <strong>CONTRATANTE</strong> declara ter ciência que o documento original
    de (CTPS) Carteira Profissional de Trabalho deixada por ela voluntariamente
    ficará de posse da <strong>CONTRATADA, onde</strong> só será devidamente
    devolvido no final da execução dos serviços aqui contratados, ficando assim
vedada a devolução da mesma durante o processo, conforme assim dispõe no<strong> Parágrafo Único </strong>da<strong>Cláusula Décima primeira </strong>e<strong> </strong><strong>Parágrafo Segundo</strong> da    <strong>Cláusula Vigésima Quarta</strong>.
</p>
<p>
    <strong>Parágrafo Segundo:</strong>
    A <strong>CONTRATANTE</strong> declara ter ciência que o documento original
    de (CTPS) Carteira Profissional de Trabalho deixada por ela voluntariamente
Ficará de posse da CONTRATADA, em conformidade com o<strong>Parágrafo Único da</strong><strong>Cláusula Décima primeira e </strong><strong>Parágrafo Primeiro e Segundo</strong> da<strong>Cláusula Vigésima Quarta, </strong>sendo assim a<strong> CONTRATANTE </strong>fica orientada pela    <strong>CONTRATADA</strong> através deste contrato, o seu impedimento de
    tentar usar os órgãos públicos no intuito ardil de enganar as autoridades
    policiais, fazendo (boletim de ocorrência por perda ou roubo) em busca de
    obter outra Carteira Profissional de Trabalho (2ª via), neste caso será
comunicado imediatamente a delegacia competente, o dolo da    <strong>CONTRATANTE</strong>, sob pena de incorrer nos termos previsto da
    lei, cabendo assim a execução deste instrumento até o limite dos honorários
    pactuados.
</p>
<p>
    <strong>Parágrafo Terceiro:</strong>
    <strong>A CONTRATANTE</strong>
    declara expressamente que não criará obstáculos para o sucesso deste
procedimento administrativo em conformidade com a <strong>Cláusula</strong><strong> D</strong><strong>écima</strong><strong> e a letra © do </strong>    <strong>Parágrafo Primeiro da Cláusula Vigésima Quinta, </strong>sob pena
de se criar obstáculo no sentido de causar prejuízo à    <strong>CONTRATADA</strong> na busca de seus direitos e consequentemente o
    recebimento de seus honorários, a <strong>CONTRATADA</strong> poderá, se
    sofrer prejuízo, ingressar com ação de cobrança de honorários cumulado com
    danos morais.
</p>
<p>
    <strong>Parágrafo Quarto: </strong>
    Tendo a<strong> </strong><strong>CONTRATANTE</strong><strong> </strong>
efetuado o pagamento dos honorários pactuados na <strong>C</strong>    <strong>láusula Quarta</strong> deste contrato<strong>,</strong> e não
sendo devolvida a NOTA PROMISSÓRIA, a <strong>CONTRATANTE</strong><strong> </strong>poderá promover ações contra a    <strong>CONTRATADA </strong>em busca de preservar os seus direitos.
</p>
<p>
    <strong>CLÁUSULA VIGÉSIMA QUINTA: </strong>
    Deixando a <strong>CONTRATANTE </strong>de honrar os honorários contratados
    na <strong>Cláusula Décima Sexta e Cláusula Vigésima Terceira </strong>
    deste contrato, a mesma autoriza a <strong>CONTRATADA</strong> a executar
    judicialmente o que lhe é devido, sejam através de demandas judiciais nas
    esferas <strong>PENAL e/ou</strong> <strong>CÍVEL </strong>para exigir o
    cumprimento deste contrato, até o limite dos honorários pactuados, ou
    executar a nota promissória garantidora deste contrato, podendo ser levado
    a protesto junto aos cartórios de títulos e protestos, podendo até ter seu
nome incluso nos    <strong> SERVIÇOS DE PROTEÇÃO AO CREDITO (SPC) e SERASA.</strong>
</p>
<p>
    <strong>
        <u>
            Parágrafo Primeiro: SÃO MOTIVOS PARA QUE SE RESCINDA ESTE PRESENTE
            INSTRUMENTO:
        </u>
    </strong>
</p>
<p>
    <strong><u></u></strong>
</p>
<p>
    a) A <strong>CONTRATANTE</strong> e a <strong>CONTRATADA</strong> deixar de
    observar quaisquer obrigações que conste no presente contrato.
</p>
<p>
b) A <strong>CONTRATANTE</strong> descumprir com o disposto na<strong> Cláusula </strong><strong>Décima Sexta Cláusula </strong>    <strong>Vigésima Terceira</strong> deste contrato.
</p>
<p>
c) Não apresentar os documentos solicitados pela<strong> CONTRATADA, </strong>conforme assim preceituam a<strong>Cláusula Décima</strong><strong> e Parágrafo Terceiro</strong><strong> Cláusula Vigésima Quarta.</strong> <strong> </strong>    <strong></strong>
</p>
<p>
    d) Não comunicar a<strong> CONTRATADA</strong> o recebimento de algum
benefício<strong> </strong>conforme <strong>Cláusula Terceira</strong>    <strong>,</strong> ou qualquer outra violação das cláusulas deste contrato.
</p>
<p>
    e) Criar obstáculos para o sucesso deste demanda, no sentido de causar
prejuízo à <strong>CONTRATADA conforme o Parágrafo Terceiro da </strong>    <strong>cláusula Vigésima Quarta.</strong>
</p>
<p>
f)<strong> </strong>Tentar induzir ou manter<strong> </strong>a    <strong> CONTRATADA </strong>a erro, mediante artifício ardil de qualquer
    outro meio, prestando Informações falsas<strong> </strong>a
    <strong>
        CONTRATADA em conformidade com a cláusula Vigésima Sexta e o Parágrafo
        único.
    </strong>
</p>
<p>
    <strong></strong>
</p>
<p>
    <strong>
        CLÁUSULA VIGÉSIMA SEXTA
        <u>
            : NO CASO DE INADIMPLÊNCIA EM CONFORMIDADE COM A CLÁUSULA VIGÉSIMA
            QUINTA A
        </u>
    </strong>
    <strong><u>CONTRATANTE</u></strong>
    <strong>
        <u> DECLARA SER RÉ CONFESSA NOS CRIMES DE APROPRIAÇÃO INDÉBITA. </u>
    </strong>
</p>
<p>
    <strong>
        “Art. 168 - Apropriar-se de coisa alheia móvel, de que tem a posse ou a
        detenção:”
        <br/>
        <br/>
    </strong>
</p>
<p>
    <strong></strong>
</p>
<p>
    <strong>­­­­­­­­­­­­­­____________________________________________</strong>
</p>
<p>
    <strong></strong>
</p>
<p>
    <strong></strong>
</p>
<p>
    <strong>Parágrafo único</strong>
    <strong>: </strong>
    A <strong>CONTRATANTE</strong> declara esta ciente sob pena de incorre na
    pratica de crime previsto no artigo 299 do código penal brasileiro ser
    completas e verdadeiras as informações prestadas, isentando o procurador a
empresa <strong>CONTRATADA,</strong>    <strong>LIDER CONSULTORIA CNPJ 24.808.801/0001-81</strong> de qualquer
    responsabilidade Penal ou Civil.
</p>
<p>
    <strong>CLÁUSULA VIGÉSIMA NONA: </strong>
    <u>A</u>
    <strong><u> CONTRATANTE </u></strong>
    <u>
        declara que, antes de assinar, examinou e leu o presente instrumento,
        reconhecendo-o em tudo correto, sob pena de incorrer nos termos
        previsto no art. 299 do Código Penal, declarando finalmente que
        reconhece, desde já, como líquida e certa a obrigação contraída por
        este instrumento particular de contrato.
    </u>
</p>
<p>
    <strong></strong>
</p>
<p align="center">
    <strong><u>DO FORO:</u></strong>
</p>
<p>
    <strong></strong>
</p>
<p>
    As partes contratadas elegem o foro da cidade do Rio de Janeiro para
    dirimir qualquer ação oriunda deste contrato.
</p>
<p>
    E, por assim terem contratado, assinam o presente em duas vias ou via
    e-mail de igual teor e forma, na presença das testemunhas abaixo
    qualificadas que também assinam.
</p>
<p align="right">
    <strong></strong>
</p>
<p align="right">
    <strong>Rio de Janeiro </strong>
________<strong>de</strong>________________________    <strong> de 2017</strong>
</p>
<p align="right">
    <strong></strong>
</p>
<p>
    <br/>
    ___________________________ ___________________________
</p>
<p>
    Testemunhas:
</p>
<p>
    <br/>
    <br/>
    ___________________________ ___________________________
    <br/>
    Nome: Nome:
    <br/>
    CPF: CPF:
</p>
