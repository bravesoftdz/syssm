<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Nota Promissória</title>
<style>
	.image {
   		position: relative;
	}

	h2 {
	position: absolute;
	width: 100%;
	margin: 0 auto;
	font-family: Arial, Helvetica, sans-serif;
	font-size: 14px;
	}
	
	h2.numcontrato {
	top: 30px;
	left: 139px;
	width: 127px;
	height: 16px;
	}
	
	h2.valornum {
	top: 30px;
	left: 508px;
	width: 57px;
	height: 16px;
	}
	
	h2.valorext {
	top: 55px;
	left: 150px;
	width: 480px;
	height: 16px;
	}
	
	h2.nome {
	top: 195px;
	left: 182px;
	width: 445px;
	height: 16px;
	}
	
	h2.cpf {
	top: 217px;
	left: 182px;
	width: 215px;
	height: 16px;
	}

</style>
</head>

<body>
<img src="[PATH_IMG]" width="649" height="279" />
<h2 class="numcontrato">[NUMERO_CONTRATO]</h2>
<h2 class="valornum">[VALOR_NUMERO]</h2>
<h2 class="valorext">[VALOR_EXTENSO]</h2>
<h2 class="nome">[NOME_BENEFICIARIO]</h2>
<h2 class="cpf">[CPF_BENEFICIARIO]</h2>
</body>
</html>