<?php
	try {
		echo("Conectando BD");
		mysql_connect("127.0.0.1", "lidercon_admin", "LideCtori@201M7");
		$db = mysql_select_db("lidercon_saprev");
		echo("Conexão OK.");
	
		echo("Recebendo informações remotas");
		$username = $_POST["username"];
		$password = $_POST["password"];
	
	   
  if (!empty($_POST)) {
  if (empty($_POST['username']) || empty($_POST['password'])) {
  // Create some data that will be the JSON response 
          $response["success"] = 0;
          $response["message"] = "Necessário preencher todos os campos.";
          
          //die is used to kill the page, will not let the code below to be executed. It will also
          //display the parameter, that is the json data which our android application will parse to be //shown to the users
          die(json_encode($response));
      }
$query = " SELECT * FROM users ". 
         "  WHERE name = '$username'".
	  	 "    and password = '$password'";
      
$sql1=mysql_query($query);
$row = mysql_fetch_array($sql1);
  
  if (!empty($row)) {
	$response["success"] = 1;
	$response["message"] = " Login bem-sucedido ";
	die(json_encode($response));
  }
		else{   
			$response["success"] = 0;
			$response["message"] = "Nome de usuário ou senha inválidos ";
			die(json_encode($response));
  		}
	}
	  else{   
		$response["success"] = 0;
		$response["message"] = " Necessário preencher todos os campos. ";
		die(json_encode($response));
	}
   
	mysql_close();
  
	} 
	catch (Exception $e) {
		echo($e->getMessage());
	}  
  
  ?>