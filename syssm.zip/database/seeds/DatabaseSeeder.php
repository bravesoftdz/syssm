<?php

use Illuminate\Database\Seeder;
use Database\Seeds\UsersTableSeeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // $this->call(UsersTableSeeder::class);
		Eloquent::unguard();

		$this->call('UsersTableSeeder');		
    }
}

class UsersTableSeeder extends Seeder
{

	public function run()
	{
		DB::table('users')->delete();
		User::create(array(
			'name'     => 'admin',
			'email'    => 'suporte@thiagocoutinho.com',		
			'password' => Hash::make('admin'),
		));
	}

}