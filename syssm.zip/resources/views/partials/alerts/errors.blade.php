@if (count($errors))
<div class="row">
  <div class="col-md-12">
  @foreach ($errors as $error)
      <div class="alert alert-{{ $error['level'] }}">{!! $error['error'] !!}</div>
  @endforeach
  </div>
</div>
@endif