@extends('layouts.master')

@section('content')

<?php 
	use App\Models\Produto;
	
	$produto = new Produto;	
	$insert_mode = True;
?>

<h1>Novo Produto</h1>
<hr>

@include('partials.alerts.errors')
@include('produtos.form', ['produto' => $produto, 
							  'insert_mode' => $insert_mode])

    <div class="container">
		@yield('produtos-form-script')	
		@yield('produtos-form')
	</div>
  
@stop
