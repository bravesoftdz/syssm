@extends('layouts.master')

@section('content')

<div class="container-fluid">
	<div class="col-md-12">
		<h1>Lista de Produtos</h1>
	</div>
</div>

<div class='table-responsive'>
	<table class = 'table table-striped'>
		<thead>
			<tr>
				<th>Código</th>
				<th>Nome</th>
				<th>Resumo</th>
				
			</tr>
			<tr>
				<td><a href="{{ route('produtos.create') }}" class="btn btn-info"><span class="glyphicon glyphicon-plus"></span></a>
				Novo Produto...
				</td>
			</tr>
		</thead>
	
		<tbody>
		@if(isset($produto))
			@foreach($produto as $produto)
				<tr>				
					<td><a href="{{ route('produtos.edit', $produto->id) }}" data-toggle="tooltip" title="Editar">{{ $produto->id }}</a>
					</td>
					<td>{{ $produto->nome }}</td>		
					<td>{{ $produto->resumo }}</td>	
					<td>
					<p>
						<a class="btn btn-danger" role="button" data-toggle="modal" data-target="#modal-delete" title="Excluir"><span class="glyphicon glyphicon-trash"></span></a>
					</p>		
					</td>
					
					{{-- Confirm Delete --}}
					<div class="modal fade" id="modal-delete" tabIndex="-1">
						<div class="modal-dialog">
							<div class="modal-content">
							<div class="modal-header">
								<button type="button" class="close" data-dismiss="modal">
								×
								</button>
								<h4 class="modal-title">Confirmação</h4>
							</div>
							<div class="modal-body">
								<p class="lead">
								<i class="fa fa-question-circle fa-lg"></i>  
								Tem certeza de que deseja excluir o registro?
								</p>
							</div>
							<div class="modal-footer">
								<form method="POST" action="{{ route('produtos.destroy', $produto->id) }}">
								<input type="hidden" name="_token" value="{{ csrf_token() }}">
								<input type="hidden" name="_method" value="DELETE">
								<button type="button" class="btn btn-default" data-dismiss="modal">Não</button>
								<button type="submit" class="btn btn-danger"><i class="fa fa-times-circle"></i> Sim</button>
								</form>
							</div>
							</div>
						</div>
					</div>					
					
				</tr>
			@endforeach	
		@endif
		</tbody>
		
	</table>
</div>

@stop