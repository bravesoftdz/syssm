@extends('layouts.master')

@section('content')

<h1>Editar Produto</h1>
<hr>

@include('partials.alerts.errors')
@include('produtos.form', ['produto' => $produto, 
						      'insert_mode' => False])

    <div class="container">
		@yield('produtos-form-script')
		@yield('produtos-form')
	</div>

@stop