@section('produtos-form-script')

<script type="text/javascript">

    $.ajaxSetup({
        headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') }
    });

    $(document).ready(function()
		{		
			formmodified = 0;
			
			$('form *').change(function(){
				formmodified = 1;
			});

			$('input[name="btn_cancelar"]').on('click', function(e){
				var $form = $(this).closest('form');
				var $indexpage = "{!! route('produtos.index'); !!}";

				if (formmodified == 1) {				
					e.preventDefault();
					$('#modal-cancel').modal({ backdrop: 'static', keyboard: false }).on('click', '#modal-cancel', function (e) {
						document.location.href = $indexpage;
					});						
				}
			});

		});
					
</script> 

@stop

@section('produtos-form')

@if($insert_mode)
	{!! Form::open(['route' => 'produtos.store']) !!}
@else
	{!! Form::model($produto, ['method' => 'PATCH',
							'route' => ['produtos.update', $produto->id]
						   ]) !!}
@endif

    <div class="form-group col-md-8">
        {!! Form::label('nome', 'Descrição', ['class' => 'control-label']) !!}
        {!! Form::text('nome', null, ['class' => 'form-control']) !!}
    </div>
    <div class="form-group col-md-4">
        {!! Form::label('codbarras', 'Código de Barras', ['class' => 'control-label']) !!}
        {!! Form::text('codbarras', null, ['class' => 'form-control']) !!}
    </div>

    <div class="form-group col-md-4">
        {!! Form::label('preco_custo', 'Preço de Custo (R$)', ['class' => 'control-label']) !!}
        {!! Form::text('preco_custo', null, ['class' => 'form-control']) !!}
    </div>
    <div class="form-group col-md-4">
        {!! Form::label('preco_venda', 'Preço de Venda (R$)', ['class' => 'control-label']) !!}
        {!! Form::text('preco_venda', null, ['class' => 'form-control']) !!}
    </div>
    <div class="form-group col-md-4">
        {!! Form::label('estoque_minimo', 'Estoque Mínimo', ['class' => 'control-label']) !!}
        {!! Form::text('estoque_minimo', null, ['class' => 'form-control']) !!}
    </div>

    <div class="form-group col-md-12">
        {!! Form::label('resumo', 'Resumo', ['class' => 'control-label']) !!}
        {!! Form::textarea('resumo', null, ['size' => '30x3', 'class' => 'form-control']) !!}		
    </div>
    
    <div class="form-group col-md-12">
        <hr>
        <p class="text-right">
            {!! Form::submit('Gravar', ['class' => 'btn btn-primary']) !!}
            @if(!$insert_mode)
                <a class="btn btn-danger" role="button" data-toggle="modal" data-target="#modal-cancel">Cancelar</a>	 
                @if(Config('globals.usuario_admin'))
                    <a class="btn btn-default" role="button" data-toggle="modal" data-target="#modal-delete" title="Excluir"><span class="glyphicon glyphicon-trash"></span></a>
                @endif
            @endif
        </p>
    </div>

{!! Form::close() !!}

    <div class="modal fade" id="modal-cancel" tabIndex="-1">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">
              ×
            </button>
            <h4 class="modal-title">Confirmação</h4>
          </div>
          <div class="modal-body">
            <p class="lead">
              <i class="fa fa-question-circle fa-lg"></i>  
              Existem dados não salvos. Tem certeza de que deseja sair?
            </p>
          </div>
          <div class="modal-footer">
              <a role="button" class="btn btn-default" data-dismiss="modal">Não</a>
              <a href="{{ route('produtos.index') }}" class="btn btn-danger" >Sim</a>
          </div>
        </div>
      </div>
    </div>
  </div> 
  
	{{-- Confirm Delete --}}
	<div class="modal fade" id="modal-delete" tabIndex="-1">
		<div class="modal-dialog">
			<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">
				×
				</button>
				<h4 class="modal-title">Confirmação</h4>
			</div>
			<div class="modal-body">
				<p class="lead">
				<i class="fa fa-question-circle fa-lg"></i>  
				Tem certeza de que deseja excluir o registro?
				</p>
			</div>
			<div class="modal-footer">
				<form method="POST" action="{{ route('produtos.destroy', $produto->id) }}">
				<input type="hidden" name="_token" value="{{ csrf_token() }}">
				<input type="hidden" name="_method" value="DELETE">
				<button type="button" class="btn btn-default"
						data-dismiss="modal">Não</button>
				<button type="submit" class="btn btn-danger">
					<i class="fa fa-times-circle"></i> Sim
				</button>
				</form>
			</div>
			</div>
		</div>
	</div>  
  
@stop