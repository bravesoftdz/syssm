@section('searchbox-script')

<script type="text/javascript">

	$(document).ready(function(){
		
		$("#tipo_pesquisa").change(function() {
			
			$valor_pesquisa = $(this).prop('value');			
			
			switch ($valor_pesquisa) {
				case "0": //nome do beneficiário
				{
					VMasker(document.getElementById("valor_pesquisa")).unMask();
					break;
				}
				case "1": //CPF do beneficiário
				{
					VMasker(document.getElementById("valor_pesquisa")).maskPattern('999.999.999-99');
					break;
				}
				case "2": //Número do contrato
				{
					VMasker(document.getElementById("valor_pesquisa")).maskPattern('9999999999');
					break;
				}
				default:
				{
					VMasker(document.getElementById("valor_pesquisa")).unMask();
					break;
				}
			}
		});
		
		$("#pesquisa_todos").click(function() {
			if ($(this).is(':checked')) {
				//$("#valor_pesquisa").prop('value', '');
				$("#valor_pesquisa").prop('disabled', true);
			}else
			{
				$("#valor_pesquisa").prop('disabled', false);
			}
		});
	});
	
</script>

@stop

@section('searchbox-content')
	
<?php
	
	$style_chk_todos = 'margin: 0px 0 0; '.
	                   'width: 20%;'.
					   'height: 34px;'.
					   'font-size: 14px;';
	$style_lbl_todos = 'position: absolute; '.
	                   'top: 0px; '.
					   'padding: 6px 12px;'.
					   'height: 34px;'.
					   'font-size: 16px;';	
?>	
	
	{{-- Pesquisar --}}
	<div class="modal fade" id="modal-search" tabIndex="-1">
		<div class="modal-dialog">
			<form method="GET" action="{{ route('search', False) }}" accept-charset="UTF-8">	
				<input type="hidden" name="_token" value="{{ csrf_token() }}">
				<input type="hidden" name="_method" value="GET">
			<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">
				×
				</button>
				<h4 class="modal-title">Pesquisar</h4>
			</div>
			<div class="modal-body">
				<div class="col-md-5">
					{!! Form::select('tipo_pesquisa', Config('globals.array_SearchTiposPesquisa'), 0, ['class' => 'form-control', 'maxlength' => 40, 'id' => 'tipo_pesquisa']) !!}
				</div>
				<div class="col-md-4">
					{!! Form::text('valor_pesquisa', null, ['class' => 'form-control', 'maxlength' => 80, 'id' => 'valor_pesquisa']) !!}
				</div>
				<div class="col-md-3">					                                                                                         
					{!! Form::checkbox('pesquisa_todos', 0, null, ['id' => 'pesquisa_todos', 'name' => 'pesquisa_todos[]', 'style' => $style_chk_todos]) !!}
                    {!! Form::label ('lblpesquisa_todos', 'Todos', ['for' => 'pesquisa_todos', 'style' => $style_lbl_todos]) !!}
				</div>					
			</div>			
			<br><br>
			<div class="modal-footer">			
				<button type="submit" class="btn btn-success">Pesquisar</button>
				<button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
			</div>
			</div>
			</form>
		</div>
	</div>	

@stop