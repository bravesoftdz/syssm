<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>SysSM - Controle de Estoque</title>

<link rel="stylesheet" href="https://code.jquery.com/ui/1.11.2/themes/smoothness/jquery-ui.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
<link rel="stylesheet" href="{{ URL::asset('css/MonthPicker.min.css') }}" type="text/css" >
<link rel="stylesheet" href="{{ Config('globals.url_css_navbar') }}" type="text/css" >   
<link rel="stylesheet" href="{{ Config('globals.url_css_loginmodal') }}" type="text/css" >
<link rel="stylesheet" href="{{ URL::asset('css/digital-clock.css') }}" type="text/css" >
<link rel="shortcut icon" href="{{ asset('favicon.ico') }}">
<link rel="icon" type="image/png" href="{{ asset('favicon-32x32.png') }}" sizes="32x32" />
<link rel="icon" type="image/png" href="{{ asset('favicon-16x16.png') }}" sizes="16x16" />

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://code.jquery.com/jquery-3.2.1.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
<script src="https://cdn.rawgit.com/digitalBush/jquery.maskedinput/1.4.1/dist/jquery.maskedinput.min.js"></script>
<script src="{{ URL::asset('js/vanilla-masker.js') }}"></script>
<script src="{{ URL::asset('js/MonthPicker.min.js') }}"></script>
<script src="{{ URL::asset('js/digital-clock.js') }}"></script>

<script type="text/javascript">

	$(document).ready(function(){

		//inicializando a tela modal de troca de senha 
		$('#modal-changepass').on('shown.bs.modal', function () {
			$('#senha_atual').val('');
			$('#password').val('');
			$('#password_confirmation').val('');
			$('#senha_atual').focus();
		});
		
		//inicializando a tela modal de pesquisa
		$('#modal-search').on('shown.bs.modal', function () {
			
			$('#valor_pesquisa').val('');
			$('#tipo_pesquisa option[value="0"]').prop('selected', true);
			$('#valor_pesquisa').focus();						
		});

		
	});
</script>

</head>
<body>	  

@include('layouts.searchbox')
@include('layouts.changepass')
  
<nav class="navbar navbar-default navbar-inverse navbar-fixed-top" role="navigation">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <!-- logo -->
      <a class="navbar-brand" href="#">
      <img alt="logo" src="{{ Config('globals.logo_sistema') }}"/></a>
    </div>
	
	
    <div class="collapse navbar-collapse animated fadeIn" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav animated fadeIn text16">
      </ul>
{{--
      <ul class="nav navbar-nav navbar-center">      
		<div class="clock">		
			<ul>
			    <li id="Date">carregando...</li>
		    	<li id="Date">&nbsp;&nbsp;às&nbsp;&nbsp;</li>			
				<li id="hours">00</li>
				<li id="point">:</li>
				<li id="min">00</li>
				<li id="point">:</li>
				<li id="sec">00</li>
			</ul>
		</div>
      </ul>
--}}      
	  @if((Auth::check())) 
      <ul class="nav navbar-nav navbar-right">
		<li>
			<a href="#" role="button" data-toggle="modal" data-target="#modal-changepass" title="Alterar senha de {{ Config('globals.nome_usuario') }}">&nbsp;{{ Config('globals.nome_usuario') }} 
				<span style="font-size:16px;" class="pull-left hidden-xs-down showopacity glyphicon glyphicon-user"></span>
			</a>
		</li>
		<li>
			<a href="{{ route('logout') }}">&nbsp;Sair
				<span style="font-size:16px;" class="pull-left hidden-xs-down showopacity glyphicon glyphicon-log-out"></span>
			</a>
		</li>		
      </ul>
	  @endif
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>

<!-- Second Nav -->
<nav class="navbar navbar-default navbar-static-top" role="navigation">
  <div class="container-fluid">
    @if((Auth::check())) 
	<div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-2">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <!-- Brand -->
      <a class="navbar-brand" href="#">{{ Config('globals.nome_empresa') }}</a>
    </div>
	
	<div class="collapse navbar-collapse animated fadeIn" id="bs-example-navbar-collapse-2">
		<ul class="nav navbar-nav animated fadeIn">
			<li><a href="{{ route('home') }}">&nbsp;Início<span style="font-size:16px;" class="pull-left hidden-xs-down showopacity glyphicon glyphicon-home"></span></a></li>		
			<li><a href="{{ route('produtos.create') }}">&nbsp;Produtos<span style="font-size:16px;" class="pull-left hidden-xs-down showopacity glyphicon glyphicon-folder-open"></span></a></li>
							
			@if(Config('globals.usuario_admin'))
			<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown">&nbsp;Gerencial 
				<span class="caret"></span>
				<span style="font-size:16px;" class="pull-left hidden-xs-down showopacity glyphicon glyphicon-wrench"></span></a>
				<ul class="dropdown-menu animated flipInX" role="menu">				
					<li><a href="{{ route('users.index') }}">Usuários</a></li>
					<li><a href="{{ route('parametros.index') }}">Configurações</a></li>
					<li><a href="{{ route('managebackup') }}">Backup</a></li>
					<li><a href="{{ route('managelog') }}">Registro de Atividades</a></li>
				</ul>
			</li> 
			@endif    
		</ul>
		<ul class="nav navbar-nav navbar-right">
		<li>
			<a href="#" role="button" data-toggle="modal" data-target="#modal-search" title="Pesquisar">&nbsp;Pesquisar		
			<span style="font-size:16px;" class="pull-left hidden-xs-down showopacity glyphicon glyphicon-search"></span>
			</a>
		</li>
    </div><!-- /.navbar-collapse -->
	@endif
  </div><!-- /.container-fluid -->
</nav>

<main>
    <div class="container">

			@if(Session::has('flash_message'))
				<div class="alert alert-success">
					{{ Session::get('flash_message') }}
				</div>
			@endif
			@if(Session::has('flash_info'))
				<div class="alert alert-info">
					{{ Session::get('flash_info') }}
				</div>
			@endif		
			@if(Session::has('flash_warning'))
				<div class="alert alert-warning">
					{{ Session::get('flash_warning') }}
				</div>
			@endif
			@if(Session::has('flash_danger'))
				<div class="alert alert-danger">
					{{ Session::get('flash_danger') }}
				</div>
			@endif	

			@yield('content')
			@yield('searchbox-script')
			@yield('searchbox-content')
			@yield('changepass-content')			
			
	</div>
</main>

</body>
</html>