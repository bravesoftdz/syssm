@section('changepass-content')

{{-- Alterar senha --}}
<div class="modal fade" id="modal-changepass" tabIndex="-1">
	<div class="modal-dialog">
		<?php
			$user = Auth::user();
		?>
		<form method="POST" action="{{ route('changepass') }}" accept-charset="UTF-8">
			<input type="hidden" name="_token" value="{{ csrf_token() }}">
			<input type="hidden" name="_method" value="POST">
		<div class="modal-content">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal">
			×
			</button>
			<h4 class="modal-title">Alterar a senha</h4>
		</div>
		<div class="modal-body">
			<div class="col-md-4">
				{!! Form::label('senha_atual', 'Senha atual', ['class' => 'control-label']) !!}
				{!! Form::password('senha_atual', null, ['class' => 'form-control']) !!}
			</div>
			<div class="col-md-4">
				{!! Form::label('password', 'Nova senha', ['class' => 'control-label']) !!}
				{!! Form::password('password', null, ['class' => 'form-control']) !!}
			</div>
			<div class="col-md-4">
				{!! Form::label('password_confirmation', 'Confirme a Senha', ['class' => 'control-label']) !!}
				{!! Form::password('password_confirmation', null, ['class' => 'form-control']) !!}
			</div>				
		</div><br><br>
		<div class="modal-footer">			
			{!! Form::submit('Alterar', ['class' => 'btn btn-primary']) !!}
			<a class="btn btn-default" role="button" data-dismiss="modal">Cancelar</a>
		</div>
		</div>
		</form>
	</div>
</div>

@stop