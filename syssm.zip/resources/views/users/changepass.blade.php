@extends('layouts.master')

@section('content')

<h1>Alterar senha</h1>
<hr>

@include('partials.alerts.errors')

{!! Form::model($user, [
    'method' => 'PATCH',
    'route' => ['users.update', $user->id]
]) !!}

<div class="form-group col-md-4">
    {!! Form::label('password', 'Senha', ['class' => 'control-label']) !!}
	{!! Form::password('password', null, ['class' => 'form-control']) !!}
</div>
<div class="form-group col-md-4">
    {!! Form::label('password_confirmation', 'Confirme a Senha', ['class' => 'control-label']) !!}
	{!! Form::password('password_confirmation', null, ['class' => 'form-control']) !!}
</div>

{!! Form::submit('Gravar', ['class' => 'btn btn-primary']) !!}
<a class="btn btn-primary" role="button" data-toggle="modal" data-target="#modal-cancel">Cancelar</a>

{!! Form::close() !!}

@stop