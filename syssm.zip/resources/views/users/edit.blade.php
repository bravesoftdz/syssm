@extends('layouts.master')

@section('content')

<h1>Editar Usuário</h1>
<hr>

@include('partials.alerts.errors')
@include('users.form', ['user' => $user, 
						'insert_mode' => False])

    <div class="container">
		@yield('users-form')
	</div>

@stop