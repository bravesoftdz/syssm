@extends('layouts.master')

@section('content')

<?php 
	use App\Models\User;
	
	$user = new User;	
	$insert_mode = True;
?>

<h1>Novo Usuário</h1>
<hr>

@include('partials.alerts.errors')
@include('users.form', ['user' => $user, 
						'insert_mode' => $insert_mode])

    <div class="container">
		@yield('users-form')
	</div>
  
@stop
