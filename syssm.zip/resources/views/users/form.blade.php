@section('users-form')

@if($insert_mode)
	{!! Form::open(['route' => 'users.store']) !!}
@else
	{!! Form::model($user, ['method' => 'PATCH',
							'route' => ['users.update', $user->id]
						   ]) !!}
@endif

<div class="form-group col-md-12">
    {!! Form::label('nome_funcionario', 'Nome do Funcionário', ['class' => 'control-label']) !!}
    {!! Form::text('nome_funcionario', null, ['class' => 'form-control']) !!}
</div>

<div class="form-group col-md-4">	
    {!! Form::label('name', 'Login', ['class' => 'control-label']) !!}
	@if($insert_mode)
		{!! Form::text('name', null, ['class' => 'form-control']) !!}
    @else
		{!! Form::text('name', null, ['class' => 'form-control', 'disabled']) !!}
	@endif
</div>
<div class="form-group col-md-4">
    {!! Form::label('password', 'Senha', ['class' => 'control-label']) !!}
    {!! Form::password('password', null, ['class' => 'form-control']) !!}
</div>
<div class="form-group col-md-4">
    {!! Form::label('password', 'Confirme a Senha', ['class' => 'control-label']) !!}
    {!! Form::password('password', null, ['class' => 'form-control']) !!}
</div>

<div class="form-group col-md-4">
    {!! Form::label('email', 'E-Mail', ['class' => 'control-label']) !!}
    {!! Form::text('email', null, ['class' => 'form-control']) !!}
</div>
<div class="form-group col-md-4">
    {!! Form::label('id_tipo_perfil', 'Tipo de Perfil', ['class' => 'control-label']) !!}
	@if(Config('globals.usuario_admin'))
		{!! Form::select('id_tipo_perfil', Config('globals.array_tipo_perfil'), $user->id_tipo_perfil, ['class' => 'form-control']) !!}
	@elseif(Config('globals.usuario_gerente'))
		{!! Form::hidden('id_tipo_perfil', Config('globals.id_perfil_funcionario')) !!}
		{!! Form::text('id_tipo_perfil', 'Funcionário', ['class' => 'form-control', 'disabled']) !!}	
	@endif
</div>
<div class="form-group col-md-4">
    {!! Form::label('id_escritorio', 'Escritório', ['class' => 'control-label']) !!}
	@if(Config('globals.usuario_admin'))	
		{!! Form::select('id_escritorio', Config('globals.array_escritorio'), $user->id_escritorio, ['class' => 'form-control']) !!}
	@elseif(Config('globals.usuario_gerente'))		
		@foreach (Config('globals.array_escritorio') as $UsuarioNomeEscritorio)
		@endforeach
		{!! Form::hidden('id_escritorio', Config('globals.usuario_escritorio')) !!}
		{!! Form::text('id_escritorio', $UsuarioNomeEscritorio, ['class' => 'form-control', 'disabled']) !!}		
	@endif
</div>

{!! Form::submit('Gravar', ['class' => 'btn btn-primary']) !!}
<a class="btn btn-danger" role="button" data-toggle="modal" data-target="#modal-cancel">Cancelar</a>

{!! Form::close() !!}

    <div class="modal fade" id="modal-cancel" tabIndex="-1">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">
              ×
            </button>
            <h4 class="modal-title">Confirmação</h4>
          </div>
          <div class="modal-body">
            <p class="lead">
              <i class="fa fa-question-circle fa-lg"></i>  
              Existem dados não salvos. Tem certeza de que deseja sair?
            </p>
          </div>
          <div class="modal-footer">
              <a role="button" class="btn btn-default" data-dismiss="modal">Não</a>
              <a href="{{ route('users.index') }}" class="btn btn-danger" >Sim</a>
          </div>
        </div>
      </div>
    </div>
  </div> 
  
@stop