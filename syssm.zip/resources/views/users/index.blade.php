@extends('layouts.master')

@section('content')

<script type="text/javascript">
/**
*   I don't recommend using this plugin on large tables, I just wrote it to make the demo useable. It will work fine for smaller tables 
*   but will likely encounter performance issues on larger tables.
*
*		<input type="text" class="form-control" id="dev-table-filter" data-action="filter" data-filters="#dev-table" placeholder="Filter Developers" />
*		$(input-element).filterTable()
*		
*	The important attributes are 'data-action="filter"' and 'data-filters="#table-selector"'
*/
(function(){
    'use strict';
	var $ = jQuery;
	$.fn.extend({
		filterTable: function(){
			return this.each(function(){
				$(this).on('keyup', function(e){
					$('.filterTable_no_results').remove();
					var $this = $(this), 
                        search = $this.val().toLowerCase(), 
                        target = $this.attr('data-filters'), 
                        $target = $(target), 
                        $rows = $target.find('tbody tr');
                        
					if(search == '') {
						$rows.show(); 
					} else {
						$rows.each(function(){
							var $this = $(this);
							$this.text().toLowerCase().indexOf(search) === -1 ? $this.hide() : $this.show();
						})
						if($target.find('tbody tr:visible').size() === 0) {
							var col_count = $target.find('tr').first().find('td').size();
							var no_results = $('<tr class="filterTable_no_results"><td colspan="'+col_count+'">No results found</td></tr>')
							$target.find('tbody').append(no_results);
						}
					}
				});
			});
		}
	});
	$('[data-action="filter"]').filterTable();
})(jQuery);

$(function(){
    // attach table filter plugin to inputs
	$('[data-action="filter"]').filterTable();
	
	$('.container').on('click', '.panel-heading span.filter', function(e){
		var $this = $(this), 
			$panel = $this.parents('.panel');
		
		$panel.find('.panel-body').slideToggle();
		if($this.css('display') != 'none') {
			$panel.find('.panel-body input').focus();
		}
	});
	$('[data-toggle="tooltip"]').tooltip();
})
</script>

<h1>Lista de Usuários</h1>
<hr>

	<a href="{{ route('users.create') }}" class="btn btn-info"><span class="glyphicon glyphicon-plus"></span>
	Adicionar novo usuário</a><br><br>

<div class='table-responsive'>

	<div class="col-md-10">
	
	<div class="panel panel-primary">
		<div class="panel-heading">
			<h3 class="panel-title">Usuários</h3>
			<div class="pull-right" style="margin-top: -15px;">
				<span class="clickable filter" data-toggle="tooltip" title="Exibir filtro" data-container="body">
					<i class="glyphicon glyphicon-filter"></i>
				</span>
			</div>
		</div>
		<div class="panel-body">
			<input type="text" class="form-control" id="user-table-filter" data-action="filter" data-filters="#user-table" placeholder="Filtrar Usuários" />
		</div>	

	<table class='table table-hover'  id="user-table">
		<thead>
			<tr>
				<th>Funcionário</th>
				<th>Usuário</th>
				<th>Tipo de Perfil</th>
				@if(Config('globals.usuario_admin'))
					<th>Escritório</th>
				@endif
			</tr>
		</thead>
	
		<tbody>
		@if(isset($users))		
			@foreach($users as $user)
			@if(Config('globals.usuario_admin') || (Config('globals.usuario_gerente') && (($user->id_escritorio == Config('globals.usuario_escritorio')) &&($user->id_tipo_perfil != Config('globals.id_perfil_admin')))))
			<tr>
				<td>
				@if( Config('globals.usuario_admin') || (Config('globals.usuario_gerente') && (($user->id_escritorio == Config('globals.usuario_escritorio')) && (($user->id_tipo_perfil == Config('globals.id_perfil_funcionario')) || (Config('globals.id_usuario') == $user->id)))))
					<a href="{{ route('users.edit', $user->id) }}" data-toggle="tooltip" title="Editar" >{{ $user->nome_funcionario }}</a>
				@else
					{{ $user->nome_funcionario }}
				@endif
				</td>
				<td>{{ $user->name }}</td>				
				<td>
				@if($user->tipoperfil)	
					{{ $user->tipoperfil->nome }}
				@else
					N/D
				@endif
				</td>
				
				@if(Config('globals.usuario_admin'))
					<td>
					@if($user->escritorio)
						{{ $user->escritorio->descricao }}
					@else
						N/D
					@endif
					</td>
				@endif
				<td>
					<p>
						@if(((Config('globals.id_usuario') != $user->id)) &&
						    ((Config('globals.usuario_admin') && ($user->id_tipo_perfil != Config('globals.id_perfil_admin'))) || 
						     (Config('globals.usuario_gerente') && (($user->id_escritorio == Config('globals.usuario_escritorio')) && (Config('globals.id_perfil_funcionario') == $user->id_tipo_perfil)))))
							<a class="btn btn-danger" role="button" data-toggle="modal" data-target="#modal-delete-{{ $user->id }}" title="Excluir"><span class="glyphicon glyphicon-trash"></span></a>											
						@else
							<a href="#" class="btn btn-danger disabled" role="button" data-toggle="tooltip"><span class="glyphicon glyphicon-trash"></span></a>							
						@endif						
					</p>
				</td>
			</tr>
			
			{{-- Confirm Delete --}}
			<div class="modal fade" id="modal-delete-{{ $user->id }}" tabIndex="-1">
			<div class="modal-dialog">
				<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">
					×
					</button>
					<h4 class="modal-title">Confirmação</h4>
				</div>
				<div class="modal-body">
					<p class="lead">
					<i class="fa fa-question-circle fa-lg"></i>  
					Tem certeza de que deseja excluir o registro? {{ $user->id }}
					</p>
				</div>
				<div class="modal-footer">
					<form method="POST" action="{{ route('users.destroy', $user->id) }}">
					<input type="hidden" name="_token" value="{{ csrf_token() }}">
					<input type="hidden" name="_method" value="DELETE">
					<button type="button" class="btn btn-default" data-dismiss="modal">Não</button>
					<button type="submit" class="btn btn-danger"><i class="fa fa-times-circle"></i> Sim</button>
					</form>
				</div>
				</div>
			</div>
			</div>			
			@endif
			@endforeach
		@endif
		</tbody>
	</table>
	</div>
	</div>
</div>

@stop