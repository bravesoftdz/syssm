@extends('layouts.master')

@section('content')

<script type="text/javascript">
    $(document).ready(function()
		{
		    $('a[href="#tabRestore"]').trigger('click');
		    $('a[href="#tabBackup"]').trigger('click');

			$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
				var $target = $(e.target).attr("href") // activated tab		
				var $elems = document.getElementsByClassName('tab-pane fade');
				var $tab;

				for (var i=0; i < $elems.length; i +=1) {
					$tab = '#' + $elems[i].id;
					if($tab == $target) 
						$elems[i].style.display = 'block';
					else 
						$elems[i].style.display = 'none';
				}
			});
		}
	);

</script>

<ul class="nav nav-tabs">
	<li class="active"><a data-toggle="tab" href="#tabBackup" id="tab_init">Backup</a></li>
	<li><a data-toggle="tab" href="#tabRestore">Recuperar</a></li>		
</ul>

<div id="tabBackup" class="tab-pane fade in active">
	<h3>Backup</h3>
	(em breve, aqui será colocada uma rotina de backup)
</div>

<div id="tabRestore" class="tab-pane fade in active">
	<h3>Recuperar</h3>
	
@if(Config('globals.nome_usuario') == 'Administrador')
    <a role="button" class="btn btn-default" href="{{ route('restore')}}">Iniciar</a> 
@else
	<a role="button" class="btn btn-default" href="#">Iniciar</a> 
@endif
</div>


@stop