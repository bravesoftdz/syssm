@extends('layouts.master')

@section('content')

<h1>Registro de Atividades</h1>
<hr>

@stop