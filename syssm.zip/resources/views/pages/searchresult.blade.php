@extends('layouts.master')

@section('content')

<?php

	$total_registros = count($dados);
	
	foreach ($dados as $index => $reg) 
	{
		$novo_nome = '<a href="'. $reg->link .'" title="Clique para editar">' . $reg->nome . '</a>';
		$reg->nome = $novo_nome;
		$reg->link = "";		
	}

?>

<div class="container-fluid">
	<div class="col-md-12">
		<h1>Resultados da Pesquisa</h1>
		<h4>Pesquisa por {{ $desc_tipopesquisa }}</h4>
	</div>
</div>

<div class='table-responsive'>

	<div class="form-group col-md-12"><br>
		@if($total_registros == 0)
			<b>A pesquisa não retornou resultados.</b>
		@else
			<b>A pesquisa retornou {{ $total_registros }} resultado(s).</b>
		@endif
	</div>
					
	<table class = 'table table-hover'>
		<thead>
			<tr>
			@foreach($colunas as $coluna)			
				<th>{{ $coluna }}</th>
			@endforeach
			</tr>
		</thead>
			
		<tbody>
			@foreach($dados as $dados)
				<tr>				
					<?php 
						foreach($dados as $index => $registro)
						{				
							if($index != 'link')
							{
								echo '<td>' . $registro . '</td>';
							}
						}							
					?>
				</tr>
			@endforeach
		</tbody>		
	</table>
	
	<tfooter>
		<tr>
			<td>
				<a href="#" class="btn btn-info" role="button" data-toggle="modal" data-target="#modal-search" title="Pesquisar">
				<span style="font-size:16px;" class="glyphicon glyphicon-search"></span>&nbsp;Nova pesquisa</a>
			</td>
		</tr>
	</tfooter>
	
</div>			

@stop