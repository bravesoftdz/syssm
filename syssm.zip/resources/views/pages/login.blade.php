@extends('layouts.master')

@section('content')

@if($errors->any())
    <div class="alert alert-danger">
        @foreach($errors->all() as $error)
            <p>{{ $error }}</p>
        @endforeach
    </div>
@endif

	<!-- if there are login errors, show them here -->
	@if (Session::get('loginError'))
	<div class="alert alert-danger">{{ Session::get('loginError') }}</div>
	@endif
	
    <div class="modal-dialog">
		<div class="loginmodal-container">
			<img src="{{ Config('globals.logo_sistema') }}" width="100%"><br>		
			<h1>Acesso ao Sistema</h1><br>
			{!! Form::open(['action' => 'PagesController@doLogin']) !!}
				{!! Form::text('name', null, ['placeholder' => 'Login', 'class' => 'loginmodal-container']) !!}
				<input type=password name='password' placeholder='Senha'>
				{!! Form::submit('Acessar', ['class' => 'login loginmodal-submit']) !!}
			{!! Form::close() !!}
			<br><br><br>
		    <p align="center">
                {{-- <a href="https://play.google.com/store/apps/details?id=br.com.app.gpu1704410.gpu8fc4efc3b634114c9a73ad3290f2957a">		        
    		        <b>Obtenha o aplicativo.</b><br>
                    <img src="{{ URL::asset('images/google_play_mini.png') }}">
                </a>--}}
            </p>
		</div>
	</div>

@stop