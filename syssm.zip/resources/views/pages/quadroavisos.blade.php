@section('quadro-avisos-script')

<script type="text/javascript">
	$(document).ready(function(){
		
		//evento disparado ao fechar alerta
		$("#alerta-agenda").bind('closed.bs.alert', function(){
			var x = $(this).find('div').attr("id");
			//alert(x);  
		});
		
	});  
	

</script>

<style type="text/css">

	.row{
		margin-top:40px;
		padding: 0 10px;
	}
	
	.clickable{
		cursor: pointer;   
	}
	
	.panel-heading span {
		margin-top: -20px;
		font-size: 15px;
	}

</style>

@stop

@section('quadro-avisos')

<?php

	use App\Models\Agenda;
	
	$arrayAgenda = DB::connection()->select('select agenda.id, ' .
											'       agenda.evento, ' .
											'       agenda.descricao, ' .
											'       agenda.dt_evento, ' . 
											//'       agenda.dt_inicio_lembrete, ' .
											//'       agenda.dt_expiracao_lembrete, ' .
											'       agenda.link, ' .
											'		tipo_evento.bootstrap_alert_type '.
											'	from agenda'.
											'   join tipo_evento on tipo_evento.id = agenda.id_tipo_evento '.
											'  where agenda.ativo = "S" '.
											'    and CURDATE() between agenda.dt_inicio_lembrete ' . 
											'    and agenda.dt_expiracao_lembrete ' . 
											'  order by agenda.id_tipo_evento desc, ' . 
											'           agenda.dt_evento ', []);
                                                     
?>

<div class="container">

	@foreach($arrayAgenda as $agenda)
	<div class="col-md-12">
		<div id="alerta-agenda" class="alert alert-{{ $agenda->bootstrap_alert_type }}">
		    <button href="#" type="button" class="close" data-dismiss="alert" >
			    <i class="glyphicon glyphicon-remove-circle text-info"></i>
			</button>
		    
		    <div id="{{ $agenda->id }}"></div>
		    <h4>{{ $agenda->evento }}</h4>
		    <p>{{ $agenda->descricao }}</p>
		
		    @if($agenda->link != "")
                <a class="btn btn-{{ $agenda->bootstrap_alert_type }}" role="button" href="{{ $agenda->link }}" title="Abrir" style="float: right; padding: 5px; margin-top: -20px;">
                    <span class="glyphicon glyphicon-folder-open"></span>
                </a>
            @endif
		</div>	
	</div>
	@endforeach
	
</div>

@stop