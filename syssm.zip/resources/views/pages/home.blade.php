@extends('layouts.master')

@section('title', 'SysSM - Controle de Estoque')

@section('sidebar')
    @parent

    <p>This is appended to the master sidebar.</p>
@stop

@section('content')

<h1>SysSM - Controle de Estoque</h1>
<p class="lead">Bem-vindo, {{ Config('globals.nome_usuario') }}.</p>
<hr>
	
	@if(Config('globals.usuario_admin'))	
		@include('pages.quadroavisos', [])
		@yield('quadro-avisos-script')
		@yield('quadro-avisos')
	@endif

@stop