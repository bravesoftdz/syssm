@extends('layouts.master')

@section('content')

<script type="text/javascript">

    $.ajaxSetup({
        headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') }
    });

    $(document).ready(function()
		{		
			$("#btncep").on('click', function()
			{
				cep = $("#emp_cep").val();
				cep = cep.replace("-", "");
				if (cep.length < 8)
				{
					alert("Digite o CEP.");
					return;
				}			
				$.getJSON('http://republicavirtual.com.br/web_cep.php?cep='+cep+'&formato=json', function(data){
					$("#emp_endereco").val('');
					$("#emp_bairro").val('');
					$("#emp_cidade").val('');
					$("#emp_uf").val('');
					
					if (data.sucesso != "0")
					{
						$("#emp_endereco").val(data.tipo_logradouro + ' ' + data.logradouro);
						$("#emp_bairro").val(data.bairro);
						$("#emp_cidade").val(data.cidade);
						$("#uf").val(data.uf);
						
						document.cookie = "endereco=" + $("#emp_endereco").val();
                        document.cookie = "bairro=" + $("#emp_bairro").val();
                        document.cookie = "cidade=" + $("#emp_cidade").val();
                        document.cookie = "uf=" + $("#emp_uf").val();
						$("#emp_numero").focus();
					}
					else
						alert("CEP não encontrado.");
				});
			});
		});
		
		(function() {
			VMasker(document.getElementById("emp_cnpj")).maskPattern('99.999.999/9999-99');
			VMasker(document.getElementById("emp_cep")).maskPattern('99999-999');
			formmodified = 0;

			$('form *').change(function(){
				formmodified=1;
			});
			window.onbeforeunload = confirmExit;

			function confirmExit() {
				if (formmodified == 1) {
					return "New information not saved. Do you wish to leave the page?";
				}
			}			
			
		})();
			
		function unMaskAll(){
			VMasker(document.getElementById("emp_cnpj")).unMask();
			VMasker(document.getElementById("emp_cep")).unMask();
			
		}
		
		$(document).ready(function() {
			
		});		
		
</script>

<h1>Configurações Gerais</h1>
<hr>

<div class='table-responsive'>

@include('partials.alerts.errors')

@foreach($parametros as $parametro)

	{!! Form::model($parametro, [
		'method' => 'PATCH',
		'route' => ['parametros.update', $parametro->id], 
        'files' => true,
		'onsubmit' => 'unMaskAll();'
	]) !!}
	
		<div class="form-group col-md-5">	
			{!! Form::label('emp_razao_social', 'Razão Social', ['class' => 'control-label']) !!}
			{!! Form::text('emp_razao_social', null, ['class' => 'form-control', 'maxlength' => 100]) !!}
		</div>
		<div class="form-group col-md-4">		
			{!! Form::label('emp_nome_fantasia', 'Nome Fantasia', ['class' => 'control-label']) !!}
			{!! Form::text('emp_nome_fantasia', null, ['class' => 'form-control', 'maxlength' => 100]) !!}			
		</div>
		<div class="form-group col-md-3">
			{!! Form::label('emp_cnpj', 'CNPJ', ['class' => 'control-label']) !!}
			{!! Form::text('emp_cnpj', null, ['class' => 'form-control', 'maxlength' => 18]) !!}
		</div>
		
		<div class="form-group col-md-8">
			{!! Form::label('emp_endereco', 'Endereço', ['class' => 'control-label']) !!}
			{!! Form::text('emp_endereco', null, ['class' => 'form-control', 'maxlength' => 100, 'disabled']) !!}
		</div>
		<div class="form-group col-md-2">
			{!! Form::label('emp_numero', 'Número', ['class' => 'control-label']) !!}
			{!! Form::text('emp_numero', null, ['class' => 'form-control', 'maxlength' => 6]) !!}
		</div>
		<div class="form-group col-md-2">
			{!! Form::label('emp_complemento', 'Complemento', ['class' => 'control-label']) !!}
			{!! Form::text('emp_complemento', null, ['class' => 'form-control', 'maxlength' => 15]) !!}
		</div>

		<div class="form-group col-md-3">
			<div class="input-group">
				{!! Form::label('emp_cep', 'CEP', ['class' => 'control-label']) !!}
				(<a href="http://www.buscacep.correios.com.br/sistemas/buscacep/" target="_blank">não sei meu CEP</a>)
				{!! Form::text('emp_cep', null, ['class' => 'form-control', 'maxlength' => 10]) !!}
				<span class="input-group-btn" style="vertical-align: bottom;">
					<a class="btn btn-primary" role="button" id="btncep"><span class="glyphicon glyphicon-search"></span></a>
				</span>
			</div>
		</div>
		<div class="form-group col-md-4">
			{!! Form::label('emp_bairro', 'Bairro', ['class' => 'control-label']) !!}
			{!! Form::text('emp_bairro', null, ['class' => 'form-control', 'maxlength' => 40, 'disabled']) !!}
		</div>
		<div class="form-group col-md-4">
			{!! Form::label('emp_cidade', 'Cidade', ['class' => 'control-label']) !!}
			{!! Form::text('emp_cidade', null, ['class' => 'form-control', 'maxlength' => 40, 'disabled']) !!}
		</div>
		<div class="form-group col-md-1">
			{!! Form::label('emp_uf', 'UF', ['class' => 'control-label']) !!}
			{!! Form::select('emp_uf', Config('globals.array_uf'), $parametro->emp_uf, ['class' => 'form-control', 'maxlength' => 2, 'disabled']) !!}
		</div>

		<div class="form-group offset-col-md-8 col-md-4">
			{!! Form::label('tipo_impressao_relatorio', 'Tipo de impressão do relatório', ['class' => 'control-label']) !!}
			{!! Form::select('tipo_impressao_relatorio', Config('globals.array_tipo_impressao_relatorio'), null, ['class' => 'form-control', 'maxlength' => 80]) !!}
		</div>				
					       
    	<div class="form-group col-md-12">
        	<hr>
	        <p class="text-right">
    	        {!! Form::submit('Gravar', ['class' => 'btn btn-primary']) !!}
        	    <a class="btn btn-danger" role="button" data-toggle="modal" data-target="#modal-cancel">Cancelar</a>	 
	        </p>
    	</div>
    
{!! Form::close() !!}			
			
@endforeach

    <div class="modal fade" id="modal-cancel" tabIndex="-1">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">
              ×
            </button>
            <h4 class="modal-title">Confirmação</h4>
          </div>
          <div class="modal-body">
            <p class="lead">
              <i class="fa fa-question-circle fa-lg"></i>  
              Existem dados não salvos. Tem certeza de que deseja sair?
            </p>
          </div>
          <div class="modal-footer">
              <a role="button" class="btn btn-default" data-dismiss="modal">Não</a>
              <a href="{{ route('parametros.index') }}" class="btn btn-danger" >Sim</a>
          </div>
        </div>
      </div>
    </div>
  </div> 
  

@stop